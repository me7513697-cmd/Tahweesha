import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.tahweesha.finance',
  appName: 'تحويشة',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
  },
};

export default config;
