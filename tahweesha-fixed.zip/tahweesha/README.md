# تحويشة (Tahweesha) — Premium Personal Finance Android App

<p align="center">
  <img src="public/assets/brand/logo-full.png" alt="Tahweesha" width="260" />
</p>

> **"خلي فلوسك في مكانها · تابع .. خطط .. حقق"**
>
> *(Keep your money where it belongs · Track .. Plan .. Achieve)*

Tahweesha (**تحويشة**) is a production-minded personal finance application designed for Android phones with a luxury glassmorphism visual identity inspired by modern iOS and native Jetpack Compose styling.

---

## 🌟 Highlights & Key Features

1. **Dashboard (الداشبورد الرئيسية)**:
   - Total current balance card with privacy eye toggle and per-account selector.
   - Frosted emerald-teal gradient glass cards matching the showcase mockup.
   - Monthly summary cards: Total Income and Total Expenses with real month-over-month change.
   - Available to spend progress tracker (`AED 7,600` for October 2025).
   - Category expense donut chart & ranked list (Housing 42%, Dining 22%, Shopping 19%, Transport 17%).
   - Recent transactions with category icons and signed currency amounts.

2. **Bank Statement Import & Reconciliation (استيراد كشف الحساب والمطابقة)**:
   - **Supported Formats**: CSV, Excel (`.xlsx`, `.xls` via SheetJS), and text-based PDF statements.
   - **Preloaded Synthetic UAE Bank Statements**: 1-click test datasets for Emirates NBD, ADCB Bank, and Ambiguous/Duplicate Audit statements.
   - **Intelligent Heuristic Classification**: Automatically maps merchants to categories (e.g. Carrefour, Lulu, DEWA, Etisalat, Starbucks, WPS Salary).
   - **Duplicate Detection**: Deterministic fingerprint hashing (`Date + Normalized Amount + Sanitized Merchant`) prevents double-counting.
   - **Opening vs. Closing Balance Reconciliation**: Verifies `Opening Balance + Credits - Debits == Closing Balance` and flags discrepancy variances.

3. **Transactions Management (العمليات)**:
   - Segmented filter chips: All (الكل), Expenses (مصاريف), Income (إيرادات), Transfers (تحويلات).
   - Instant search by merchant name or keyword.
   - Date grouping with calendar badges.
   - Transaction details modal with edit, delete, and confirmation status.

4. **Add / Edit Transaction (إضافة عملية)**:
   - Expense / Income / Internal Transfer modes.
   - High precision financial math (stored in integer minor units / cents).
   - Account and category pickers with real-time validation.

5. **Reports & Analytics (التقارير والتحليل)**:
   - Monthly and yearly toggles with month carousel navigator.
   - Dynamic spending vs income bar chart with 5-day interval bars.
   - Net cash flow indicator and monthly savings rate.
   - Top spending merchants breakdown.

6. **Budgets (الميزانية)**:
   - Circular progress gauge (65% of AED 10,000 monthly allowance).
   - Category limits tracking with 80% threshold warnings and 100%+ overbudget alerts.
   - Inline budget limit adjustments.

7. **Accounts & Wallets (الحسابات والمحافظ)**:
   - Multi-account management: Emirates NBD Checking, Cash Wallet, Dubai Islamic Savings.
   - Internal transfer engine: guarantees neutrality to total net worth.

8. **Savings Goals & Upcoming Bills (الأهداف والالتزامات)**:
   - Savings goals (e.g. "رحلة إلى دبي" - AED 3,200 / 5,000) with confetti celebration on completion.
   - Upcoming bills tracker (Rent, DEWA, Netflix, Internet) with due dates and paid toggles.

9. **Smart Financial Assistant (المساعد الذكي)**:
   - Real-time conversational insights based on stored transactions (dining spending, budget runway, savings suggestions).

10. **Settings & Privacy (الإعدادات والخصوصية)**:
    - Full Arabic (RTL) & English (LTR) language support.
    - Default currency AED (with USD, EUR, SAR, EGP options).
    - Light glassmorphism & Dark glassmorphism themes.
    - Biometric app lock simulation (Fingerprint / Face ID).
    - Local-first architecture: 100% offline, zero cloud uploads.
    - JSON & CSV backup export and restore.

---

## 🏗️ Architecture & Technology Stack

### Web Interactive Runtime (AI Studio Live Environment)
- **Framework**: React 19 + TypeScript + Vite 8
- **Styling**: Tailwind CSS v4 + Custom Glassmorphism CSS layers
- **Icons**: Lucide React
- **Parsers**: `xlsx` (SheetJS) for Excel files, native CSV engine, Canvas Confetti

### Android app (Capacitor)
- The web app is packaged as an Android app with **Capacitor 7** (`capacitor.config.ts`, `appId: com.tahweesha.finance`).
- The Android project is **generated in CI** (`npx cap add android`), launcher icons and splash come from `assets/` via `@capacitor/assets`.
- `android-native/` holds an early Kotlin / Jetpack Compose + Room prototype (static home screen + domain model); it is built as an optional, non-blocking CI job.

---

## 🚀 Running the Project

### 1. Interactive Web Application
```bash
# Install dependencies
npm install

# Run automated financial invariant unit tests
npm test

# Start local development server
npm run dev
```
Open `http://localhost:3000` to interact with Tahweesha in your browser.

### 2. Build the APK on GitHub
1. Push this folder to a GitHub repository (branch `main`).
2. Open the **Actions** tab → *Build Tahweesha APK* (it also runs on every push).
3. When it finishes, download **tahweesha-debug-apk** from the run's *Artifacts* and install the `.apk` on your phone (allow "install unknown apps").

Locally (needs JDK 21 + Android SDK): `npm run build && npx cap add android && npm run assets && npx cap sync android && cd android && ./gradlew assembleDebug`.

---

## 🧪 Automated Test Verification

All financial invariants are validated via automated tests:

Run `npm test` to execute the suite (accounting invariants, statement parsing for CSV / Excel / PDF rows, duplicate detection, reconciliation, regression tests).

---

## 🔒 Privacy & Security Invariants

1. **Zero External Servers**: No bank credentials are requested, stored, or transmitted.
2. **Local Processing**: Bank statements (PDF/Excel/CSV) are parsed strictly within device memory.
3. **Audit Trail**: The original raw narrative from the bank statement is stored alongside normalized descriptions.
4. **Data Portability**: Users can export their complete data to standard JSON or CSV at any time.

---

## 📄 License

Licensed under the Apache License, Version 2.0.
