package com.tahweesha.finance

import com.tahweesha.finance.domain.accounting.FinancialCalculator
import com.tahweesha.finance.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class FinancialCalculatorTest {

    @Test
    fun testAccountBalanceCalculations() {
        val account = Account(
            id = "acc_1",
            name = "حساب بنكي",
            nameEn = "Bank Account",
            type = AccountType.BANK,
            currency = "AED",
            openingBalanceMinorUnits = 100000L, // 1,000.00 AED
            openingDate = "2025-01-01",
            color = "#059669",
            icon = "Building2"
        )

        val transactions = listOf(
            Transaction(
                id = "tx_1",
                date = "2025-10-01",
                amountMinorUnits = 50000L, // 500.00 AED
                type = TransactionType.INCOME,
                categoryId = "cat_salary",
                accountId = "acc_1",
                description = "راتب",
                fingerprint = "fp1"
            ),
            Transaction(
                id = "tx_2",
                date = "2025-10-02",
                amountMinorUnits = 20000L, // 200.00 AED
                type = TransactionType.EXPENSE,
                categoryId = "cat_dining",
                accountId = "acc_1",
                description = "مطعم",
                fingerprint = "fp2"
            )
        )

        val computedBalance = FinancialCalculator.calculateAccountBalance(account, transactions)
        // 1000 + 500 - 200 = 1300 AED = 130,000 minor units
        assertEquals(130000L, computedBalance)
    }

    @Test
    fun testTransferNeutrality() {
        val checking = Account(
            id = "acc_checking",
            name = "حساب جاري",
            nameEn = "Checking",
            type = AccountType.BANK,
            currency = "AED",
            openingBalanceMinorUnits = 200000L, // 2,000.00 AED
            openingDate = "2025-01-01",
            color = "#059669",
            icon = "Building2"
        )

        val savings = Account(
            id = "acc_savings",
            name = "حساب توفير",
            nameEn = "Savings",
            type = AccountType.SAVINGS,
            currency = "AED",
            openingBalanceMinorUnits = 100000L, // 1,000.00 AED
            openingDate = "2025-01-01",
            color = "#7c3aed",
            icon = "PiggyBank"
        )

        val transferTx = Transaction(
            id = "tx_trf",
            date = "2025-10-03",
            amountMinorUnits = 50000L, // 500.00 AED
            type = TransactionType.TRANSFER,
            categoryId = "cat_transfer",
            accountId = "acc_checking",
            destinationAccountId = "acc_savings",
            description = "تحويل للتوفير",
            fingerprint = "fp_trf"
        )

        val accounts = listOf(checking, savings)
        val checkingBal = FinancialCalculator.calculateAccountBalance(checking, listOf(transferTx))
        val savingsBal = FinancialCalculator.calculateAccountBalance(savings, listOf(transferTx))
        val totalNetWorth = FinancialCalculator.calculateTotalNetWorth(accounts, listOf(transferTx))

        // Checking: 2000 - 500 = 1500 AED = 150,000 minor
        assertEquals(150000L, checkingBal)
        // Savings: 1000 + 500 = 1500 AED = 150,000 minor
        assertEquals(150000L, savingsBal)
        // Combined total must remain constant: 3,000 AED = 300,000 minor
        assertEquals(300000L, totalNetWorth)
    }

    @Test
    fun testStatementBalanceReconciliation() {
        val movements = listOf(
            TransactionType.INCOME to 800000L, // 8,000 AED
            TransactionType.EXPENSE to 250000L, // 2,500 AED
            TransactionType.EXPENSE to 18000L   // 180 AED
        )

        // Opening: 10,000 AED (1,000,000 minor)
        // Net: + 8,000 - 2,500 - 180 = + 5,320 AED
        // Calculated Closing: 15,320 AED (1,532,000 minor)
        val validReconciliation = FinancialCalculator.reconcileStatement(
            openingMinorUnits = 1000000L,
            reportedClosingMinorUnits = 1532000L,
            movements = movements
        )

        assertTrue(validReconciliation.isReconciled)
        assertEquals(0L, validReconciliation.differenceMinorUnits)

        val mismatchedReconciliation = FinancialCalculator.reconcileStatement(
            openingMinorUnits = 1000000L,
            reportedClosingMinorUnits = 1600000L, // Discrepancy
            movements = movements
        )

        assertFalse(mismatchedReconciliation.isReconciled)
        assertEquals(68000L, mismatchedReconciliation.differenceMinorUnits)
    }

    @Test
    fun testDuplicateFingerprints() {
        val fp1 = FinancialCalculator.generateFingerprint("2025-10-21", 18000L, "Zahrat Al Laymoun")
        val fp2 = FinancialCalculator.generateFingerprint("2025-10-21", 18000L, "zahrat al laymoun")
        assertEquals(fp1, fp2)

        val fpDifferentAmt = FinancialCalculator.generateFingerprint("2025-10-21", 18500L, "Zahrat Al Laymoun")
        assertNotEquals(fp1, fpDifferentAmt)
    }
}
