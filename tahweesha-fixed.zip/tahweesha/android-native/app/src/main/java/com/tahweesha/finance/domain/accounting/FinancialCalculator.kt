package com.tahweesha.finance.domain.accounting

import com.tahweesha.finance.domain.model.Account
import com.tahweesha.finance.domain.model.Transaction
import com.tahweesha.finance.domain.model.TransactionType

object FinancialCalculator {

    /**
     * Invariant 1:
     * Opening balance + Incomes - Expenses - Outward Transfers + Inward Transfers = Account Balance
     */
    fun calculateAccountBalance(account: Account, transactions: List<Transaction>): Long {
        var balance = account.openingBalanceMinorUnits

        for (tx in transactions) {
            if (tx.accountId == account.id) {
                when (tx.type) {
                    TransactionType.INCOME -> balance += tx.amountMinorUnits
                    TransactionType.EXPENSE -> balance -= tx.amountMinorUnits
                    TransactionType.TRANSFER -> balance -= tx.amountMinorUnits
                }
            } else if (tx.destinationAccountId == account.id && tx.type == TransactionType.TRANSFER) {
                balance += tx.amountMinorUnits
            }
        }

        return balance
    }

    /**
     * Invariant 2:
     * Total Net Position across all accounts.
     * Internal transfers between owned accounts have a net impact of 0.
     */
    fun calculateTotalNetWorth(accounts: List<Account>, transactions: List<Transaction>): Long {
        return accounts.sumOf { calculateAccountBalance(it, transactions) }
    }

    /**
     * Invariant 3:
     * Duplicate Fingerprint Hash
     */
    fun generateFingerprint(date: String, amountMinorUnits: Long, description: String): String {
        val cleanDate = date.trim()
        val cleanAmt = kotlin.math.abs(amountMinorUnits)
        val cleanDesc = description.lowercase().replace(Regex("[^a-zA-Z0-9\\u0600-\\u06FF]"), "").trim()
        return "$cleanDate#$cleanAmt#$cleanDesc"
    }

    /**
     * Invariant 4:
     * Bank Statement Balance Reconciliation:
     * Opening Balance + Sum(Credits) - Sum(Debits) === Closing Balance
     */
    data class ReconciliationResult(
        val isReconciled: Boolean,
        val openingMinorUnits: Long,
        val calculatedClosingMinorUnits: Long,
        val reportedClosingMinorUnits: Long,
        val differenceMinorUnits: Long
    )

    fun reconcileStatement(
        openingMinorUnits: Long,
        reportedClosingMinorUnits: Long,
        movements: List<Pair<TransactionType, Long>>
    ): ReconciliationResult {
        var credits = 0L
        var debits = 0L

        for ((type, amount) in movements) {
            val absAmt = kotlin.math.abs(amount)
            if (type == TransactionType.INCOME) {
                credits += absAmt
            } else {
                debits += absAmt
            }
        }

        val calculatedClosing = openingMinorUnits + credits - debits
        val difference = reportedClosingMinorUnits - calculatedClosing
        val isReconciled = difference == 0L

        return ReconciliationResult(
            isReconciled = isReconciled,
            openingMinorUnits = openingMinorUnits,
            calculatedClosingMinorUnits = calculatedClosing,
            reportedClosingMinorUnits = reportedClosingMinorUnits,
            differenceMinorUnits = difference
        )
    }
}
