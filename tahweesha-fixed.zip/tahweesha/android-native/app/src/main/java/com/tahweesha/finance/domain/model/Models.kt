package com.tahweesha.finance.domain.model

enum class TransactionType {
    INCOME,
    EXPENSE,
    TRANSFER
}

enum class TransactionSource {
    MANUAL,
    STATEMENT_IMPORT
}

enum class TransactionReviewStatus {
    VERIFIED,
    REVIEWED,
    UNCERTAIN
}

data class Transaction(
    val id: String,
    val date: String, // ISO YYYY-MM-DD
    val amountMinorUnits: Long, // Exact integer minor units (e.g. 18000 for 180.00 AED)
    val type: TransactionType,
    val categoryId: String,
    val accountId: String,
    val destinationAccountId: String? = null,
    val description: String,
    val originalDescription: String? = null,
    val notes: String? = null,
    val source: TransactionSource = TransactionSource.MANUAL,
    val importBatchId: String? = null,
    val status: TransactionReviewStatus = TransactionReviewStatus.VERIFIED,
    val fingerprint: String,
    val referenceNumber: String? = null
) {
    val amountMajor: Double
        get() = amountMinorUnits / 100.0
}

enum class AccountType {
    BANK,
    WALLET,
    SAVINGS,
    CREDIT
}

data class Account(
    val id: String,
    val name: String,
    val nameEn: String,
    val type: AccountType,
    val currency: String = "AED",
    val openingBalanceMinorUnits: Long,
    val openingDate: String,
    val color: String,
    val icon: String,
    val accountNumberMask: String? = null,
    val lastReconciliationDate: String? = null
)

data class Category(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val icon: String,
    val color: String,
    val type: TransactionType
)

data class Budget(
    val id: String,
    val categoryId: String,
    val month: String, // YYYY-MM
    val limitMinorUnits: Long
)

data class SavingsGoal(
    val id: String,
    val name: String,
    val targetAmountMinorUnits: Long,
    val currentAmountMinorUnits: Long,
    val targetDate: String,
    val icon: String
)

data class RecurringBill(
    val id: String,
    val name: String,
    val amountMinorUnits: Long,
    val dueDate: String,
    val isPaid: Boolean,
    val icon: String
)
