package com.tahweesha.finance.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.tahweesha.finance.domain.model.AccountType
import com.tahweesha.finance.domain.model.TransactionReviewStatus
import com.tahweesha.finance.domain.model.TransactionSource
import com.tahweesha.finance.domain.model.TransactionType

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val date: String,
    val amountMinorUnits: Long,
    val type: String, // INCOME, EXPENSE, TRANSFER
    val categoryId: String,
    val accountId: String,
    val destinationAccountId: String?,
    val description: String,
    val originalDescription: String?,
    val notes: String?,
    val source: String,
    val importBatchId: String?,
    val status: String,
    val fingerprint: String,
    val referenceNumber: String?
)

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String,
    val name: String,
    val nameEn: String,
    val type: String,
    val currency: String,
    val openingBalanceMinorUnits: Long,
    val openingDate: String,
    val color: String,
    val icon: String,
    val accountNumberMask: String?,
    val lastReconciliationDate: String?
)

@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey val id: String,
    val categoryId: String,
    val month: String,
    val limitMinorUnits: Long
)

@Entity(tableName = "savings_goals")
data class SavingsGoalEntity(
    @PrimaryKey val id: String,
    val name: String,
    val targetAmountMinorUnits: Long,
    val currentAmountMinorUnits: Long,
    val targetDate: String,
    val icon: String
)

@Entity(tableName = "recurring_bills")
data class RecurringBillEntity(
    @PrimaryKey val id: String,
    val name: String,
    val amountMinorUnits: Long,
    val dueDate: String,
    val isPaid: Boolean,
    val icon: String
)
