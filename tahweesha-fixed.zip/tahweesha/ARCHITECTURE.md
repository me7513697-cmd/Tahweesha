# Tahweesha (تحويشة) — Technical Architecture

This document describes the software architecture, data invariants, and design principles of the **Tahweesha** personal finance system.

---

## 1. Architectural Philosophy: Clean, Local-First Architecture

Tahweesha adheres to Clean Architecture with three strictly decoupled layers:

```
┌─────────────────────────────────────────────────────────────────┐
│                          UI Layer                               │
│  - Jetpack Compose / React Components                           │
│  - ViewModels & State Management                                │
│  - Responsive Glassmorphism Mobile Frame                        │
└────────────────────────────────┬────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                        Domain Layer                             │
│  - FinancialCalculator & Invariant Enforcers                    │
│  - StatementParser & Heuristic Classification                   │
│  - Models: Transaction, Account, Category, Budget, Goal, Bill   │
└────────────────────────────────┬────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                         Data Layer                              │
│  - Room Database with SQLite (Android)                          │
│  - LocalStorage / IndexedDB (Web Runtime)                       │
│  - Storage Access Framework & XLSX Parser                       │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. Fundamental Accounting Invariants

To guarantee that Tahweesha produces exact, auditable financial records without precision drift or double-counting, the following mathematical rules are strictly enforced:

### Invariant 1: Account Balance Formula
$$\text{Balance}_{\text{Account}} = \text{OpeningBalance} + \sum \text{Credits} - \sum \text{Debits} - \sum \text{OutwardTransfers} + \sum \text{InwardTransfers}$$

Monetary values are represented with exact 2-decimal precision (or integer minor units in SQLite: e.g. `18000` for `180.00 AED`) to prevent floating-point inaccuracies.

### Invariant 2: Transfer Neutrality
$$\Delta \text{NetWorth}_{\text{InternalTransfer}} = 0$$

An internal transfer moving funds between two accounts owned by the user (e.g. from Emirates NBD Checking to Dubai Islamic Savings) decreases Account A and increases Account B by the identical amount. Internal transfers are never counted as personal income or expense in spending summaries.

### Invariant 3: Bank Statement Balance Reconciliation
Given:
- Statement Opening Balance: $B_{\text{open}}$
- Statement Closing Balance: $B_{\text{close}}$
- Statement Movements: $\{M_1, M_2, \dots, M_k\}$

The system calculates:
$$B_{\text{calc}} = B_{\text{open}} + \sum_{i=1}^k (\text{Credit}_i - \text{Debit}_i)$$
$$\text{Variance} = B_{\text{close}} - B_{\text{calc}}$$

If $\text{Variance} = 0$, the statement is marked as **Verified & Reconciled** (`isReconciled = true`). If a difference exists, the user is warned that candidate transactions may have missing rows or manual adjustments.

### Invariant 4: Duplicate Fingerprint Hashing
Every imported or entered transaction generates a deterministic hash:
$$\text{Fingerprint} = \text{Normalize}(\text{Date}) \mathbin{\Vert} \text{Round}_2(|\text{Amount}|) \mathbin{\Vert} \text{Sanitize}(\text{Description})$$

If an imported file contains a transaction whose fingerprint matches an existing entry in the database, the candidate row is flagged as **Uncertain / Potential Duplicate** and unselected by default.

---

## 3. Bank Statement Import Pipeline

The statement import pipeline consists of 10 deterministic stages:

1. **Document Selection**: Document picker or drag & drop (PDF, Excel `.xlsx`, CSV).
2. **Matrix Parsing**: Row and column extraction into a tabular grid.
3. **Header Detection**: Identifies header positions for Date, Description, Debit, Credit, Amount, and Balance.
4. **Column Mapping**: Auto-maps columns based on multilingual dictionaries (Arabic & English).
5. **Normalization**:
   - Dates converted to ISO standard `YYYY-MM-DD`.
   - Currency strings parsed, stripping symbols (`AED`, `د.إ`, `CR`, `DR`, commas, parentheses).
   - Merchant descriptions cleaned of transaction noise (`POS DEBIT`, `CHQ CLEARING`, `WPS`).
6. **Heuristic Category Matching**: Automatic classification into Dining, Shopping, Housing, Transport, Health, etc.
7. **Duplicate Detection**: Fingerprint comparison against existing database records.
8. **Balance Reconciliation**: Verifies closing balance against opening balance and row sum.
9. **Interactive Review**: User can toggle transactions, modify category suggestions, and inspect warnings.
10. **Atomic Batch Insertion**: Transactions are saved in a single database transaction.

---

## 4. Security & Privacy Blueprint

- **Offline-First**: All data is stored in the local SQLite/Room database or browser `localStorage`.
- **Zero Cloud Leakage**: No telemetry, analytics, or external server calls.
- **Biometric App Lock**: Protects app access on device resume using AndroidX BiometricPrompt.
- **Encrypted Exports**: Backups are produced directly to local device storage.
