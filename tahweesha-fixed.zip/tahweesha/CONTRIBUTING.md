# Contributing to Tahweesha (تحويشة)

We welcome contributions to make Tahweesha the best local-first personal finance app!

## Development Guidelines

1. **Accounting Invariants**: Any change modifying balance calculations, transfers, or statement reconciliation must pass all automated invariant unit tests:
   ```bash
   npm test
   ```
2. **Precision**: Never use standard floating point arithmetic without rounding or integer minor units for monetary calculations.
3. **Localization**: All UI strings must have both Arabic (values-ar) and English (values) representations with proper RTL/LTR support.
4. **Android Compose Standards**: Use Material 3 customized with the glassmorphism theme tokens (`Theme.kt`).
5. **No Telemetry**: Never add external trackers, telemetry, or server reporting. All data processing must remain 100% on-device.
