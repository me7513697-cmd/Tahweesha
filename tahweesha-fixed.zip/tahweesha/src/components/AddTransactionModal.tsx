import React, { useState, useEffect } from 'react';
import { X, Calendar, ArrowLeftRight, Check, AlertCircle } from 'lucide-react';
import { Transaction, Account, Category, AppSettings, TransactionType } from '../types/finance';
import { generateTransactionFingerprint, roundTo2Decimals, todayISO } from '../utils/financialMath';

interface AddTransactionModalProps {
  isOpen: boolean;
  initialType?: TransactionType;
  editingTransaction?: Transaction | null;
  categories: Category[];
  accounts: Account[];
  settings: AppSettings;
  onClose: () => void;
  onSave: (tx: Transaction) => void;
}

export const AddTransactionModal: React.FC<AddTransactionModalProps> = ({
  isOpen,
  initialType = 'expense',
  editingTransaction = null,
  categories,
  accounts,
  settings,
  onClose,
  onSave,
}) => {
  const isDark = settings.theme === 'dark';
  const isAr = settings.language === 'ar';

  const [type, setType] = useState<TransactionType>(initialType);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [accountId, setAccountId] = useState('');
  const [destinationAccountId, setDestinationAccountId] = useState('');
  const [date, setDate] = useState(todayISO());
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (editingTransaction) {
      setType(editingTransaction.type);
      setAmount(editingTransaction.amount.toString());
      setDescription(editingTransaction.description);
      setCategoryId(editingTransaction.categoryId);
      setAccountId(editingTransaction.accountId);
      setDestinationAccountId(editingTransaction.destinationAccountId || '');
      setDate(editingTransaction.date);
      setNotes(editingTransaction.notes || '');
    } else {
      setType(initialType);
      setAmount('');
      setDescription('');
      setDate(todayISO());
      setNotes('');

      // Defaults
      const preferred =
        settings.selectedAccountId !== 'all' && accounts.some((a) => a.id === settings.selectedAccountId)
          ? settings.selectedAccountId
          : accounts[0]?.id;
      if (preferred) setAccountId(preferred);
      const other = accounts.find((a) => a.id !== preferred);
      setDestinationAccountId(other ? other.id : '');

      const defaultCat = categories.find((c) =>
        initialType === 'income' ? c.type === 'income' : c.type === 'expense'
      );
      setCategoryId(defaultCat ? defaultCat.id : '');
    }
    setError(null);
    // Only re-initialise when the dialog opens or its target changes, never while the user is typing
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editingTransaction, initialType, isOpen]);

  if (!isOpen) return null;

  const filteredCategories = categories.filter((c) => {
    if (c.id === 'cat_transfer') return false; // reserved for internal transfers
    if (type === 'income') return c.type === 'income' || c.type === 'both';
    if (type === 'expense') return c.type === 'expense' || c.type === 'both';
    return true;
  });

  const handleTypeChange = (newType: TransactionType) => {
    setType(newType);
    // Keep the chosen category valid for the new type (an income must not keep an expense category)
    const valid = categories.filter((c) => c.id !== 'cat_transfer').filter((c) =>
      newType === 'income' ? c.type === 'income' || c.type === 'both' : c.type === 'expense' || c.type === 'both'
    );
    if (newType !== 'transfer' && !valid.some((c) => c.id === categoryId)) {
      const first = valid.find((c) => c.id !== 'cat_transfer' && c.id !== 'cat_other') || valid[0];
      setCategoryId(first ? first.id : '');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError(isAr ? 'يرجى إدخال مبلغ صحيح أكبر من الصفر' : 'Please enter a valid amount greater than 0');
      return;
    }

    if (!description.trim()) {
      setError(isAr ? 'يرجى كتابة وصف المعاملة' : 'Please enter a description');
      return;
    }

    if (!accountId) {
      setError(isAr ? 'يرجى اختيار الحساب' : 'Please select an account');
      return;
    }

    if (type === 'transfer') {
      if (!destinationAccountId) {
        setError(isAr ? 'يرجى اختيار الحساب المحول إليه' : 'Please select destination account');
        return;
      }
      if (accountId === destinationAccountId) {
        setError(
          isAr
            ? 'لا يمكن التحويل لنفس الحساب. اختر حسابين مختلفين'
            : 'Cannot transfer to the same account. Select distinct accounts'
        );
        return;
      }
    }

    const cleanAmt = roundTo2Decimals(parsedAmount);
    const fingerprint = generateTransactionFingerprint(date, cleanAmt, description);

    const newTx: Transaction = {
      id: editingTransaction ? editingTransaction.id : `tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      date,
      amount: cleanAmt,
      type,
      categoryId: type === 'transfer' ? 'cat_transfer' : categoryId || 'cat_other',
      accountId,
      destinationAccountId: type === 'transfer' ? destinationAccountId : undefined,
      description: description.trim(),
      originalDescription: editingTransaction?.originalDescription,
      notes: notes.trim() || undefined,
      source: editingTransaction ? editingTransaction.source : 'manual',
      status: 'verified',
      fingerprint,
    };

    onSave(newTx);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div
        className={`w-full max-w-sm max-h-[92vh] overflow-y-auto rounded-3xl p-6 shadow-2xl transition-all ${
          isDark ? 'bg-slate-900 border border-slate-800 text-white' : 'bg-white text-slate-900'
        }`}
      >
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <h2 className="text-base font-bold">
            {editingTransaction
              ? isAr ? 'تعديل المعاملة' : 'Edit Transaction'
              : isAr ? 'إضافة عملية جديدة' : 'Add New Transaction'}
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="pt-4 space-y-4">
          {/* Segmented Type Toggle (مصاريف / إيراد / تحويل) */}
          <div
            className={`p-1 rounded-2xl flex items-center gap-1 ${
              isDark ? 'bg-slate-800' : 'bg-slate-100'
            }`}
          >
            <button
              type="button"
              onClick={() => handleTypeChange('expense')}
              className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
                type === 'expense'
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
              }`}
            >
              {isAr ? 'مصاريف' : 'Expense'}
            </button>
            <button
              type="button"
              onClick={() => handleTypeChange('income')}
              className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
                type === 'income'
                  ? 'bg-emerald-500 text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
              }`}
            >
              {isAr ? 'إيراد' : 'Income'}
            </button>
            <button
              type="button"
              onClick={() => handleTypeChange('transfer')}
              className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
                type === 'transfer'
                  ? 'bg-blue-500 text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
              }`}
            >
              {isAr ? 'تحويل' : 'Transfer'}
            </button>
          </div>

          {/* Amount Field matching reference */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
              {isAr ? 'المبلغ' : 'Amount'}
            </label>
            <div
              className={`flex items-center px-4 py-3 rounded-2xl border transition-all ${
                isDark
                  ? 'bg-slate-800/80 border-slate-700 focus-within:border-emerald-500'
                  : 'bg-slate-50 border-slate-200 focus-within:border-emerald-600'
              }`}
            >
              <input
                type="number"
                step="0.01"
                min="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder={isAr ? 'أدخل المبلغ' : 'Enter amount'}
                className="w-full bg-transparent text-xl font-bold tabular-nums outline-none text-slate-900 dark:text-white"
                autoFocus
              />
              <span className="text-xs font-bold text-slate-400 px-1 shrink-0">
                {settings.currency}
              </span>
            </div>
          </div>

          {/* Category Dropdown (hidden if Transfer) */}
          {type !== 'transfer' && (
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                {isAr ? 'الفئة' : 'Category'}
              </label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className={`w-full px-3 py-2.5 rounded-2xl text-xs font-medium border outline-none cursor-pointer ${
                  isDark
                    ? 'bg-slate-800 border-slate-700 text-white'
                    : 'bg-slate-50 border-slate-200 text-slate-900'
                }`}
              >
                <option value="">{isAr ? 'اختر الفئة' : 'Select category'}</option>
                {filteredCategories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {isAr ? c.nameAr : c.nameEn}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Account Picker */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
              {type === 'transfer'
                ? isAr ? 'من الحساب' : 'From Account'
                : isAr ? 'الحساب' : 'Account'}
            </label>
            <select
              value={accountId}
              onChange={(e) => setAccountId(e.target.value)}
              className={`w-full px-3 py-2.5 rounded-2xl text-xs font-medium border outline-none cursor-pointer ${
                isDark
                  ? 'bg-slate-800 border-slate-700 text-white'
                  : 'bg-slate-50 border-slate-200 text-slate-900'
              }`}
            >
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {isAr ? a.name : a.nameEn}
                </option>
              ))}
            </select>
          </div>

          {/* Destination Account Picker for Transfer */}
          {type === 'transfer' && (
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                {isAr ? 'إلى الحساب' : 'To Destination Account'}
              </label>
              <select
                value={destinationAccountId}
                onChange={(e) => setDestinationAccountId(e.target.value)}
                className={`w-full px-3 py-2.5 rounded-2xl text-xs font-medium border outline-none cursor-pointer ${
                  isDark
                    ? 'bg-slate-800 border-slate-700 text-white'
                    : 'bg-slate-50 border-slate-200 text-slate-900'
                }`}
              >
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {isAr ? a.name : a.nameEn}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Description Input */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
              {isAr ? 'الوصف' : 'Description'}
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={isAr ? 'مثل: سوبرماركت، مطعم، إيجار' : 'e.g. Supermarket, Dining, Rent'}
              className={`w-full px-3 py-2.5 rounded-2xl text-xs font-medium border outline-none ${
                isDark
                  ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-500'
                  : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'
              }`}
            />
          </div>

          {/* Date Picker */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
              {isAr ? 'التاريخ' : 'Date'}
            </label>
            <div
              className={`flex items-center px-3 py-2.5 rounded-2xl border ${
                isDark ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <Calendar size={16} className="text-slate-400 shrink-0" />
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-transparent px-2 text-xs font-medium outline-none text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-2.5 rounded-xl bg-rose-500/10 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-1.5">
              <AlertCircle size={14} className="shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Save Button matching reference */}
          <button
            type="submit"
            className="w-full py-3.5 rounded-2xl text-white font-bold text-sm shadow-lg shadow-emerald-700/20 active:scale-[0.98] transition-all"
            style={{
              background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
            }}
          >
            {isAr ? 'حفظ' : 'Save'}
          </button>
        </form>
      </div>
    </div>
  );
};
