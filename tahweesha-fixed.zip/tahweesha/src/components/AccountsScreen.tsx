import React, { useState } from 'react';
import {
  Building2,
  Wallet,
  PiggyBank,
  CreditCard,
  Plus,
  ArrowLeftRight,
  CheckCircle2,
  X,
  Shield,
  Layers,
} from 'lucide-react';
import { Account, Transaction, AppSettings } from '../types/finance';
import { calculateAccountBalance, calculateTotalBalance, formatCurrency, roundTo2Decimals, todayISO } from '../utils/financialMath';

interface AccountsScreenProps {
  accounts: Account[];
  transactions: Transaction[];
  settings: AppSettings;
  onAddAccount: (account: Account) => void;
  onTransfer: (fromAccountId: string, toAccountId: string, amount: number, description: string) => void;
}

export const AccountsScreen: React.FC<AccountsScreenProps> = ({
  accounts,
  transactions,
  settings,
  onAddAccount,
  onTransfer,
}) => {
  const isDark = settings.theme === 'dark';
  const isAr = settings.language === 'ar';

  const [showTransferModal, setShowTransferModal] = useState(false);
  const [fromAccountId, setFromAccountId] = useState(accounts[0]?.id || '');
  const [toAccountId, setToAccountId] = useState(accounts[1]?.id || '');
  const [transferAmount, setTransferAmount] = useState('');
  const [transferDesc, setTransferDesc] = useState('');
  const [transferError, setTransferError] = useState<string | null>(null);

  const [showAddAccountModal, setShowAddAccountModal] = useState(false);
  const [newAccName, setNewAccName] = useState('');
  const [newAccType, setNewAccType] = useState<Account['type']>('bank');
  const [newAccBalance, setNewAccBalance] = useState('');

  const totalBalance = calculateTotalBalance(accounts, transactions);

  const formatAmount = (val: number) => {
    return formatCurrency(val, settings.currency, settings.language);
  };

  const getAccountIcon = (type: Account['type'], iconName: string) => {
    switch (type) {
      case 'bank':
        return <Building2 size={20} />;
      case 'wallet':
        return <Wallet size={20} />;
      case 'savings':
        return <PiggyBank size={20} />;
      case 'credit':
        return <CreditCard size={20} />;
      default:
        return <Building2 size={20} />;
    }
  };

  const handleExecuteTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    setTransferError(null);

    const amt = parseFloat(transferAmount);
    if (isNaN(amt) || amt <= 0) {
      setTransferError(isAr ? 'يرجى إدخال مبلغ صحيح' : 'Please enter a valid amount');
      return;
    }

    if (!fromAccountId || !toAccountId || fromAccountId === toAccountId) {
      setTransferError(
        isAr ? 'يرجى اختيار حسابين مختلفين للتحويل' : 'Please select two different accounts'
      );
      return;
    }

    const available = calculateAccountBalance(
      accounts.find((a) => a.id === fromAccountId)!,
      transactions
    );
    if (available < amt && !confirm(
      isAr
        ? 'الرصيد في الحساب المحوّل منه أقل من المبلغ. هل تريد المتابعة؟'
        : 'The source account balance is lower than this amount. Continue anyway?'
    )) {
      return;
    }

    onTransfer(
      fromAccountId,
      toAccountId,
      roundTo2Decimals(amt),
      transferDesc.trim() || (isAr ? 'تحويل بين الحسابات' : 'Internal Transfer')
    );
    setShowTransferModal(false);
    setTransferAmount('');
    setTransferDesc('');
  };

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAccName.trim()) return;

    const openingBal = parseFloat(newAccBalance) || 0;
    const newAcc: Account = {
      id: `acc_${Date.now()}`,
      name: newAccName.trim(),
      nameEn: newAccName.trim(),
      type: newAccType,
      currency: settings.currency,
      openingBalance: roundTo2Decimals(openingBal),
      openingDate: todayISO(),
      color: newAccType === 'bank' ? '#059669' : newAccType === 'savings' ? '#7c3aed' : '#0284c7',
      icon: newAccType === 'bank' ? 'Building2' : newAccType === 'savings' ? 'PiggyBank' : 'Wallet',
      accountNumberMask: '•••• 1234',
    };

    onAddAccount(newAcc);
    setShowAddAccountModal(false);
    setNewAccName('');
    setNewAccBalance('');
  };

  return (
    <div className="flex flex-col gap-5 pb-28">
      {/* Top Header */}
      <div className="flex items-center justify-between px-1">
        <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          {isAr ? 'الحسابات والمحافظ' : 'Accounts & Wallets'}
        </h1>
        <button
          onClick={() => setShowTransferModal(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-600 text-white text-xs font-semibold shadow-sm hover:bg-emerald-700 transition-colors"
        >
          <ArrowLeftRight size={14} />
          <span>{isAr ? 'تحويل بين الحسابات' : 'Transfer'}</span>
        </button>
      </div>

      {/* Aggregate Net Worth Card */}
      <div
        className="rounded-3xl p-6 text-white shadow-lg shadow-emerald-950/20"
        style={{
          background: 'linear-gradient(135deg, #047857 0%, #0d9488 50%, #065f46 100%)',
        }}
      >
        <div className="text-xs font-medium text-emerald-100">
          {isAr ? 'إجمالي صافي الأصول المالية' : 'Total Net Financial Position'}
        </div>
        <div className="text-3xl font-extrabold tabular-nums mt-1">
          {formatAmount(totalBalance)}
        </div>
        <div className="text-[11px] text-emerald-100/80 mt-2 flex items-center gap-2">
          <span>{accounts.length} {isAr ? 'حسابات ومحافظ نشطة' : 'active accounts'}</span>
          <span>·</span>
          <span>{isAr ? 'جميع العمليات محلية 100%' : '100% offline local'}</span>
        </div>
      </div>

      {/* Accounts List */}
      <div className="space-y-3">
        {accounts.map((acc) => {
          const balance = calculateAccountBalance(acc, transactions);

          return (
            <div
              key={acc.id}
              className={`p-4 rounded-3xl transition-all ${
                isDark ? 'glass-card-dark' : 'glass-card-light'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className="w-11 h-11 rounded-2xl flex items-center justify-center text-white shadow-sm"
                    style={{ backgroundColor: acc.color }}
                  >
                    {getAccountIcon(acc.type, acc.icon)}
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900 dark:text-white">
                      {isAr ? acc.name : acc.nameEn}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-2">
                      <span>{acc.accountNumberMask || acc.type}</span>
                      {acc.lastReconciliationDate && (
                        <>
                          <span>·</span>
                          <span className="text-emerald-600 dark:text-emerald-400 font-medium">
                            {isAr ? 'تمت المطابقة' : 'Reconciled'}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="text-left font-bold tabular-nums">
                  <div className="text-base text-slate-900 dark:text-white">
                    {formatAmount(balance)}
                  </div>
                  <div className="text-[10px] text-slate-400 font-normal mt-0.5">
                    {isAr ? `الرصيد الافتتاحي: ${formatAmount(acc.openingBalance)}` : `Opening: ${formatAmount(acc.openingBalance)}`}
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {/* Add Account Trigger */}
        <button
          onClick={() => setShowAddAccountModal(true)}
          className={`w-full py-4 rounded-3xl border border-dashed text-xs font-bold flex items-center justify-center gap-2 transition-colors ${
            isDark
              ? 'border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white bg-slate-900/40'
              : 'border-slate-300 hover:border-slate-400 text-slate-600 hover:text-slate-900 bg-white/40'
          }`}
        >
          <Plus size={16} />
          <span>{isAr ? 'إضافة حساب أو محفظة جديدة' : 'Add New Account or Wallet'}</span>
        </button>
      </div>

      {/* Internal Transfer Modal */}
      {showTransferModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div
            className={`w-full max-w-sm rounded-3xl p-6 shadow-2xl ${
              isDark ? 'bg-slate-900 border border-slate-800 text-white' : 'bg-white text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-sm">
                {isAr ? 'تحويل مالي بين الحسابات' : 'Transfer Between Accounts'}
              </h3>
              <button onClick={() => setShowTransferModal(false)} className="text-slate-400 hover:text-slate-600">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleExecuteTransfer} className="pt-4 space-y-4">
              <div>
                <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                  {isAr ? 'من الحساب (خصم)' : 'From Account'}
                </label>
                <select
                  value={fromAccountId}
                  onChange={(e) => setFromAccountId(e.target.value)}
                  className={`w-full p-2.5 rounded-2xl text-xs font-medium border outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  {accounts.map((a) => (
                    <option key={a.id} value={a.id}>
                      {isAr ? a.name : a.nameEn} ({formatAmount(calculateAccountBalance(a, transactions))})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                  {isAr ? 'إلى الحساب (إيداع)' : 'To Account'}
                </label>
                <select
                  value={toAccountId}
                  onChange={(e) => setToAccountId(e.target.value)}
                  className={`w-full p-2.5 rounded-2xl text-xs font-medium border outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  {accounts.map((a) => (
                    <option key={a.id} value={a.id}>
                      {isAr ? a.name : a.nameEn} ({formatAmount(calculateAccountBalance(a, transactions))})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                  {isAr ? 'المبلغ المحوّل' : 'Transfer Amount'}
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={transferAmount}
                  onChange={(e) => setTransferAmount(e.target.value)}
                  placeholder="0.00"
                  className={`w-full p-2.5 rounded-2xl text-base font-bold tabular-nums border outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200'
                  }`}
                  autoFocus
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                  {isAr ? 'الوصف' : 'Description'}
                </label>
                <input
                  type="text"
                  value={transferDesc}
                  onChange={(e) => setTransferDesc(e.target.value)}
                  placeholder={isAr ? 'تحويل حساب توفير أو سداد' : 'e.g. Monthly Savings'}
                  className={`w-full p-2.5 rounded-2xl text-xs border outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200'
                  }`}
                />
              </div>

              {transferError && (
                <div className="text-xs text-rose-500 font-medium">{transferError}</div>
              )}

              <div className="p-3 rounded-2xl bg-blue-500/10 text-blue-800 dark:text-blue-300 text-[10px]">
                {isAr
                  ? 'ℹ️ التحويل الداخلي لا يُعد مصروفاً ولا دخلاً، ولا يغير إجمالي رصيدك الصافي.'
                  : 'ℹ️ Internal transfers are neutral to total net worth and excluded from spending budgets.'}
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-emerald-600 text-white font-bold text-xs shadow-md shadow-emerald-700/20 active:scale-[0.98]"
              >
                {isAr ? 'تنفيذ التحويل' : 'Execute Transfer'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Add New Account Modal */}
      {showAddAccountModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div
            className={`w-full max-w-sm rounded-3xl p-6 shadow-2xl ${
              isDark ? 'bg-slate-900 border border-slate-800 text-white' : 'bg-white text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-sm">
                {isAr ? 'إضافة حساب جديد' : 'Add New Account'}
              </h3>
              <button onClick={() => setShowAddAccountModal(false)} className="text-slate-400 hover:text-slate-600">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateAccount} className="pt-4 space-y-4">
              <div>
                <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                  {isAr ? 'اسم الحساب' : 'Account Name'}
                </label>
                <input
                  type="text"
                  value={newAccName}
                  onChange={(e) => setNewAccName(e.target.value)}
                  placeholder={isAr ? 'مثال: بنك المشرق، محفظة السفر' : 'e.g. Mashreq Bank, Travel Cash'}
                  className={`w-full p-2.5 rounded-2xl text-xs border outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200'
                  }`}
                  autoFocus
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                  {isAr ? 'نوع الحساب' : 'Account Type'}
                </label>
                <select
                  value={newAccType}
                  onChange={(e) => setNewAccType(e.target.value as any)}
                  className={`w-full p-2.5 rounded-2xl text-xs font-medium border outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <option value="bank">{isAr ? 'حساب بنكي جاري' : 'Bank Checking'}</option>
                  <option value="savings">{isAr ? 'حساب توفير واستثمار' : 'Savings & Investment'}</option>
                  <option value="wallet">{isAr ? 'محفظة نقدية (كاش)' : 'Cash Wallet'}</option>
                  <option value="credit">{isAr ? 'بطاقة ائتمانية' : 'Credit Card'}</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                  {isAr ? `الرصيد الافتتاحي (${settings.currency})` : `Opening Balance (${settings.currency})`}
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={newAccBalance}
                  onChange={(e) => setNewAccBalance(e.target.value)}
                  placeholder="0.00"
                  className={`w-full p-2.5 rounded-2xl text-sm font-bold tabular-nums border outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200'
                  }`}
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-emerald-600 text-white font-bold text-xs shadow-md shadow-emerald-700/20 active:scale-[0.98]"
              >
                {isAr ? 'حفظ الحساب' : 'Save Account'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
