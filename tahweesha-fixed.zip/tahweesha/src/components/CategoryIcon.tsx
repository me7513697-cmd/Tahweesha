import React from 'react';
import {
  Utensils,
  Home,
  ShoppingBag,
  Car,
  HeartPulse,
  Sparkles,
  Briefcase,
  TrendingUp,
  ArrowLeftRight,
  MoreHorizontal,
  Building2,
  Wallet,
  PiggyBank,
  Plane,
  ShieldCheck,
  Zap,
  Tv,
  Wifi,
  CreditCard,
} from 'lucide-react';

interface CategoryIconProps {
  iconName: string;
  color?: string;
  size?: number;
  className?: string;
  containerSize?: string; // e.g. "w-10 h-10"
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({
  iconName,
  color,
  size = 20,
  className = '',
  containerSize = 'w-11 h-11',
}) => {
  const getIcon = () => {
    switch (iconName) {
      case 'Utensils':
        return <Utensils size={size} />;
      case 'Home':
        return <Home size={size} />;
      case 'ShoppingBag':
        return <ShoppingBag size={size} />;
      case 'Car':
        return <Car size={size} />;
      case 'HeartPulse':
        return <HeartPulse size={size} />;
      case 'Sparkles':
        return <Sparkles size={size} />;
      case 'Briefcase':
        return <Briefcase size={size} />;
      case 'TrendingUp':
        return <TrendingUp size={size} />;
      case 'ArrowLeftRight':
        return <ArrowLeftRight size={size} />;
      case 'Building2':
        return <Building2 size={size} />;
      case 'Wallet':
        return <Wallet size={size} />;
      case 'PiggyBank':
        return <PiggyBank size={size} />;
      case 'Plane':
        return <Plane size={size} />;
      case 'ShieldCheck':
        return <ShieldCheck size={size} />;
      case 'Zap':
        return <Zap size={size} />;
      case 'Tv':
        return <Tv size={size} />;
      case 'Wifi':
        return <Wifi size={size} />;
      case 'CreditCard':
        return <CreditCard size={size} />;
      default:
        return <MoreHorizontal size={size} />;
    }
  };

  // If containerSize is provided, render circular container like reference design
  if (containerSize) {
    const bgColor = color ? `${color}18` : '#f1f5f9';
    const textColor = color || '#0f172a';

    return (
      <div
        className={`${containerSize} rounded-full flex items-center justify-center shrink-0 transition-transform ${className}`}
        style={{
          backgroundColor: bgColor,
          color: textColor,
        }}
      >
        {getIcon()}
      </div>
    );
  }

  return <span style={{ color }}>{getIcon()}</span>;
};
