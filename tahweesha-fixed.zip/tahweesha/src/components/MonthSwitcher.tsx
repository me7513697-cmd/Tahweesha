import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { formatMonthLabel, shiftMonth } from '../utils/financialMath';

interface MonthSwitcherProps {
  month: string; // YYYY-MM
  onChange: (month: string) => void;
  isAr: boolean;
  className?: string;
}

/** Previous / next month control. Works in both RTL and LTR. */
export const MonthSwitcher: React.FC<MonthSwitcherProps> = ({ month, onChange, isAr, className = '' }) => (
  <div
    className={`flex items-center gap-1 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700/50 px-1 py-0.5 ${className}`}
  >
    <button
      onClick={() => onChange(shiftMonth(month, -1))}
      className="p-1 rounded-full text-slate-500 hover:text-slate-900 dark:hover:text-white"
      aria-label={isAr ? 'الشهر السابق' : 'Previous month'}
    >
      <ChevronRight size={14} className={isAr ? '' : 'rotate-180'} />
    </button>
    <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 min-w-[84px] text-center tabular-nums">
      {formatMonthLabel(month, isAr ? 'ar' : 'en')}
    </span>
    <button
      onClick={() => onChange(shiftMonth(month, 1))}
      className="p-1 rounded-full text-slate-500 hover:text-slate-900 dark:hover:text-white"
      aria-label={isAr ? 'الشهر التالي' : 'Next month'}
    >
      <ChevronLeft size={14} className={isAr ? '' : 'rotate-180'} />
    </button>
  </div>
);
