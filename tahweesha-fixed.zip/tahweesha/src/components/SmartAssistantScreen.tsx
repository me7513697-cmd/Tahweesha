import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, Sparkles, User, HelpCircle } from 'lucide-react';
import { Transaction, Category, AppSettings, MonthlyFinancialSummary } from '../types/finance';
import { formatCurrency, formatMonthLabel } from '../utils/financialMath';
import { storage } from '../services/storage';

interface SmartAssistantScreenProps {
  summary: MonthlyFinancialSummary;
  totalBalance: number;
  transactions: Transaction[];
  categories: Category[];
  settings: AppSettings;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

const nowLabel = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

export const SmartAssistantScreen: React.FC<SmartAssistantScreenProps> = ({
  summary,
  totalBalance,
  transactions,
  categories,
  settings,
}) => {
  const isDark = settings.theme === 'dark';
  const isAr = settings.language === 'ar';
  const money = (v: number) => formatCurrency(v, settings.currency, settings.language);

  const [inputQuestion, setInputQuestion] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: isAr
        ? 'أهلاً! أنا مساعدك المالي المحلي. أجيب من بياناتك المسجلة على جهازك فقط. جرّب أحد الأسئلة السريعة بالأعلى.'
        : 'Hi! I am your on-device financial assistant. I answer only from the data stored on your device. Try one of the quick questions above.',
      timestamp: nowLabel(),
    },
  ]);
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (messages.length > 1) endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages.length]);

  const quickQuestions = [
    isAr ? 'ما هو ملخص وضعي المالي اليوم؟' : 'What is my financial summary today?',
    isAr ? 'كم المتبقي من ميزانية الشهر؟' : 'How much budget is left this month?',
    isAr ? 'ما هي أكبر فئة استهلكت أموالي؟' : 'What is my highest spending category?',
    isAr ? 'كم صرفت على المطاعم؟' : 'How much did I spend on dining?',
    isAr ? 'هل كشف حساب البنك متطابق؟' : 'Is my bank statement reconciled?',
  ];

  const buildReply = (query: string): string => {
    const q = query.toLowerCase();
    const monthLabel = formatMonthLabel(summary.month, settings.language);

    if (q.includes('مطعم') || q.includes('مطاعم') || q.includes('dining') || q.includes('restaurant')) {
      const d = summary.categoryBreakdown.find((c) => c.category.id === 'cat_dining');
      if (!d) {
        return isAr ? `لا توجد مصاريف مطاعم مسجلة في ${monthLabel}.` : `No dining expenses recorded in ${monthLabel}.`;
      }
      return isAr
        ? `صرفت على المطاعم ${money(d.amount)} في ${monthLabel}، أي ${d.percentage}% من إجمالي مصاريفك.`
        : `You spent ${money(d.amount)} on dining in ${monthLabel} (${d.percentage}% of total expenses).`;
    }

    if (q.includes('ملخص') || q.includes('summary')) {
      const flow = summary.netCashFlow;
      return isAr
        ? `رصيدك الإجمالي الحالي ${money(totalBalance)}. في ${monthLabel}: الدخل ${money(summary.totalIncome)} والمصاريف ${money(summary.totalExpenses)}، بصافي تدفق ${flow >= 0 ? 'إيجابي' : 'سلبي'} قدره ${money(Math.abs(flow))}.`
        : `Your current balance is ${money(totalBalance)}. In ${monthLabel}: income ${money(summary.totalIncome)}, expenses ${money(summary.totalExpenses)}, net cash flow ${flow >= 0 ? '+' : '-'}${money(Math.abs(flow))}.`;
    }

    if (q.includes('ميزانية') || q.includes('budget')) {
      const left = summary.totalBudget - summary.budgetSpent;
      if (left < 0) {
        return isAr
          ? `تجاوزت ميزانية ${monthLabel} بمبلغ ${money(Math.abs(left))} (الميزانية ${money(summary.totalBudget)}).`
          : `You are over the ${monthLabel} budget by ${money(Math.abs(left))} (budget ${money(summary.totalBudget)}).`;
      }
      const status =
        summary.budgetProgressPct >= 80
          ? isAr ? 'اقتربت من الحد، انتبه.' : 'You are close to the limit.'
          : isAr ? 'أنت ضمن المعدل الآمن.' : 'You are within a safe range.';
      return isAr
        ? `المتبقي من ميزانية ${monthLabel} هو ${money(left)} (استهلكت ${summary.budgetProgressPct}%). ${status}`
        : `${money(left)} remains of the ${monthLabel} budget (${summary.budgetProgressPct}% used). ${status}`;
    }

    if (q.includes('فئة') || q.includes('category') || q.includes('أكبر') || q.includes('highest')) {
      const top = summary.categoryBreakdown[0];
      if (!top) {
        return isAr ? `لا توجد مصاريف مسجلة في ${monthLabel}.` : `No expenses recorded in ${monthLabel}.`;
      }
      return isAr
        ? `أكبر فئة إنفاق في ${monthLabel} هي «${top.category.nameAr}» بمبلغ ${money(top.amount)} وتمثل ${top.percentage}% من مصاريفك.`
        : `Your highest spending category in ${monthLabel} is "${top.category.nameEn}" with ${money(top.amount)} (${top.percentage}%).`;
    }

    if (q.includes('مطابق') || q.includes('reconcil')) {
      const batch = storage.getImportBatches()[0];
      if (!batch) {
        return isAr
          ? 'لم تستورد أي كشف حساب بعد، لذلك لا يمكنني التحقق من المطابقة. استورد كشفاً من قائمة المزيد.'
          : 'You have not imported a bank statement yet, so there is nothing to reconcile. Import one from the More menu.';
      }
      return batch.isReconciled
        ? isAr
          ? `آخر كشف مستورد (${batch.fileName}) مطابق لرصيده الختامي.`
          : `Your last imported statement (${batch.fileName}) matches its closing balance.`
        : isAr
        ? `آخر كشف مستورد (${batch.fileName}) به فرق ${money(Math.abs(batch.reconciliationDifference ?? 0))} عن الرصيد الختامي. راجع العمليات المستوردة.`
        : `Your last imported statement (${batch.fileName}) differs from its closing balance by ${money(Math.abs(batch.reconciliationDifference ?? 0))}. Review the imported transactions.`;
    }

    return isAr
      ? `لديك ${transactions.length} عملية محفوظة، ومعدل ادخارك في ${monthLabel} هو ${summary.savingsRate}%. اسألني عن الملخص أو الميزانية أو أكبر فئة إنفاق أو المطاعم أو مطابقة الكشف.`
      : `You have ${transactions.length} saved transactions and a ${summary.savingsRate}% savings rate in ${monthLabel}. Ask me about your summary, budget, top category, dining, or statement reconciliation.`;
  };

  const handleSend = (textToSend?: string) => {
    const query = (textToSend || inputQuestion).trim();
    if (!query) return;

    setMessages((prev) => [
      ...prev,
      { id: `usr_${Date.now()}`, sender: 'user', text: query, timestamp: nowLabel() },
    ]);
    if (!textToSend) setInputQuestion('');

    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        { id: `bot_${Date.now()}`, sender: 'assistant', text: buildReply(query), timestamp: nowLabel() },
      ]);
    }, 300);
  };

  return (
    <div className="flex flex-col gap-4 pb-28">
      {/* Top Header */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center">
            <Sparkles size={16} />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              {isAr ? 'المساعد الذكي' : 'Smart Assistant'}
            </h1>
            <p className="text-[11px] text-slate-400">
              {isAr ? 'تحليل فوري لبياناتك المالية محلياً' : 'Local financial analytics & insights'}
            </p>
          </div>
        </div>
      </div>

      {/* Quick Prompt Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {quickQuestions.map((q, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(q)}
            className={`px-3 py-1.5 rounded-full text-[11px] font-semibold whitespace-nowrap border shrink-0 transition-all ${
              isDark
                ? 'bg-slate-800/80 hover:bg-slate-700 border-slate-700 text-slate-300'
                : 'bg-white hover:bg-emerald-50 border-slate-200 text-slate-700 shadow-sm'
            }`}
          >
            {q}
          </button>
        ))}
      </div>

      {/* Chat Messages Feed matching reference styling */}
      <div
        className={`rounded-3xl p-4 sm:p-5 flex-1 min-h-[380px] space-y-4 ${
          isDark ? 'glass-card-dark' : 'glass-card-light'
        }`}
      >
        {messages.map((m) => {
          const isUser = m.sender === 'user';

          return (
            <div
              key={m.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} max-w-[85%] ${
                isUser ? 'mr-0 ml-auto' : 'ml-0 mr-auto'
              }`}
            >
              <div
                className={`p-3.5 rounded-2xl text-xs sm:text-sm font-medium leading-relaxed shadow-sm ${
                  isUser
                    ? 'bg-emerald-600 text-white rounded-br-none'
                    : isDark
                    ? 'bg-slate-800 text-slate-100 rounded-bl-none border border-slate-700/60'
                    : 'bg-slate-100 text-slate-800 rounded-bl-none border border-slate-200/50'
                }`}
              >
                {m.text}
              </div>
              <span className="text-[10px] text-slate-400 px-1 mt-1">{m.timestamp}</span>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>

      {/* Chat Input Box matching reference */}
      <div
        className={`flex items-center gap-2 p-2 rounded-2xl ${
          isDark ? 'glass-card-dark' : 'glass-card-light'
        }`}
      >
        <input
          type="text"
          value={inputQuestion}
          onChange={(e) => setInputQuestion(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleSend();
          }}
          placeholder={isAr ? 'اكتب سؤالك المالي...' : 'Ask your financial question...'}
          className="flex-1 bg-transparent px-3 py-2 text-xs sm:text-sm outline-none text-slate-900 dark:text-white placeholder-slate-400"
        />

        <button
          onClick={() => handleSend()}
          className="w-10 h-10 rounded-xl flex items-center justify-center text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shrink-0"
        >
          <Send size={16} className={isAr ? 'rotate-180' : ''} />
        </button>
      </div>
    </div>
  );
};
