import React, { useState, useRef } from 'react';
import {
  Globe,
  Coins,
  Moon,
  Sun,
  ShieldCheck,
  Download,
  Upload,
  RefreshCw,
  Trash2,
  Info,
  ChevronLeft,
  ChevronRight,
  Fingerprint,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { AppSettings } from '../types/finance';
import { storage } from '../services/storage';
import { todayISO } from '../utils/financialMath';

interface SettingsScreenProps {
  settings: AppSettings;
  onUpdateSettings: (partial: Partial<AppSettings>) => void;
  onResetDemo: () => void;
  onClearAll: () => void;
  onRequestBiometricTest: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  settings,
  onUpdateSettings,
  onResetDemo,
  onClearAll,
  onRequestBiometricTest,
}) => {
  const isDark = settings.theme === 'dark';
  const isAr = settings.language === 'ar';

  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [showExportSuccess, setShowExportSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  /** Save a file: share sheet on phones (WebView blob downloads are unreliable), download elsewhere. */
  const saveFile = async (name: string, mime: string, content: string) => {
    const file = new File([content], name, { type: mime });
    try {
      const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
      if (nav.canShare && nav.canShare({ files: [file] }) && /android|iphone|ipad/i.test(navigator.userAgent)) {
        await nav.share({ files: [file], title: name });
        return;
      }
    } catch (err) {
      if ((err as Error)?.name === 'AbortError') return; // user closed the share sheet
    }
    const url = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const flashSuccess = () => {
    setShowExportSuccess(true);
    setTimeout(() => setShowExportSuccess(false), 2500);
  };

  const handleExportJSON = async () => {
    await saveFile(`tahweesha_backup_${todayISO()}.json`, 'application/json', storage.exportBackupJSON());
    flashSuccess();
  };

  const handleExportCSV = async () => {
    await saveFile(`tahweesha_transactions_${todayISO()}.csv`, 'text/csv;charset=utf-8', storage.exportTransactionsCSV());
    flashSuccess();
  };

  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow restoring the same file twice
    if (!file) return;

    try {
      const text = await file.text();
      const success = storage.restoreBackupJSON(text);
      if (success) {
        alert(isAr ? 'تمت استعادة النسخة الاحتياطية بنجاح!' : 'Backup restored successfully!');
      } else {
        alert(isAr ? 'ملف النسخة الاحتياطية غير صالح' : 'Invalid backup file');
      }
    } catch {
      alert(isAr ? 'حدث خطأ أثناء قراءة الملف' : 'Error reading file');
    }
  };

  return (
    <div className="flex flex-col gap-5 pb-28">
      {/* Top Header */}
      <div className="flex items-center justify-between px-1">
        <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          {isAr ? 'الإعدادات' : 'Settings'}
        </h1>
      </div>

      {/* User Profile Card matching reference */}
      <div
        className={`p-4 rounded-3xl flex items-center justify-between ${
          isDark ? 'glass-card-dark' : 'glass-card-light'
        }`}
      >
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full ring-2 ring-emerald-500/30 flex items-center justify-center text-white font-bold text-lg bg-gradient-to-br from-emerald-500 to-teal-600 shrink-0">
            {(settings.userName || 'ت').trim().charAt(0).toUpperCase()}
          </div>
          <div>
            <input
              type="text"
              value={settings.userName || ''}
              onChange={(e) => onUpdateSettings({ userName: e.target.value })}
              placeholder={isAr ? 'اكتب اسمك' : 'Your name'}
              maxLength={30}
              className="text-sm font-bold bg-transparent outline-none text-slate-900 dark:text-white placeholder-slate-400 w-40"
            />
            <div className="text-xs text-slate-400 mt-0.5">
              {isAr ? 'حسابك محلي على هذا الجهاز' : 'Local profile on this device'}
            </div>
          </div>
        </div>

        <div className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
          {isAr ? 'محلي ومحمي' : 'Local & Secure'}
        </div>
      </div>

      {/* Preferences Section */}
      <div
        className={`rounded-3xl divide-y ${
          isDark ? 'glass-card-dark divide-slate-800' : 'glass-card-light divide-slate-100'
        } overflow-hidden`}
      >
        {/* Language Selection */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-500 flex items-center justify-center">
              <Globe size={18} />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                {isAr ? 'اللغة' : 'Language'}
              </div>
              <div className="text-[11px] text-slate-400">
                {settings.language === 'ar' ? 'العربية (RTL)' : 'English (LTR)'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
            <button
              onClick={() => onUpdateSettings({ language: 'ar' })}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all ${
                settings.language === 'ar'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-400'
              }`}
            >
              العربية
            </button>
            <button
              onClick={() => onUpdateSettings({ language: 'en' })}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all ${
                settings.language === 'en'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-400'
              }`}
            >
              English
            </button>
          </div>
        </div>

        {/* Currency Selection */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
              <Coins size={18} />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                {isAr ? 'العملة الافتراضية' : 'Default Currency'}
              </div>
              <div className="text-[11px] text-slate-400">
                {{
                  AED: isAr ? 'الدرهم الإماراتي (AED)' : 'UAE Dirham (AED)',
                  USD: isAr ? 'الدولار الأمريكي (USD)' : 'US Dollar (USD)',
                  EUR: isAr ? 'اليورو (EUR)' : 'Euro (EUR)',
                  SAR: isAr ? 'الريال السعودي (SAR)' : 'Saudi Riyal (SAR)',
                  EGP: isAr ? 'الجنيه المصري (EGP)' : 'Egyptian Pound (EGP)',
                }[settings.currency]}
              </div>
            </div>
          </div>

          <select
            value={settings.currency}
            onChange={(e) => onUpdateSettings({ currency: e.target.value as any })}
            className={`p-2 rounded-xl text-xs font-bold border outline-none ${
              isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <option value="AED">AED (د.إ)</option>
            <option value="USD">USD ($)</option>
            <option value="EUR">EUR (€)</option>
            <option value="SAR">SAR (ر.س)</option>
            <option value="EGP">EGP (ج.م)</option>
          </select>
        </div>

        {/* Theme Selection */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
              {isDark ? <Moon size={18} /> : <Sun size={18} />}
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                {isAr ? 'المظهر' : 'Appearance'}
              </div>
              <div className="text-[11px] text-slate-400">
                {settings.theme === 'dark'
                  ? isAr ? 'داكن زجاجي' : 'Dark Glass'
                  : isAr ? 'فاتح زجاجي' : 'Light Glass'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
            <button
              onClick={() => onUpdateSettings({ theme: 'light' })}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                settings.theme === 'light'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-400'
              }`}
            >
              {isAr ? 'فاتح' : 'Light'}
            </button>
            <button
              onClick={() => onUpdateSettings({ theme: 'dark' })}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                settings.theme === 'dark'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-400'
              }`}
            >
              {isAr ? 'داكن' : 'Dark'}
            </button>
          </div>
        </div>

        {/* Biometric App Lock */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-500 flex items-center justify-center">
              <Fingerprint size={18} />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                {isAr ? 'قفل التطبيق البيومتري' : 'Biometric App Lock'}
              </div>
              <div className="text-[11px] text-slate-400">
                {isAr ? 'بصمة الإصبع أو التعرف على الوجه' : 'Fingerprint or Face Unlock'}
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              const newVal = !settings.biometricEnabled;
              onUpdateSettings({ biometricEnabled: newVal });
              if (newVal) onRequestBiometricTest();
            }}
            className={`w-12 h-6 rounded-full transition-colors relative ${
              settings.biometricEnabled ? 'bg-emerald-600' : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                settings.biometricEnabled
                  ? isAr ? 'left-0.5' : 'right-0.5'
                  : isAr ? 'right-0.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Data & Backup Section */}
      <div
        className={`rounded-3xl divide-y ${
          isDark ? 'glass-card-dark divide-slate-800' : 'glass-card-light divide-slate-100'
        } overflow-hidden`}
      >
        {/* Export Backup JSON */}
        <div
          onClick={handleExportJSON}
          className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center">
              <Download size={18} />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                {isAr ? 'تصدير نسخة احتياطية (JSON)' : 'Export Backup (JSON)'}
              </div>
              <div className="text-[11px] text-slate-400">
                {isAr ? 'حفظ كامل السجلات في ملف محلي' : 'Save all records in local JSON'}
              </div>
            </div>
          </div>
          <ChevronLeft size={16} className={`text-slate-400 ${isAr ? '' : 'rotate-180'}`} />
        </div>

        {/* Export CSV */}
        <div
          onClick={handleExportCSV}
          className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
              <Download size={18} />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                {isAr ? 'تصدير المعاملات (CSV)' : 'Export Transactions (CSV)'}
              </div>
              <div className="text-[11px] text-slate-400">
                {isAr ? 'مناسب للجداول الحسابية وإكسل' : 'Spreadsheet compatible'}
              </div>
            </div>
          </div>
          <ChevronLeft size={16} className={`text-slate-400 ${isAr ? '' : 'rotate-180'}`} />
        </div>

        {/* Restore Backup */}
        <div
          onClick={() => fileInputRef.current?.click()}
          className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-sky-500/10 text-sky-500 flex items-center justify-center">
              <Upload size={18} />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                {isAr ? 'استعادة نسخة احتياطية' : 'Restore Backup'}
              </div>
              <div className="text-[11px] text-slate-400">
                {isAr ? 'تحميل بيانات من ملف JSON سابق' : 'Load from JSON backup'}
              </div>
            </div>
          </div>
          <ChevronLeft size={16} className={`text-slate-400 ${isAr ? '' : 'rotate-180'}`} />
        </div>

        {/* Reset Demo Data */}
        <div
          onClick={() => {
            if (confirm(isAr ? 'سيتم استبدال بياناتك الحالية ببيانات تجريبية. هل تريد المتابعة؟' : 'This replaces your current data with sample data. Continue?')) {
              onResetDemo();
            }
          }}
          className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <RefreshCw size={18} />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                {isAr ? 'استعادة بيانات العرض التوضيحي' : 'Reset to Demo Showcase'}
              </div>
              <div className="text-[11px] text-slate-400">
                {isAr ? 'استبدال بياناتك ببيانات تجريبية جاهزة' : 'Replace your data with sample data'}
              </div>
            </div>
          </div>
          <ChevronLeft size={16} className={`text-slate-400 ${isAr ? '' : 'rotate-180'}`} />
        </div>

        {/* Clear All Data */}
        <div
          onClick={() => setShowClearConfirm(true)}
          className="p-4 flex items-center justify-between cursor-pointer hover:bg-rose-50/50 dark:hover:bg-rose-950/20 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center">
              <Trash2 size={18} />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-rose-600 dark:text-rose-400">
                {isAr ? 'مسح كافة البيانات' : 'Delete All Data'}
              </div>
              <div className="text-[11px] text-slate-400">
                {isAr ? 'بدء سجلات مالية فارغة تماماً' : 'Clear all stored transactions'}
              </div>
            </div>
          </div>
          <ChevronLeft size={16} className={`text-slate-400 ${isAr ? '' : 'rotate-180'}`} />
        </div>
      </div>

      {/* Hidden file input for restore */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".json"
        onChange={handleRestoreFile}
        className="hidden"
      />

      {/* Export notification badge */}
      {showExportSuccess && (
        <div className="p-3 rounded-2xl bg-emerald-500 text-white text-xs font-bold text-center animate-in fade-in shadow-lg">
          {isAr ? '✓ تم تصدير الملف بنجاح وحفظه على جهازك' : '✓ Export file downloaded successfully'}
        </div>
      )}

      {/* Clear Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div
            className={`w-full max-w-sm rounded-3xl p-6 shadow-2xl ${
              isDark ? 'bg-slate-900 border border-slate-800 text-white' : 'bg-white text-slate-900'
            }`}
          >
            <div className="w-12 h-12 rounded-full bg-rose-500/10 text-rose-500 flex items-center justify-center mx-auto mb-3">
              <AlertTriangle size={24} />
            </div>
            <h3 className="font-bold text-center text-sm">
              {isAr ? 'هل أنت متأكد من مسح جميع البيانات؟' : 'Confirm Data Deletion?'}
            </h3>
            <p className="text-xs text-slate-400 text-center mt-1.5 leading-relaxed">
              {isAr
                ? 'سيتم حذف جميع المعاملات والميزانيات وسجلات كشوف الحساب نهائياً من هذا الجهاز.'
                : 'All transactions, budgets, and imported records will be permanently removed.'}
            </p>
            <div className="flex items-center gap-2 mt-5">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  onClearAll();
                  setShowClearConfirm(false);
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 text-white text-xs font-bold shadow-md shadow-rose-600/20"
              >
                {isAr ? 'نعم، امسح' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* About Box */}
      <div className="text-center py-4 space-y-1">
        <div className="text-xs font-bold text-slate-400">
          تحويشة · Tahweesha Personal Finance v1.0.0
        </div>
        <div className="text-[10px] text-slate-500">
          {isAr
            ? 'تطبيق مالي محلي خاص 100% · معالجة كشوف الحساب بدون خوادم خارجية'
            : '100% local-first personal finance app · Local statement processing'}
        </div>
      </div>
    </div>
  );
};
