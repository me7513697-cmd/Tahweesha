import React from 'react';

interface TahweeshaLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  showTagline?: boolean;
  className?: string;
  isDark?: boolean;
}

/** Brand lockup built from the official Tahweesha icon and wordmark images. */
export const TahweeshaLogo: React.FC<TahweeshaLogoProps> = ({
  size = 'md',
  showText = true,
  showTagline = false,
  className = '',
  isDark = false,
}) => {
  const iconPx = { sm: 34, md: 46, lg: 66, xl: 96 }[size];
  const wordmarkH = { sm: 26, md: 34, lg: 48, xl: 64 }[size];

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      <img
        src="/assets/brand/icon.png"
        alt="تحويشة"
        width={iconPx}
        height={iconPx}
        draggable={false}
        className="shrink-0 object-contain transition-transform hover:scale-105"
        style={{ width: iconPx, height: iconPx }}
      />

      {showText && (
        <div className="flex flex-col">
          <img
            src="/assets/brand/wordmark.png"
            alt="تحويشة"
            draggable={false}
            className="object-contain"
            style={{
              height: wordmarkH,
              width: 'auto',
              // the dark-green lettering needs a lift on dark backgrounds
              filter: isDark ? 'brightness(1.9) saturate(1.1)' : 'none',
            }}
          />
          {showTagline && (
            <span
              className={`text-[11px] font-medium ${isDark ? 'text-slate-400' : 'text-slate-500'}`}
            >
              خلي فلوسك في مكانها · تابع .. خطط .. حقق
            </span>
          )}
        </div>
      )}
    </div>
  );
};
