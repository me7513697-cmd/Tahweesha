import React, { useState, useMemo } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  PieChart,
  BarChart2,
  Calendar,
  DollarSign,
  ArrowUpRight,
  ArrowDownLeft,
} from 'lucide-react';
import { CategoryIcon } from './CategoryIcon';
import { Transaction, Category, AppSettings } from '../types/finance';
import { formatCurrency, roundTo2Decimals, calculateMonthlySummary, formatMonthLabel, shiftMonth } from '../utils/financialMath';

interface ReportsScreenProps {
  transactions: Transaction[];
  categories: Category[];
  settings: AppSettings;
  onChangeMonth: (month: string) => void;
}

export const ReportsScreen: React.FC<ReportsScreenProps> = ({
  transactions,
  categories,
  settings,
  onChangeMonth,
}) => {
  const isDark = settings.theme === 'dark';
  const isAr = settings.language === 'ar';

  const [periodType, setPeriodType] = useState<'monthly' | 'yearly'>('monthly');

  const monthKey = settings.currentMonth;
  const selectedYear = parseInt(monthKey.slice(0, 4), 10);
  const selectedMonthIndex = parseInt(monthKey.slice(5, 7), 10);

  const monthsArabic = [
    'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
  ];
  const monthsEnglish = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];

  const isYearly = periodType === 'yearly';
  const periodPrefix = isYearly ? String(selectedYear) : monthKey;

  const currentMonthLabel = isYearly
    ? String(selectedYear)
    : formatMonthLabel(monthKey, settings.language);

  // Summary for the period actually shown (month or whole year), always from real data
  const summary = useMemo(() => {
    if (!isYearly) return calculateMonthlySummary(monthKey, transactions, categories, []);
    // Yearly: aggregate by calling the monthly engine for each month
    const perMonth = Array.from({ length: 12 }, (_, i) =>
      calculateMonthlySummary(`${selectedYear}-${String(i + 1).padStart(2, '0')}`, transactions, categories, [])
    );
    const totalIncome = roundTo2Decimals(perMonth.reduce((a, m) => a + m.totalIncome, 0));
    const totalExpenses = roundTo2Decimals(perMonth.reduce((a, m) => a + m.totalExpenses, 0));
    const netCashFlow = roundTo2Decimals(totalIncome - totalExpenses);
    const byCat = new Map<string, { category: Category; amount: number }>();
    perMonth.forEach((m) =>
      m.categoryBreakdown.forEach((c) => {
        const prev = byCat.get(c.category.id);
        byCat.set(c.category.id, {
          category: c.category,
          amount: roundTo2Decimals((prev?.amount || 0) + c.amount),
        });
      })
    );
    const categoryBreakdown = [...byCat.values()]
      .map((c) => ({
        ...c,
        percentage: totalExpenses > 0 ? Math.round((c.amount / totalExpenses) * 100) : 0,
      }))
      .sort((x, y) => y.amount - x.amount);
    return {
      month: String(selectedYear),
      totalIncome,
      totalExpenses,
      netCashFlow,
      savingsRate:
        totalIncome > 0 ? Math.max(0, Math.min(100, Math.round((netCashFlow / totalIncome) * 100))) : 0,
      totalBudget: 0,
      budgetSpent: totalExpenses,
      remainingBudget: 0,
      budgetProgressPct: 0,
      incomeChangePct: 0,
      expenseChangePct: 0,
      hasPreviousIncome: false,
      hasPreviousExpenses: false,
      categoryBreakdown,
    };
  }, [isYearly, monthKey, selectedYear, transactions, categories]);

  const formatAmount = (val: number) => {
    return formatCurrency(val, settings.currency, settings.language);
  };

  const periodTxs = transactions.filter((tx) => tx.date.startsWith(periodPrefix));

  // Monthly: 7 day-buckets. Yearly: 12 month-buckets.
  const monthlyIntervals = [
    { label: '1', startDay: 1, endDay: 4 },
    { label: '5', startDay: 5, endDay: 9 },
    { label: '10', startDay: 10, endDay: 14 },
    { label: '15', startDay: 15, endDay: 19 },
    { label: '20', startDay: 20, endDay: 24 },
    { label: '25', startDay: 25, endDay: 29 },
    { label: '31', startDay: 30, endDay: 31 },
  ];

  const chartData = isYearly
    ? Array.from({ length: 12 }, (_, i) => {
        let income = 0;
        let expense = 0;
        const prefix = `${selectedYear}-${String(i + 1).padStart(2, '0')}`;
        periodTxs.forEach((tx) => {
          if (!tx.date.startsWith(prefix)) return;
          if (tx.type === 'income') income += tx.amount;
          else if (tx.type === 'expense') expense += tx.amount;
        });
        return { label: (isAr ? monthsArabic[i] : monthsEnglish[i]).slice(0, 3), income, expense };
      })
    : monthlyIntervals.map((interval) => {
        let income = 0;
        let expense = 0;
        periodTxs.forEach((tx) => {
          const day = parseInt(tx.date.split('-')[2], 10);
          if (day >= interval.startDay && day <= interval.endDay) {
            if (tx.type === 'income') income += tx.amount;
            else if (tx.type === 'expense') expense += tx.amount;
          }
        });
        return { label: interval.label, income, expense };
      });

  // Scale to the data itself so small months are not flattened
  const maxChartValue = Math.max(...chartData.map((d) => Math.max(d.income, d.expense)), 1);
  const barHeight = (v: number) => (v <= 0 ? 0 : Math.max(4, (v / maxChartValue) * 130));

  // Top Merchants / Narratives
  const topMerchants = useMemo(() => {
    const map: Record<string, number> = {};
    periodTxs
      .filter((t) => t.type === 'expense')
      .forEach((t) => {
        const desc = t.description;
        map[desc] = roundTo2Decimals((map[desc] || 0) + t.amount);
      });

    return Object.entries(map)
      .map(([merchant, amount]) => ({ merchant, amount }))
      .sort((a, b) => b.amount - a.amount)
      .slice(0, 5);
  }, [periodTxs]);

  return (
    <div className="flex flex-col gap-5 pb-28">
      {/* Top Bar with Period Toggle (شهري / سنوي) matching reference */}
      <div className="flex items-center justify-between px-1">
        <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          {isAr ? 'التقارير' : 'Reports'}
        </h1>

        {/* Segmented Period Switch */}
        <div
          className={`p-1 rounded-2xl flex items-center gap-1 ${
            isDark ? 'bg-slate-900 border border-slate-800' : 'bg-slate-100 border border-slate-200/60'
          }`}
        >
          <button
            onClick={() => setPeriodType('yearly')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all ${
              periodType === 'yearly'
                ? isDark
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            {isAr ? 'سنوي' : 'Yearly'}
          </button>
          <button
            onClick={() => setPeriodType('monthly')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all ${
              periodType === 'monthly'
                ? isDark
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            {isAr ? 'شهري' : 'Monthly'}
          </button>
        </div>
      </div>

      {/* Month Navigator: < أكتوبر 2025 > */}
      <div
        className={`flex items-center justify-between p-3 rounded-2xl ${
          isDark ? 'glass-card-dark' : 'glass-card-light'
        }`}
      >
        <button
          onClick={() => {
            onChangeMonth(
              isYearly
                ? `${selectedYear - 1}-${String(selectedMonthIndex).padStart(2, '0')}`
                : shiftMonth(monthKey, -1)
            );
          }}
          className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
          aria-label="Previous month"
        >
          <ChevronRight size={18} className={isAr ? '' : 'rotate-180'} />
        </button>

        <span className="text-sm font-bold text-slate-900 dark:text-white">
          {currentMonthLabel}
        </span>

        <button
          onClick={() => {
            onChangeMonth(
              isYearly
                ? `${selectedYear + 1}-${String(selectedMonthIndex).padStart(2, '0')}`
                : shiftMonth(monthKey, 1)
            );
          }}
          className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
          aria-label="Next month"
        >
          <ChevronLeft size={18} className={isAr ? '' : 'rotate-180'} />
        </button>
      </div>

      {/* Net Cash Flow & Savings Summary Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div
          className={`p-4 rounded-3xl ${
            isDark ? 'glass-card-dark' : 'glass-card-light'
          }`}
        >
          <div className="text-xs text-slate-400 font-medium">
            {isAr ? 'صافي التدفق المالي' : 'Net Cash Flow'}
          </div>
          <div
            className={`text-lg font-extrabold tabular-nums mt-1 ${
              summary.netCashFlow >= 0
                ? 'text-emerald-600 dark:text-emerald-400'
                : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            {summary.netCashFlow >= 0 ? '+ ' : '- '}
            {formatAmount(Math.abs(summary.netCashFlow))}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            {isAr ? 'فائض نقدي متاح للادخار' : 'Available surplus for savings'}
          </div>
        </div>

        <div
          className={`p-4 rounded-3xl ${
            isDark ? 'glass-card-dark' : 'glass-card-light'
          }`}
        >
          <div className="text-xs text-slate-400 font-medium">
            {isAr ? 'معدل الادخار' : 'Savings Rate'}
          </div>
          <div className="text-lg font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400 mt-1">
            {summary.savingsRate}%
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            {isYearly ? (isAr ? 'من إجمالي دخل السنة' : 'of total yearly income') : isAr ? 'من إجمالي الدخل الشهري' : 'of total monthly income'}
          </div>
        </div>
      </div>

      {/* Bar Chart: Spending & Income Summary matching reference */}
      <div
        className={`p-5 rounded-3xl ${
          isDark ? 'glass-card-dark' : 'glass-card-light'
        }`}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            {isAr ? 'ملخص الإنفاق والدخل' : 'Spending & Income Breakdown'}
          </h2>

          {/* Chart Legend */}
          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="text-slate-500 dark:text-slate-400">{isAr ? 'الدخل' : 'Income'}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-rose-400" />
              <span className="text-slate-500 dark:text-slate-400">{isAr ? 'المصاريف' : 'Expenses'}</span>
            </div>
          </div>
        </div>

        {/* Bar Chart Canvas / SVG */}
        <div className="h-44 w-full flex items-end justify-between gap-2 pt-6 pb-2 border-b border-slate-100 dark:border-slate-800">
          {chartData.map((d, idx) => {
            const incomeHeight = barHeight(d.income);
            const expenseHeight = barHeight(d.expense);

            return (
              <div key={idx} className="flex-1 flex flex-col items-center gap-1 h-full justify-end">
                <div className="w-full flex items-end justify-center gap-1 h-full">
                  {/* Income bar */}
                  <div
                    className="w-2 sm:w-2.5 rounded-t-full bg-emerald-500 transition-all duration-500 hover:brightness-110"
                    style={{ height: `${incomeHeight}px` }}
                    title={`${isAr ? 'دخل' : 'Income'}: ${formatAmount(d.income)}`}
                  />
                  {/* Expense bar */}
                  <div
                    className="w-2 sm:w-2.5 rounded-t-full bg-rose-400 transition-all duration-500 hover:brightness-110"
                    style={{ height: `${expenseHeight}px` }}
                    title={`${isAr ? 'مصروف' : 'Expense'}: ${formatAmount(d.expense)}`}
                  />
                </div>
                <span className="text-[10px] text-slate-400 font-medium tabular-nums mt-1">
                  {d.label}
                </span>
              </div>
            );
          })}
        </div>

        <div className="flex justify-between items-center text-[10px] text-slate-400 dark:text-slate-500 pt-2">
          <span>{isYearly ? (isAr ? 'أشهر السنة' : 'Months of year') : isAr ? 'أيام الشهر' : 'Days of month'}</span>
          <span>{isAr ? `المبالغ بعملة ${settings.currency}` : `Amounts in ${settings.currency}`}</span>
        </div>
      </div>

      {/* Top Spending Categories ranked list matching reference */}
      <div
        className={`p-5 rounded-3xl ${
          isDark ? 'glass-card-dark' : 'glass-card-light'
        }`}
      >
        <h2 className="text-sm font-bold text-slate-900 dark:text-white mb-4">
          {isAr ? 'أكثر الفئات إنفاقاً' : 'Top Spending Categories'}
        </h2>

        {summary.categoryBreakdown.length === 0 && (
          <p className="text-xs text-slate-400 text-center py-4">
            {isAr ? 'لا توجد مصاريف في هذه الفترة' : 'No expenses in this period'}
          </p>
        )}
        <div className="space-y-3">
          {summary.categoryBreakdown.map((item, idx) => (
            <div
              key={item.category.id}
              className={`flex items-center justify-between p-3 rounded-2xl ${
                isDark ? 'bg-slate-800/40' : 'bg-slate-50/70'
              }`}
            >
              <div className="flex items-center gap-3">
                <CategoryIcon iconName={item.category.icon} color={item.category.color} />
                <div>
                  <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                    {isAr ? item.category.nameAr : item.category.nameEn}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {item.percentage}% {isAr ? 'من إجمالي المصاريف' : 'of expenses'}
                  </div>
                </div>
              </div>

              <div className="text-left font-bold tabular-nums">
                <div className="text-xs sm:text-sm text-slate-900 dark:text-white">
                  {formatAmount(item.amount)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Top Merchants Breakdown */}
      {topMerchants.length > 0 && (
        <div
          className={`p-5 rounded-3xl ${
            isDark ? 'glass-card-dark' : 'glass-card-light'
          }`}
        >
          <h2 className="text-sm font-bold text-slate-900 dark:text-white mb-3">
            {isAr ? 'أعلى التجار إنفاقاً' : 'Top Merchants / Spends'}
          </h2>

          <div className="space-y-2">
            {topMerchants.map((m, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800 text-xs">
                <span className="font-semibold text-slate-800 dark:text-slate-200">{m.merchant}</span>
                <span className="font-bold tabular-nums text-rose-500">{formatAmount(m.amount)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
