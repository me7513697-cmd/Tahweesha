import React, { useState } from 'react';
import {
  Eye,
  EyeOff,
  Bell,
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  FileSpreadsheet,
  BarChart3,
  ChevronLeft,
  ChevronRight,
  ArrowLeftRight,
} from 'lucide-react';
import { TahweeshaLogo } from './TahweeshaLogo';
import { CategoryIcon } from './CategoryIcon';
import { Transaction, Account, Category, AppSettings, MonthlyFinancialSummary } from '../types/finance';
import { formatCurrency, formatMonthLabel } from '../utils/financialMath';
import { MonthSwitcher } from './MonthSwitcher';
import { storage } from '../services/storage';

interface HomeScreenProps {
  summary: MonthlyFinancialSummary;
  totalBalance: number;
  recentTransactions: Transaction[];
  categories: Category[];
  accounts: Account[];
  settings: AppSettings;
  onChangeMonth: (month: string) => void;
  onNavigate: (tab: 'home' | 'transactions' | 'reports' | 'budget' | 'more') => void;
  onOpenAddModal: (type?: 'expense' | 'income' | 'transfer') => void;
  onOpenImportModal: () => void;
  onToggleHideBalance: () => void;
  onSelectAccount: (accountId: string) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  summary,
  totalBalance,
  recentTransactions,
  categories,
  accounts,
  settings,
  onChangeMonth,
  onNavigate,
  onOpenAddModal,
  onOpenImportModal,
  onToggleHideBalance,
  onSelectAccount,
}) => {
  const isDark = settings.theme === 'dark';
  const isAr = settings.language === 'ar';
  const [showNotifications, setShowNotifications] = useState(false);

  const formatAmount = (val: number, showPlus = false) => {
    if (settings.hideBalance) return '••••••';
    return formatCurrency(val, settings.currency, settings.language, { showPlusSign: showPlus });
  };

  const getCategory = (catId: string) => {
    return (
      categories.find((c) => c.id === catId) || {
        id: catId,
        nameAr: 'أخرى',
        nameEn: 'Other',
        icon: 'MoreHorizontal',
        color: '#94a3b8',
        type: 'expense' as const,
      }
    );
  };

  // Real alerts derived from the current month's budget
  const alerts: { tone: 'warn' | 'danger'; text: string }[] = [];
  if (summary.budgetProgressPct >= 100) {
    alerts.push({
      tone: 'danger',
      text: isAr ? 'تجاوزت ميزانية هذا الشهر' : 'You exceeded this month\'s budget',
    });
  } else if (summary.budgetProgressPct >= 80) {
    alerts.push({
      tone: 'warn',
      text: isAr
        ? `وصلت إلى ${summary.budgetProgressPct}% من ميزانية الشهر`
        : `You have used ${summary.budgetProgressPct}% of this month's budget`,
    });
  }

  const lastBatch = storage.getImportBatches()[0];
  const sortedRecent = [...recentTransactions].sort((a, b) => b.date.localeCompare(a.date));

  // Donut chart stroke calculations
  const totalCategoryAmount = summary.categoryBreakdown.reduce((sum, item) => sum + item.amount, 0);
  const radius = 38;
  const circumference = 2 * Math.PI * radius;
  let accumulatedAngle = 0;

  return (
    <div className="flex flex-col gap-5 pb-24">
      {/* A. Top Header matching reference showcase */}
      <header className="flex items-center justify-between px-1 pt-1">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-11 h-11 rounded-full ring-2 ring-emerald-500/30 shadow-sm flex items-center justify-center text-white font-bold bg-gradient-to-br from-emerald-500 to-teal-600">
              {(settings.userName || 'ت').trim().charAt(0).toUpperCase()}
            </div>
          </div>
          <div>
            <h1
              className={`text-base font-bold tracking-tight ${
                isDark ? 'text-white' : 'text-slate-900'
              }`}
            >
              {settings.userName
                ? isAr ? `مرحباً ${settings.userName}` : `Welcome, ${settings.userName}`
                : isAr ? 'مرحباً بك' : 'Welcome'}
            </h1>
            <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              {isAr ? 'مستقبلك المالي بين إيديك' : 'Your financial future in your hands'}
            </p>
          </div>
        </div>

        {/* Center / Brand wordmark */}
        <TahweeshaLogo size="sm" showText={false} isDark={isDark} />

        {/* Actions: Notification bell */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-colors ${
              isDark
                ? 'bg-slate-800/80 text-slate-200 hover:bg-slate-800 border border-slate-700/60'
                : 'bg-white/80 text-slate-700 hover:bg-white shadow-sm border border-slate-200/60'
            }`}
            aria-label="Notifications"
          >
            <Bell size={19} />
            {alerts.length > 0 && (
              <span className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
            )}
          </button>

          {/* Simple notification popover */}
          {showNotifications && (
            <div
              className={`absolute ${
                isAr ? 'left-0' : 'right-0'
              } top-12 w-64 p-3 rounded-2xl z-50 shadow-xl ${
                isDark
                  ? 'bg-slate-900 border border-slate-800 text-slate-200'
                  : 'bg-white border border-slate-100 text-slate-800 shadow-slate-900/10'
              }`}
            >
              <div className="text-xs font-semibold mb-2 text-emerald-600 dark:text-emerald-400">
                {isAr ? 'التنبيهات المالية' : 'Financial Notifications'}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 space-y-2">
                {alerts.length === 0 && (
                  <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-800 dark:text-emerald-300">
                    {isAr ? 'لا توجد تنبيهات حالياً 👌' : 'No alerts right now 👌'}
                  </div>
                )}
                {alerts.map((a, i) => (
                  <div
                    key={i}
                    className={`p-2 rounded-lg ${
                      a.tone === 'danger'
                        ? 'bg-rose-500/10 text-rose-800 dark:text-rose-300'
                        : 'bg-amber-500/10 text-amber-800 dark:text-amber-300'
                    }`}
                  >
                    {a.text}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </header>

      {/* B. Total Balance Card (Frosted emerald-teal luxury card matching reference) */}
      <div
        className="relative overflow-hidden rounded-3xl p-6 text-white shadow-lg shadow-emerald-950/20"
        style={{
          background: 'linear-gradient(135deg, #047857 0%, #0d9488 50%, #065f46 100%)',
          border: '1px solid rgba(255, 255, 255, 0.25)',
        }}
      >
        {/* Subtle decorative geometric overlay */}
        <div
          className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full opacity-15 pointer-events-none"
          style={{
            background: 'radial-gradient(circle, rgba(255,255,255,0.8) 0%, transparent 70%)',
          }}
        />

        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-emerald-100/90 tracking-wide">
              {isAr ? 'رصيدك الحالي' : 'Current Balance'}
            </span>
            <button
              onClick={onToggleHideBalance}
              className="p-1 rounded-full text-emerald-200 hover:text-white hover:bg-white/10 transition-colors"
              title={settings.hideBalance ? 'إظهار الرصيد' : 'إخفاء الرصيد'}
            >
              {settings.hideBalance ? <EyeOff size={15} /> : <Eye size={15} />}
            </button>
          </div>

          {/* Account selector pill */}
          <select
            value={settings.selectedAccountId}
            onChange={(e) => onSelectAccount(e.target.value)}
            className="text-[11px] bg-white/20 text-white rounded-full px-2.5 py-1 border border-white/30 backdrop-blur-md outline-none cursor-pointer hover:bg-white/30 transition-colors"
          >
            <option value="all" className="text-slate-900 bg-white">
              {isAr ? 'جميع الحسابات' : 'All Accounts'}
            </option>
            {accounts.map((acc) => (
              <option key={acc.id} value={acc.id} className="text-slate-900 bg-white">
                {isAr ? acc.name : acc.nameEn}
              </option>
            ))}
          </select>
        </div>

        {/* Big Balance Number */}
        <div className="text-3xl sm:text-4xl font-extrabold tracking-tight tabular-nums mt-1 mb-3">
          {formatAmount(totalBalance)}
        </div>

        {/* Balance status / date indicator */}
        <div className="flex items-center justify-between text-[11px] text-emerald-100/80 pt-2 border-t border-white/15">
          <span className="flex items-center gap-1.5">
            <span
              className={`w-1.5 h-1.5 rounded-full animate-pulse ${
                !lastBatch ? 'bg-slate-300' : lastBatch.isReconciled ? 'bg-emerald-300' : 'bg-amber-300'
              }`}
            />
            {!lastBatch
              ? isAr ? 'لم يتم استيراد كشف حساب بعد' : 'No statement imported yet'
              : lastBatch.isReconciled
              ? isAr ? 'آخر كشف مستورد مطابق ✓' : 'Last import reconciled ✓'
              : isAr ? 'آخر كشف مستورد به فروقات' : 'Last import has a variance'}
          </span>
          <span>{formatMonthLabel(settings.currentMonth, settings.language)}</span>
        </div>
      </div>

      {/* C. Monthly Summary: Two Cards (Income and Expenses) */}
      <div className="grid grid-cols-2 gap-3">
        {/* Income Card (Soft Emerald) */}
        <div
          className={`rounded-3xl p-4 transition-all ${
            isDark
              ? 'bg-emerald-950/30 border border-emerald-800/40'
              : 'bg-emerald-50/80 border border-emerald-100/80 shadow-sm'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-emerald-700 dark:text-emerald-400 mb-1 font-medium">
            <span>{isAr ? 'إجمالي الدخل' : 'Total Income'}</span>
            <div className="w-6 h-6 rounded-full bg-emerald-500/15 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
              <ArrowDownLeft size={13} />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-bold tabular-nums text-slate-900 dark:text-white mt-1">
            {formatAmount(summary.totalIncome)}
          </div>
          <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 mt-2">
            <span>
              {summary.hasPreviousIncome
                ? `${summary.incomeChangePct >= 0 ? '↑ +' : '↓ '}${summary.incomeChangePct}%`
                : '—'}
            </span>
            <span className="text-slate-400 dark:text-slate-500 font-normal">
              {isAr ? 'عن الشهر الماضي' : 'vs last mo'}
            </span>
          </div>
        </div>

        {/* Expenses Card (Soft Coral / Rose) */}
        <div
          className={`rounded-3xl p-4 transition-all ${
            isDark
              ? 'bg-rose-950/30 border border-rose-800/40'
              : 'bg-rose-50/80 border border-rose-100/80 shadow-sm'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-rose-700 dark:text-rose-400 mb-1 font-medium">
            <span>{isAr ? 'إجمالي المصاريف' : 'Total Expenses'}</span>
            <div className="w-6 h-6 rounded-full bg-rose-500/15 flex items-center justify-center text-rose-600 dark:text-rose-400">
              <ArrowUpRight size={13} />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-bold tabular-nums text-slate-900 dark:text-white mt-1">
            {formatAmount(summary.totalExpenses)}
          </div>
          <div className="flex items-center gap-1 text-[11px] font-semibold text-rose-600 dark:text-rose-400 mt-2">
            <span>
              {summary.hasPreviousExpenses
                ? `${summary.expenseChangePct > 0 ? '↑ +' : '↓ '}${summary.expenseChangePct}%`
                : '—'}
            </span>
            <span className="text-slate-400 dark:text-slate-500 font-normal">
              {isAr ? 'عن الشهر الماضي' : 'vs last mo'}
            </span>
          </div>
        </div>
      </div>

      {/* D. Available to Spend Card matching reference */}
      <div
        className={`rounded-3xl p-4.5 ${
          isDark ? 'glass-card-dark' : 'glass-card-light'
        }`}
      >
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              {isAr ? 'المتاح للصرف هذا الشهر' : 'Available to spend this month'}
            </div>
            <div className="text-2xl font-extrabold tabular-nums text-slate-900 dark:text-white mt-1">
              {formatAmount(summary.remainingBudget)}
            </div>
          </div>
          <MonthSwitcher month={settings.currentMonth} onChange={onChangeMonth} isAr={isAr} />
        </div>

        {/* Progress bar */}
        <div className="mt-3">
          <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{
                width: `${Math.min(100, summary.budgetProgressPct)}%`,
                backgroundColor:
                  summary.budgetProgressPct > 90
                    ? '#ef4444'
                    : summary.budgetProgressPct > 75
                    ? '#f59e0b'
                    : '#10b981',
              }}
            />
          </div>
          <div className="flex justify-between items-center text-[10px] text-slate-400 dark:text-slate-500 mt-1.5">
            <span>
              {isAr
                ? `المصروف: ${formatAmount(summary.budgetSpent)}`
                : `Spent: ${formatAmount(summary.budgetSpent)}`}
            </span>
            <span>
              {isAr
                ? `الميزانية: ${formatAmount(summary.totalBudget)}`
                : `Budget: ${formatAmount(summary.totalBudget)}`}
            </span>
          </div>
        </div>
      </div>

      {/* E. Spending Breakdown by Category with Donut Chart */}
      <div
        className={`rounded-3xl p-5 ${
          isDark ? 'glass-card-dark' : 'glass-card-light'
        }`}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            {isAr ? 'المصاريف حسب الفئة' : 'Expenses by Category'}
          </h2>
          <button
            onClick={() => onNavigate('reports')}
            className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-0.5"
          >
            {isAr ? 'التقرير الكامل' : 'Full Report'}
            <ChevronLeft size={14} className={isAr ? '' : 'rotate-180'} />
          </button>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-6">
          {/* SVG Donut Ring */}
          <div className="relative w-32 h-32 shrink-0 flex items-center justify-center">
            <svg className="w-32 h-32 -rotate-90 transform" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r={radius}
                className="text-slate-100 dark:text-slate-800"
                strokeWidth="11"
                stroke="currentColor"
                fill="transparent"
              />
              {summary.categoryBreakdown.map((item) => {
                const strokeDasharray = `${(item.percentage / 100) * circumference} ${circumference}`;
                const strokeDashoffset = -((accumulatedAngle / 100) * circumference);
                accumulatedAngle += item.percentage;
                return (
                  <circle
                    key={item.category.id}
                    cx="50"
                    cy="50"
                    r={radius}
                    stroke={item.category.color}
                    strokeWidth="11"
                    strokeDasharray={strokeDasharray}
                    strokeDashoffset={strokeDashoffset}
                    strokeLinecap="round"
                    fill="transparent"
                    className="transition-all duration-700 ease-out"
                  />
                );
              })}
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">
                {isAr ? 'الإجمالي' : 'Total'}
              </span>
              <span className="text-xs font-bold text-slate-900 dark:text-white tabular-nums">
                {formatCurrency(totalCategoryAmount, settings.currency, settings.language, {
                  hideDecimals: true,
                })}
              </span>
            </div>
          </div>

          {/* Legend Grid matching reference */}
          <div className="grid grid-cols-2 gap-x-4 gap-y-2.5 w-full">
            {summary.categoryBreakdown.slice(0, 4).map((item) => (
              <div key={item.category.id} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 truncate">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ backgroundColor: item.category.color }}
                  />
                  <span className="text-slate-600 dark:text-slate-300 truncate">
                    {isAr ? item.category.nameAr : item.category.nameEn}
                  </span>
                </div>
                <span className="font-bold tabular-nums text-slate-900 dark:text-white shrink-0">
                  {item.percentage}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* F. Quick Actions Bar */}
      <div className="grid grid-cols-4 gap-2">
        <button
          onClick={() => onOpenAddModal('expense')}
          className={`flex flex-col items-center justify-center py-3 px-1 rounded-2xl transition-all ${
            isDark
              ? 'bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-200'
              : 'bg-white/80 hover:bg-white border border-slate-200/60 text-slate-700 shadow-sm'
          }`}
        >
          <div className="w-9 h-9 rounded-full bg-rose-500/10 text-rose-500 flex items-center justify-center mb-1.5">
            <ArrowUpRight size={18} />
          </div>
          <span className="text-[11px] font-semibold">{isAr ? 'مصروف' : 'Expense'}</span>
        </button>

        <button
          onClick={() => onOpenAddModal('income')}
          className={`flex flex-col items-center justify-center py-3 px-1 rounded-2xl transition-all ${
            isDark
              ? 'bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-200'
              : 'bg-white/80 hover:bg-white border border-slate-200/60 text-slate-700 shadow-sm'
          }`}
        >
          <div className="w-9 h-9 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center mb-1.5">
            <ArrowDownLeft size={18} />
          </div>
          <span className="text-[11px] font-semibold">{isAr ? 'إيراد' : 'Income'}</span>
        </button>

        <button
          onClick={onOpenImportModal}
          className={`flex flex-col items-center justify-center py-3 px-1 rounded-2xl transition-all ${
            isDark
              ? 'bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-200'
              : 'bg-white/80 hover:bg-white border border-slate-200/60 text-slate-700 shadow-sm'
          }`}
        >
          <div className="w-9 h-9 rounded-full bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center mb-1.5">
            <FileSpreadsheet size={18} />
          </div>
          <span className="text-[11px] font-semibold">{isAr ? 'استيراد كشف' : 'Import'}</span>
        </button>

        <button
          onClick={() => onNavigate('reports')}
          className={`flex flex-col items-center justify-center py-3 px-1 rounded-2xl transition-all ${
            isDark
              ? 'bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-200'
              : 'bg-white/80 hover:bg-white border border-slate-200/60 text-slate-700 shadow-sm'
          }`}
        >
          <div className="w-9 h-9 rounded-full bg-indigo-500/10 text-indigo-500 flex items-center justify-center mb-1.5">
            <BarChart3 size={18} />
          </div>
          <span className="text-[11px] font-semibold">{isAr ? 'التقارير' : 'Reports'}</span>
        </button>
      </div>

      {/* G. Recent Transactions matching reference layout */}
      <div
        className={`rounded-3xl p-5 ${
          isDark ? 'glass-card-dark' : 'glass-card-light'
        }`}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            {isAr ? 'العمليات الأخيرة' : 'Recent Transactions'}
          </h2>
          <button
            onClick={() => onNavigate('transactions')}
            className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-0.5"
          >
            {isAr ? 'عرض الكل' : 'View All'}
            <ChevronLeft size={14} className={isAr ? '' : 'rotate-180'} />
          </button>
        </div>

        {sortedRecent.length === 0 && (
          <p className="text-xs text-slate-400 text-center py-4">
            {isAr ? 'لا توجد عمليات بعد. اضغط على «مصروف» أو «إيراد» للبدء.' : 'No transactions yet. Tap Expense or Income to start.'}
          </p>
        )}
        <div className="space-y-3">
          {sortedRecent.slice(0, 6).map((tx) => {
            const cat = getCategory(tx.categoryId);
            const isIncome = tx.type === 'income';
            const isTransfer = tx.type === 'transfer';

            return (
              <div
                key={tx.id}
                onClick={() => onNavigate('transactions')}
                className={`flex items-center justify-between p-3 rounded-2xl cursor-pointer transition-colors ${
                  isDark
                    ? 'hover:bg-slate-800/60 border border-transparent hover:border-slate-800'
                    : 'hover:bg-slate-50/80 border border-transparent hover:border-slate-100'
                }`}
              >
                <div className="flex items-center gap-3">
                  <CategoryIcon
                    iconName={isTransfer ? 'ArrowLeftRight' : cat.icon}
                    color={isTransfer ? '#3b82f6' : cat.color}
                  />
                  <div>
                    <div className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white">
                      {tx.description}
                    </div>
                    <div className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
                      {isAr ? cat.nameAr : cat.nameEn}
                    </div>
                  </div>
                </div>

                <div className="text-left font-bold tabular-nums">
                  <div
                    className={`text-xs sm:text-sm ${
                      isIncome
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : isTransfer
                        ? 'text-blue-600 dark:text-blue-400'
                        : 'text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {isIncome ? '+ ' : '- '}
                    {formatAmount(tx.amount)}
                  </div>
                  <div className="text-[10px] text-slate-400 dark:text-slate-500 font-normal mt-0.5">
                    {tx.date.replace(/-/g, '/')}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
