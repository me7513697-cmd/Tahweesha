import React, { useState, useRef } from 'react';
import {
  FileText,
  FileSpreadsheet,
  FileCode,
  Upload,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ArrowLeft,
  Sliders,
  Check,
  X,
  HelpCircle,
  Sparkles,
  Info,
} from 'lucide-react';
import {
  StatementParseResult,
  processStatementMatrix,
  parseCSVText,
  parseExcelBuffer,
  SYNTHETIC_STATEMENTS,
} from '../services/statementParser';
import { extractPdfRows } from '../services/pdfExtract';
import { Transaction, Account, Category, AppSettings, ImportBatch } from '../types/finance';
import { formatCurrency, generateTransactionFingerprint } from '../utils/financialMath';

interface StatementImportScreenProps {
  accounts: Account[];
  categories: Category[];
  existingTransactions: Transaction[];
  settings: AppSettings;
  onClose: () => void;
  onImportComplete: (batch: ImportBatch, transactions: Transaction[]) => void;
}

export const StatementImportScreen: React.FC<StatementImportScreenProps> = ({
  accounts,
  categories,
  existingTransactions,
  settings,
  onClose,
  onImportComplete,
}) => {
  const isDark = settings.theme === 'dark';
  const isAr = settings.language === 'ar';

  const [step, setStep] = useState<'upload' | 'mapping' | 'preview' | 'reconcile'>('upload');
  const [targetAccountId, setTargetAccountId] = useState(accounts[0]?.id || 'acc_enbd');
  const [parseResult, setParseResult] = useState<StatementParseResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // File Upload Handler for real user files
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow picking the same file again
    if (!file) return;

    setLoading(true);
    const fileName = file.name;
    const extension = fileName.split('.').pop()?.toLowerCase();

    try {
      if (extension === 'csv' || extension === 'txt') {
        const text = await file.text();
        const matrix = parseCSVText(text);
        const result = processStatementMatrix(matrix, fileName, 'csv', existingTransactions);
        if (result.candidateRows.length === 0) {
          alert(isAr ? 'لم يتم العثور على معاملات في هذا الملف' : 'No transactions were found in this file');
        } else {
          setParseResult(result);
          setStep('preview');
        }
      } else if (extension === 'xlsx' || extension === 'xls') {
        const buffer = await file.arrayBuffer();
        const result = parseExcelBuffer(buffer, fileName, existingTransactions);
        if (result.candidateRows.length === 0) {
          alert(isAr ? 'لم يتم العثور على معاملات في هذا الملف' : 'No transactions were found in this file');
        } else {
          setParseResult(result);
          setStep('preview');
        }
      } else if (extension === 'pdf') {
        const matrix = await extractPdfRows(await file.arrayBuffer());
        const result = processStatementMatrix(matrix, fileName, 'pdf', existingTransactions);
        if (result.candidateRows.length === 0) {
          alert(
            isAr
              ? 'لم أتمكن من استخراج معاملات من ملف PDF. قد يكون الكشف صورة ممسوحة ضوئياً. جرّب تصدير الكشف بصيغة Excel أو CSV من تطبيق البنك.'
              : 'No transactions could be extracted from this PDF (it may be a scanned image). Try exporting the statement as Excel or CSV from your bank.'
          );
        } else {
          setParseResult(result);
          setStep('preview');
        }
      } else {
        alert(isAr ? 'صيغة الملف غير مدعومة. يرجى اختيار ملف CSV أو Excel أو PDF' : 'Unsupported format. Please select CSV, Excel, or PDF');
      }
    } catch (err) {
      console.error('File parsing error:', err);
      alert(isAr ? 'حدث خطأ أثناء قراءة الملف' : 'Error reading file');
    } finally {
      setLoading(false);
    }
  };

  // 1-Click Synthetic Bank Statements for Instant Testing
  const handleLoadSyntheticStatement = (type: 'emiratesNBD' | 'adcb' | 'ambiguous') => {
    setLoading(true);
    setTimeout(() => {
      let sampleData = SYNTHETIC_STATEMENTS.emiratesNBD_CSV;
      if (type === 'adcb') sampleData = SYNTHETIC_STATEMENTS.adcb_CSV;
      if (type === 'ambiguous') sampleData = SYNTHETIC_STATEMENTS.ambiguous_CSV;

      const matrix = parseCSVText(sampleData.data);
      const result = processStatementMatrix(matrix, sampleData.name, 'csv', existingTransactions);
      setParseResult(result);
      setStep('preview');
      setLoading(false);
    }, 250);
  };

  // Toggle selection for a row
  const toggleRowSelection = (rowIndex: number) => {
    if (!parseResult) return;
    const updated = parseResult.candidateRows.map((r) =>
      r.rowIndex === rowIndex ? { ...r, selected: !r.selected } : r
    );
    setParseResult({ ...parseResult, candidateRows: updated });
  };

  // Change category for candidate row
  const changeRowCategory = (rowIndex: number, newCatId: string) => {
    if (!parseResult) return;
    const updated = parseResult.candidateRows.map((r) =>
      r.rowIndex === rowIndex ? { ...r, suggestedCategoryId: newCatId } : r
    );
    setParseResult({ ...parseResult, candidateRows: updated });
  };

  // Confirm and Save Import
  const handleConfirmImport = () => {
    if (!parseResult) return;

    const selectedRows = parseResult.candidateRows.filter((r) => r.selected && r.isValid);
    if (selectedRows.length === 0) {
      alert(isAr ? 'يرجى تحديد عملية واحدة على الأقل للاستيراد' : 'Please select at least one transaction to import');
      return;
    }

    const batchId = `batch_${Date.now()}`;
    const transferDestination = accounts.find((a) => a.id !== targetAccountId)?.id;
    const newTransactions: Transaction[] = selectedRows.map((row) => ({
      id: `tx_imp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      date: row.normalizedDate,
      amount: row.amount,
      // A transfer needs a destination account; with a single account it is just an outflow
      type: row.type === 'transfer' && !transferDestination ? 'expense' : row.type,
      categoryId: row.suggestedCategoryId,
      accountId: targetAccountId,
      destinationAccountId: row.type === 'transfer' ? transferDestination : undefined,
      description: row.cleanedDescription,
      originalDescription: row.rawDescription,
      source: 'statement_import',
      importBatchId: batchId,
      status: row.isDuplicate ? 'uncertain' : 'reviewed',
      fingerprint: generateTransactionFingerprint(row.normalizedDate, row.amount, row.cleanedDescription),
      referenceNumber: row.referenceNumber,
    }));

    const batch: ImportBatch = {
      id: batchId,
      fileName: parseResult.fileName,
      fileType: parseResult.fileType,
      importedAt: new Date().toISOString(),
      totalRows: parseResult.candidateRows.length,
      acceptedCount: newTransactions.length,
      duplicateCount: parseResult.duplicateCount,
      skippedCount: parseResult.candidateRows.length - newTransactions.length,
      openingBalance: parseResult.openingBalance,
      closingBalance: parseResult.closingBalance,
      calculatedClosingBalance: parseResult.calculatedClosingBalance,
      isReconciled: parseResult.isReconciled,
      reconciliationDifference: parseResult.reconciliationDifference,
    };

    onImportComplete(batch, newTransactions);
    // Reset so a second tap (or reopening from the More menu) can never import the same rows twice
    setParseResult(null);
    setStep('upload');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-md animate-in fade-in">
      <div
        className={`w-full max-w-xl max-h-[92vh] flex flex-col rounded-3xl shadow-2xl overflow-hidden transition-all ${
          isDark ? 'bg-slate-900 border border-slate-800 text-white' : 'bg-white text-slate-900'
        }`}
      >
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => {
                if (step === 'preview') setStep('upload');
                else onClose();
              }}
              className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 transition-colors"
            >
              {isAr ? <ArrowRight size={18} /> : <ArrowLeft size={18} />}
            </button>
            <h2 className="text-base font-bold">
              {isAr ? 'استيراد كشف الحساب' : 'Import Bank Statement'}
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowHelpModal(true)}
              className="p-2 rounded-xl text-slate-400 hover:text-emerald-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-xs flex items-center gap-1"
            >
              <HelpCircle size={16} />
              <span className="hidden sm:inline">
                {isAr ? 'كيفية الاستيراد؟' : 'How it works?'}
              </span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* STEP 1: Upload / Choose File Source (Exact layout from reference) */}
          {step === 'upload' && (
            <div className="space-y-6">
              <div className="text-center">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  {isAr ? 'اختر مصدر الملف' : 'Choose File Source'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
                  {isAr
                    ? 'يمكنك استيراد ملفات PDF أو Excel أو CSV من كشف حساب البنك.'
                    : 'You can import PDF, Excel, or CSV files from your bank statement.'}
                </p>
              </div>

              {/* 3 Prominent Format Cards matching reference */}
              <div className="grid grid-cols-3 gap-3">
                {/* PDF Card */}
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className={`flex flex-col items-center justify-center p-4 rounded-2xl cursor-pointer border transition-all hover:scale-[1.02] ${
                    isDark
                      ? 'bg-slate-800/60 border-slate-700/80 hover:border-rose-500/50'
                      : 'bg-rose-50/50 border-rose-100 hover:border-rose-300'
                  }`}
                >
                  <div className="w-12 h-12 rounded-2xl bg-rose-500 flex items-center justify-center text-white shadow-md shadow-rose-500/20 mb-2">
                    <FileText size={24} />
                  </div>
                  <span className="text-xs font-bold text-slate-900 dark:text-white">PDF</span>
                  <span className="text-[10px] text-slate-400 mt-0.5">{isAr ? 'كشف إلكتروني' : 'E-Statement'}</span>
                </div>

                {/* Excel Card */}
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className={`flex flex-col items-center justify-center p-4 rounded-2xl cursor-pointer border transition-all hover:scale-[1.02] ${
                    isDark
                      ? 'bg-slate-800/60 border-slate-700/80 hover:border-emerald-500/50'
                      : 'bg-emerald-50/50 border-emerald-100 hover:border-emerald-300'
                  }`}
                >
                  <div className="w-12 h-12 rounded-2xl bg-emerald-600 flex items-center justify-center text-white shadow-md shadow-emerald-600/20 mb-2">
                    <FileSpreadsheet size={24} />
                  </div>
                  <span className="text-xs font-bold text-slate-900 dark:text-white">Excel</span>
                  <span className="text-[10px] text-slate-400 mt-0.5">XLSX / XLS</span>
                </div>

                {/* CSV Card */}
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className={`flex flex-col items-center justify-center p-4 rounded-2xl cursor-pointer border transition-all hover:scale-[1.02] ${
                    isDark
                      ? 'bg-slate-800/60 border-slate-700/80 hover:border-purple-500/50'
                      : 'bg-purple-50/50 border-purple-100 hover:border-purple-300'
                  }`}
                >
                  <div className="w-12 h-12 rounded-2xl bg-purple-600 flex items-center justify-center text-white shadow-md shadow-purple-600/20 mb-2">
                    <FileCode size={24} />
                  </div>
                  <span className="text-xs font-bold text-slate-900 dark:text-white">CSV</span>
                  <span className="text-[10px] text-slate-400 mt-0.5">{isAr ? 'ملف نصي' : 'Comma-separated'}</span>
                </div>
              </div>

              {/* Target Account Selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5">
                  {isAr ? 'استيراد إلى حساب:' : 'Import into account:'}
                </label>
                <select
                  value={targetAccountId}
                  onChange={(e) => setTargetAccountId(e.target.value)}
                  className={`w-full p-3 rounded-2xl text-xs font-medium border outline-none ${
                    isDark
                      ? 'bg-slate-800 border-slate-700 text-white'
                      : 'bg-slate-50 border-slate-200 text-slate-900'
                  }`}
                >
                  {accounts.map((a) => (
                    <option key={a.id} value={a.id}>
                      {isAr ? a.name : a.nameEn} ({a.currency})
                    </option>
                  ))}
                </select>
              </div>

              {/* Hidden file input */}
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.xlsx,.xls,.txt,.pdf"
                onChange={handleFileUpload}
                className="hidden"
              />

              {/* Action Button: اختيار الملف */}
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={loading}
                className="w-full py-4 rounded-2xl text-white font-bold text-sm shadow-lg shadow-emerald-700/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                style={{
                  background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                }}
              >
                <Upload size={18} />
                <span>{loading ? (isAr ? 'جاري قراءة الملف...' : 'Parsing file...') : (isAr ? 'اختيار الملف' : 'Select File')}</span>
              </button>

              {/* 1-Click Verification Test Statements */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400 mb-3">
                  <Sparkles size={14} />
                  <span>{isAr ? 'اختبار فوري بكشوف بنوك الإمارات (جاهزة للتجربة):' : 'Instant 1-Click UAE Bank Statements:'}</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <button
                    onClick={() => handleLoadSyntheticStatement('emiratesNBD')}
                    className={`p-2.5 rounded-xl text-xs text-right border transition-all ${
                      isDark
                        ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
                        : 'bg-slate-50 hover:bg-emerald-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    <div className="font-bold">{isAr ? 'الإمارات دبي الوطني' : 'Emirates NBD'}</div>
                    <div className="text-[10px] text-slate-400">{isAr ? 'كشف متوازن ودقيق' : 'Fully balanced'}</div>
                  </button>

                  <button
                    onClick={() => handleLoadSyntheticStatement('adcb')}
                    className={`p-2.5 rounded-xl text-xs text-right border transition-all ${
                      isDark
                        ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
                        : 'bg-slate-50 hover:bg-emerald-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    <div className="font-bold">{isAr ? 'أبوظبي التجاري ADCB' : 'ADCB Bank'}</div>
                    <div className="text-[10px] text-slate-400">{isAr ? 'صيغة أعمدة مختلفة' : 'Distinct columns'}</div>
                  </button>

                  <button
                    onClick={() => handleLoadSyntheticStatement('ambiguous')}
                    className={`p-2.5 rounded-xl text-xs text-right border transition-all ${
                      isDark
                        ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
                        : 'bg-slate-50 hover:bg-amber-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    <div className="font-bold">{isAr ? 'كشف يحوي تكرار' : 'Duplicate Check'}</div>
                    <div className="text-[10px] text-slate-400">{isAr ? 'اختبار اكتشاف التكرار' : 'Audit validation'}</div>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: Preview & Reconciliation */}
          {step === 'preview' && parseResult && (
            <div className="space-y-5">
              {/* File Info & Reconciliation Card */}
              <div
                className={`p-4 rounded-2xl border ${
                  parseResult.isReconciled
                    ? isDark
                      ? 'bg-emerald-950/20 border-emerald-800/50'
                      : 'bg-emerald-50 border-emerald-200/80'
                    : isDark
                    ? 'bg-amber-950/20 border-amber-800/50'
                    : 'bg-amber-50 border-amber-200/80'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {parseResult.isReconciled ? (
                      <CheckCircle2 size={18} className="text-emerald-500" />
                    ) : (
                      <AlertTriangle size={18} className="text-amber-500" />
                    )}
                    <span className="text-xs font-bold">
                      {parseResult.isReconciled
                        ? isAr ? 'كشف الحساب مطابق محاسبياً وموثوق ✓' : 'Statement Reconciled & Verified ✓'
                        : isAr ? 'تنبيه: مراجعة العمليات قبل الحفظ' : 'Review Candidate Records'}
                    </span>
                  </div>
                  <span className="text-[11px] font-medium text-slate-500">
                    {parseResult.candidateRows.length} {isAr ? 'معاملة' : 'rows'}
                  </span>
                </div>

                {parseResult.openingBalance !== undefined && parseResult.closingBalance !== undefined && (
                  <div className="grid grid-cols-3 gap-2 text-[11px] pt-2 border-t border-slate-200/50 dark:border-slate-700/50">
                    <div>
                      <span className="text-slate-400 block">{isAr ? 'رصيد الافتتاح' : 'Opening'}</span>
                      <span className="font-bold tabular-nums">
                        {formatCurrency(parseResult.openingBalance, settings.currency, settings.language)}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">{isAr ? 'الرصيد المحسوب' : 'Calculated'}</span>
                      <span className="font-bold tabular-nums">
                        {formatCurrency(parseResult.calculatedClosingBalance || 0, settings.currency, settings.language)}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">{isAr ? 'الرصيد النهائي' : 'Reported'}</span>
                      <span className="font-bold tabular-nums">
                        {formatCurrency(parseResult.closingBalance, settings.currency, settings.language)}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Duplicate summary warning if duplicates found */}
              {parseResult.duplicateCount > 0 && (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-700 dark:text-amber-400 text-xs flex items-center gap-2">
                  <AlertTriangle size={16} className="shrink-0" />
                  <span>
                    {isAr
                      ? `تم اكتشاف ${parseResult.duplicateCount} معاملات قد تكون مكررة. تم إلغاء تحديدها تلقائياً لتجنب الازدواجية.`
                      : `Detected ${parseResult.duplicateCount} potential duplicates. Unselected by default.`}
                  </span>
                </div>
              )}

              {/* Transactions Preview Table */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-900 dark:text-white px-1">
                  <span>{isAr ? 'معاينة المعاملات المستخرجة:' : 'Extracted Transactions:'}</span>
                  <div className="text-[11px] font-normal text-slate-400">
                    {isAr
                      ? `المحدد: ${parseResult.candidateRows.filter((r) => r.selected).length} من ${parseResult.candidateRows.length}`
                      : `Selected: ${parseResult.candidateRows.filter((r) => r.selected).length} of ${parseResult.candidateRows.length}`}
                  </div>
                </div>

                <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
                  {parseResult.candidateRows.map((row) => (
                    <div
                      key={row.rowIndex}
                      className={`p-3 rounded-2xl border text-xs flex items-center justify-between gap-3 transition-colors ${
                        row.isDuplicate
                          ? isDark
                            ? 'bg-amber-950/20 border-amber-800/40 opacity-75'
                            : 'bg-amber-50/60 border-amber-200 opacity-80'
                          : row.selected
                          ? isDark
                            ? 'bg-slate-800/80 border-emerald-500/40'
                            : 'bg-emerald-50/40 border-emerald-300'
                          : isDark
                          ? 'bg-slate-800/30 border-slate-800'
                          : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      {/* Checkbox */}
                      <button
                        onClick={() => toggleRowSelection(row.rowIndex)}
                        className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 border transition-colors ${
                          row.selected
                            ? 'bg-emerald-600 border-emerald-600 text-white'
                            : 'border-slate-300 dark:border-slate-600 bg-transparent'
                        }`}
                      >
                        {row.selected && <Check size={12} strokeWidth={3} />}
                      </button>

                      {/* Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 dark:text-white truncate">
                            {row.cleanedDescription}
                          </span>
                          {row.isDuplicate && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-600 dark:text-amber-400 font-semibold shrink-0">
                              {isAr ? 'مكرر محتمل' : 'Duplicate'}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                          <span>{row.normalizedDate}</span>
                          <span>·</span>
                          {/* Category selector inline */}
                          <select
                            value={row.suggestedCategoryId}
                            onChange={(e) => changeRowCategory(row.rowIndex, e.target.value)}
                            className="bg-transparent text-emerald-600 dark:text-emerald-400 font-medium outline-none cursor-pointer"
                          >
                            {categories.map((c) => (
                              <option key={c.id} value={c.id} className="text-slate-900 bg-white">
                                {isAr ? c.nameAr : c.nameEn}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {/* Amount */}
                      <div className="text-left font-bold tabular-nums shrink-0">
                        <span
                          className={
                            row.type === 'income'
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-rose-600 dark:text-rose-400'
                          }
                        >
                          {row.type === 'income' ? '+ ' : '- '}
                          {formatCurrency(row.amount, settings.currency, settings.language)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={() => setStep('upload')}
                  className="py-3 px-4 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 transition-colors"
                >
                  {isAr ? 'اختيار ملف آخر' : 'Choose another'}
                </button>

                <button
                  onClick={handleConfirmImport}
                  className="flex-1 py-3.5 rounded-2xl text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-700/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                  style={{
                    background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                  }}
                >
                  <CheckCircle2 size={16} />
                  <span>
                    {isAr
                      ? `تأكيد وحفظ (${parseResult.candidateRows.filter((r) => r.selected).length}) معاملة`
                      : `Confirm & Save (${parseResult.candidateRows.filter((r) => r.selected).length})`}
                  </span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* How to import Help Modal */}
        {showHelpModal && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <div
              className={`w-full max-w-md rounded-3xl p-6 shadow-2xl ${
                isDark ? 'bg-slate-900 border border-slate-800 text-white' : 'bg-white text-slate-900'
              }`}
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <h3 className="font-bold text-sm">
                  {isAr ? 'كيفية استيراد كشف الحساب من بنكك؟' : 'How to export & import statement?'}
                </h3>
                <button
                  onClick={() => setShowHelpModal(false)}
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="py-4 space-y-3 text-xs text-slate-600 dark:text-slate-300">
                <p>
                  {isAr
                    ? '1. افتح تطبيق البنك الخاص بك (مثل الإمارات دبي الوطني، أبوظبي التجاري، دبي الإسلامي، المشرق).'
                    : '1. Open your banking app or web portal.'}
                </p>
                <p>
                  {isAr
                    ? '2. ادخل على الحساب ثم اختر "تحميل كشف الحساب" (Download Statement).'
                    : '2. Navigate to your account and select "Download Statement".'}
                </p>
                <p>
                  {isAr
                    ? '3. اختر صيغة Excel أو CSV (أو PDF) للفترة المراد تحليلها.'
                    : '3. Choose Excel, CSV, or PDF format for the desired period.'}
                </p>
                <p>
                  {isAr
                    ? '4. قم برفع الملف هنا، وسيقوم تطبيق تحويشة بقراءة التواريخ، والمبالغ، والتصنيف التلقائي، واكتشاف أي معاملات مكررة.'
                    : '4. Upload the file here. Tahweesha will parse dates, amounts, categorize merchants, and detect duplicates.'}
                </p>
                <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-800 dark:text-emerald-300 text-[11px] font-medium">
                  {isAr
                    ? '🔒 بياناتك المالية مشفرة وتبقى داخل جهازك فقط بدون إرسالها لأي خادم خارجي.'
                    : '🔒 Your data is processed 100% locally on your device for absolute privacy.'}
                </div>
              </div>

              <button
                onClick={() => setShowHelpModal(false)}
                className="w-full py-2.5 rounded-xl bg-slate-900 dark:bg-white dark:text-slate-900 text-white font-bold text-xs"
              >
                {isAr ? 'فهمت' : 'Got it'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
