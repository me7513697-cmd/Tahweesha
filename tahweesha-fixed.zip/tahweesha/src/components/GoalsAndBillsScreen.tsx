import React, { useState } from 'react';
import {
  Target,
  Plus,
  CheckCircle2,
  Calendar,
  AlertCircle,
  Home,
  Zap,
  Tv,
  Wifi,
  Plane,
  ShieldCheck,
  Car,
  X,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { SavingsGoal, RecurringBill, AppSettings } from '../types/finance';
import { formatCurrency, roundTo2Decimals, todayISO } from '../utils/financialMath';

interface GoalsAndBillsScreenProps {
  goals: SavingsGoal[];
  bills: RecurringBill[];
  settings: AppSettings;
  onUpdateGoal: (goal: SavingsGoal) => void;
  onAddGoal: (goal: SavingsGoal) => void;
  onToggleBill: (billId: string) => void;
}

export const GoalsAndBillsScreen: React.FC<GoalsAndBillsScreenProps> = ({
  goals,
  bills,
  settings,
  onUpdateGoal,
  onAddGoal,
  onToggleBill,
}) => {
  const isDark = settings.theme === 'dark';
  const isAr = settings.language === 'ar';

  const [showAddGoalModal, setShowAddGoalModal] = useState(false);
  const [newGoalName, setNewGoalName] = useState('');
  const [newGoalTarget, setNewGoalTarget] = useState('');
  const [newGoalCurrent, setNewGoalCurrent] = useState('');
  const [newGoalDate, setNewGoalDate] = useState(() => {
    const d = new Date();
    d.setFullYear(d.getFullYear() + 1);
    return todayISO(d);
  });

  const [contributeGoalId, setContributeGoalId] = useState<string | null>(null);
  const [contributeAmount, setContributeAmount] = useState('');

  const formatAmount = (val: number) => {
    return formatCurrency(val, settings.currency, settings.language, { hideDecimals: true });
  };

  const getGoalIcon = (iconName: string) => {
    switch (iconName) {
      case 'ShieldCheck':
        return <ShieldCheck size={16} />;
      case 'Car':
        return <Car size={16} />;
      case 'Plane':
        return <Plane size={16} />;
      default:
        return <Target size={16} />;
    }
  };

  const getBillIcon = (iconName: string) => {
    switch (iconName) {
      case 'Home':
        return <Home size={18} />;
      case 'Zap':
        return <Zap size={18} />;
      case 'Tv':
        return <Tv size={18} />;
      case 'Wifi':
        return <Wifi size={18} />;
      default:
        return <Calendar size={18} />;
    }
  };

  const handleContribute = (goal: SavingsGoal) => {
    const amt = parseFloat(contributeAmount);
    if (isNaN(amt) || amt <= 0) return;

    const newCurrent = roundTo2Decimals(goal.currentAmount + amt);
    onUpdateGoal({
      ...goal,
      currentAmount: newCurrent,
    });

    if (newCurrent >= goal.targetAmount && goal.currentAmount < goal.targetAmount) {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });
    }

    setContributeGoalId(null);
    setContributeAmount('');
  };

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoalName.trim()) return;

    const target = parseFloat(newGoalTarget);
    if (isNaN(target) || target <= 0) return;

    const current = parseFloat(newGoalCurrent) || 0;

    const goal: SavingsGoal = {
      id: `goal_${Date.now()}`,
      name: newGoalName.trim(),
      nameEn: newGoalName.trim(),
      targetAmount: roundTo2Decimals(target),
      currentAmount: roundTo2Decimals(current),
      targetDate: newGoalDate,
      category: 'عام',
      icon: 'Target',
      color: '#0d9488',
    };

    onAddGoal(goal);
    setShowAddGoalModal(false);
    setNewGoalName('');
    setNewGoalTarget('');
    setNewGoalCurrent('');
  };

  return (
    <div className="flex flex-col gap-6 pb-28">
      {/* Top Header */}
      <div className="flex items-center justify-between px-1">
        <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          {isAr ? 'الأهداف والالتزامات' : 'Goals & Commitments'}
        </h1>
        <div className="text-xs text-slate-400 font-medium">
          {goals.length} {isAr ? 'أهداف' : 'goals'} · {bills.length} {isAr ? 'فواتير' : 'bills'}
        </div>
      </div>

      {/* SECTION 1: Savings Goals ("أهدافي") matching reference */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            {isAr ? 'أهدافي' : 'My Goals'}
          </h2>
        </div>

        {/* Goals Cards */}
        <div className="space-y-3">
          {goals.map((g) => {
            const pct =
              g.targetAmount > 0 ? Math.min(100, Math.round((g.currentAmount / g.targetAmount) * 100)) : 0;

            return (
              <div
                key={g.id}
                className={`relative overflow-hidden rounded-3xl p-5 border transition-all ${
                  isDark
                    ? 'glass-card-dark border-slate-800'
                    : 'glass-card-light border-slate-200/80 shadow-sm'
                }`}
              >
                {/* Decorative subtle ambient gradient header */}
                <div
                  className="absolute top-0 left-0 right-0 h-1.5"
                  style={{
                    background: 'linear-gradient(90deg, #10b981 0%, #06b6d4 100%)',
                  }}
                />

                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                      {getGoalIcon(g.icon)}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                        {isAr ? g.name : g.nameEn}
                      </h3>
                      <span className="text-[10px] text-slate-400">
                        {isAr ? 'الهدف المخطط:' : 'Target:'} {g.targetDate}
                      </span>
                    </div>
                  </div>

                  <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                    {pct}%
                  </span>
                </div>

                {/* Amount Ratio: e.g. AED 3,200 / 5,000 */}
                <div className="flex items-baseline justify-between my-2 text-xs font-semibold tabular-nums">
                  <span className="text-slate-900 dark:text-white text-base font-extrabold">
                    {formatAmount(g.currentAmount)}
                  </span>
                  <span className="text-slate-400 text-xs font-medium">
                    {isAr ? 'من أصل' : 'of'} {formatAmount(g.targetAmount)}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden mb-3">
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{
                      width: `${pct}%`,
                      background: 'linear-gradient(90deg, #10b981 0%, #059669 100%)',
                    }}
                  />
                </div>

                {/* Contribution Action Trigger */}
                {contributeGoalId === g.id ? (
                  <div className="p-2 rounded-2xl bg-slate-100 dark:bg-slate-800/80 flex items-center gap-2 animate-in fade-in">
                    <input
                      type="number"
                      step="0.01"
                      value={contributeAmount}
                      onChange={(e) => setContributeAmount(e.target.value)}
                      placeholder={isAr ? `مبلغ الإيداع (${settings.currency})` : 'Amount to deposit'}
                      className="flex-1 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 text-xs font-bold tabular-nums outline-none border border-slate-200 dark:border-slate-700"
                      autoFocus
                    />
                    <button
                      onClick={() => handleContribute(g)}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-bold text-xs"
                    >
                      {isAr ? 'إيداع' : 'Deposit'}
                    </button>
                    <button
                      onClick={() => setContributeGoalId(null)}
                      className="p-1.5 text-slate-400 hover:text-slate-600"
                    >
                      <X size={15} />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setContributeGoalId(g.id)}
                    className="w-full py-2 rounded-xl text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-colors"
                  >
                    {isAr ? '+ إضافة مبلغ للهدف' : '+ Add contribution'}
                  </button>
                )}
              </div>
            );
          })}
        </div>

        {/* Add Goal Button matching reference (+ إضافة هدف جديد) */}
        <button
          onClick={() => setShowAddGoalModal(true)}
          className={`w-full py-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
            isDark
              ? 'bg-slate-900/80 border-slate-800 text-emerald-400 hover:bg-slate-800'
              : 'bg-white border-slate-200/80 text-emerald-600 hover:bg-slate-50 shadow-sm'
          }`}
        >
          <Plus size={16} />
          <span>{isAr ? 'إضافة هدف جديد' : 'Add New Goal'}</span>
        </button>
      </div>

      {/* SECTION 2: Upcoming Commitments & Bills ("الالتزامات القادمة") matching reference */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            {isAr ? 'الالتزامات القادمة' : 'Upcoming Bills & Commitments'}
          </h2>
          <span className="text-xs text-slate-400">
            {bills.filter((b) => !b.isPaid).length} {isAr ? 'مستحقة' : 'due'}
          </span>
        </div>

        <div
          className={`rounded-3xl divide-y ${
            isDark
              ? 'glass-card-dark divide-slate-800'
              : 'glass-card-light divide-slate-100'
          } overflow-hidden`}
        >
          {bills.map((bill) => {
            const isDueSoon = !bill.isPaid;

            return (
              <div
                key={bill.id}
                className="flex items-center justify-between p-4 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                      bill.isPaid
                        ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                        : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                    }`}
                  >
                    {getBillIcon(bill.icon)}
                  </div>
                  <div>
                    <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                      {isAr ? bill.name : bill.nameEn}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1.5">
                      <Calendar size={12} />
                      <span>{bill.dueDate}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-left font-bold tabular-nums">
                    <div className="text-xs sm:text-sm text-slate-900 dark:text-white">
                      {formatAmount(bill.amount)}
                    </div>
                  </div>

                  {/* Paid / Unpaid Status Toggle */}
                  <button
                    onClick={() => onToggleBill(bill.id)}
                    className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all ${
                      bill.isPaid
                        ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/25'
                        : 'bg-amber-500/15 text-amber-700 dark:text-amber-400 hover:bg-amber-500/25'
                    }`}
                  >
                    {bill.isPaid
                      ? isAr ? 'تم السداد ✓' : 'Paid ✓'
                      : isAr ? 'تسديد' : 'Pay'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Goal Modal */}
      {showAddGoalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div
            className={`w-full max-w-sm rounded-3xl p-6 shadow-2xl ${
              isDark ? 'bg-slate-900 border border-slate-800 text-white' : 'bg-white text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-sm">
                {isAr ? 'إنشاء هدف ادخار جديد' : 'New Savings Goal'}
              </h3>
              <button onClick={() => setShowAddGoalModal(false)} className="text-slate-400 hover:text-slate-600">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateGoal} className="pt-4 space-y-3.5">
              <div>
                <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                  {isAr ? 'اسم الهدف' : 'Goal Name'}
                </label>
                <input
                  type="text"
                  value={newGoalName}
                  onChange={(e) => setNewGoalName(e.target.value)}
                  placeholder={isAr ? 'مثال: شراء سيارة، رحلة صيفية' : 'e.g. Travel, Emergency'}
                  className={`w-full p-2.5 rounded-2xl text-xs border outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200'
                  }`}
                  autoFocus
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                  {isAr ? `المبلغ المستهدف (${settings.currency})` : `Target Amount (${settings.currency})`}
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={newGoalTarget}
                  onChange={(e) => setNewGoalTarget(e.target.value)}
                  placeholder="5000"
                  className={`w-full p-2.5 rounded-2xl text-sm font-bold tabular-nums border outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200'
                  }`}
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                  {isAr ? 'المبلغ الحالي المتوفر' : 'Current Saved'}
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={newGoalCurrent}
                  onChange={(e) => setNewGoalCurrent(e.target.value)}
                  placeholder="0"
                  className={`w-full p-2.5 rounded-2xl text-sm font-bold tabular-nums border outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200'
                  }`}
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                  {isAr ? 'تاريخ الإنجاز المتوقع' : 'Target Date'}
                </label>
                <input
                  type="date"
                  value={newGoalDate}
                  onChange={(e) => setNewGoalDate(e.target.value)}
                  className={`w-full p-2.5 rounded-2xl text-xs border outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200'
                  }`}
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-emerald-600 text-white font-bold text-xs shadow-md shadow-emerald-700/20 active:scale-[0.98]"
              >
                {isAr ? 'حفظ الهدف' : 'Save Goal'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
