import React, { useState, useMemo } from 'react';
import {
  Search,
  SlidersHorizontal,
  Plus,
  ArrowUpDown,
  Calendar,
  CheckCircle2,
  AlertCircle,
  FileText,
  Trash2,
  Edit2,
  X,
  Building2,
  Filter,
} from 'lucide-react';
import { CategoryIcon } from './CategoryIcon';
import { Transaction, Account, Category, AppSettings } from '../types/finance';
import { formatCurrency } from '../utils/financialMath';

interface TransactionsScreenProps {
  transactions: Transaction[];
  categories: Category[];
  accounts: Account[];
  settings: AppSettings;
  onOpenAddModal: () => void;
  onEditTransaction: (tx: Transaction) => void;
  onDeleteTransaction: (id: string) => void;
  onUpdateStatus: (id: string, status: 'verified' | 'reviewed') => void;
}

export const TransactionsScreen: React.FC<TransactionsScreenProps> = ({
  transactions,
  categories,
  accounts,
  settings,
  onOpenAddModal,
  onEditTransaction,
  onDeleteTransaction,
  onUpdateStatus,
}) => {
  const isDark = settings.theme === 'dark';
  const isAr = settings.language === 'ar';

  const [activeTab, setActiveTab] = useState<'all' | 'expense' | 'income' | 'transfer'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedAccount, setSelectedAccount] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'date_desc' | 'date_asc' | 'amount_desc' | 'amount_asc'>('date_desc');
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);
  const [selectedTxForDetail, setSelectedTxForDetail] = useState<Transaction | null>(null);

  const getCategory = (catId: string) => {
    return (
      categories.find((c) => c.id === catId) || {
        id: catId,
        nameAr: 'أخرى',
        nameEn: 'Other',
        icon: 'MoreHorizontal',
        color: '#94a3b8',
        type: 'expense' as const,
      }
    );
  };

  const getAccount = (accId: string) => {
    return accounts.find((a) => a.id === accId);
  };

  // Filter and Sort Pipeline
  const filteredTransactions = useMemo(() => {
    return transactions
      .filter((tx) => {
        // Tab filter
        if (activeTab !== 'all' && tx.type !== activeTab) return false;

        // Account filter
        if (selectedAccount !== 'all' && tx.accountId !== selectedAccount && tx.destinationAccountId !== selectedAccount) {
          return false;
        }

        // Category filter
        if (selectedCategory !== 'all' && tx.categoryId !== selectedCategory) {
          return false;
        }

        // Search Query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchDesc = tx.description.toLowerCase().includes(q);
          const matchOrig = tx.originalDescription?.toLowerCase().includes(q);
          const cat = getCategory(tx.categoryId);
          const matchCat = cat.nameAr.toLowerCase().includes(q) || cat.nameEn.toLowerCase().includes(q);
          if (!matchDesc && !matchOrig && !matchCat) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'date_desc') return b.date.localeCompare(a.date);
        if (sortBy === 'date_asc') return a.date.localeCompare(b.date);
        if (sortBy === 'amount_desc') return b.amount - a.amount;
        if (sortBy === 'amount_asc') return a.amount - b.amount;
        return 0;
      });
  }, [transactions, activeTab, selectedAccount, selectedCategory, searchQuery, sortBy]);

  // Group by Date for authentic mobile list view
  const groupedTransactions = useMemo(() => {
    const groups: { date: string; items: Transaction[] }[] = [];
    filteredTransactions.forEach((tx) => {
      const existing = groups.find((g) => g.date === tx.date);
      if (existing) {
        existing.items.push(tx);
      } else {
        groups.push({ date: tx.date, items: [tx] });
      }
    });
    return groups;
  }, [filteredTransactions]);

  const formatAmount = (val: number) => {
    return formatCurrency(val, settings.currency, settings.language);
  };

  return (
    <div className="flex flex-col gap-4 pb-28">
      {/* Top Header */}
      <div className="flex items-center justify-between px-1">
        <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          {isAr ? 'العمليات' : 'Transactions'}
        </h1>
        <div className="text-xs text-slate-500 dark:text-slate-400 font-medium tabular-nums">
          {filteredTransactions.length} {isAr ? 'عملية' : 'items'}
        </div>
      </div>

      {/* Segmented Filter Control matching reference mockup */}
      <div
        className={`p-1 rounded-2xl flex items-center justify-between ${
          isDark ? 'bg-slate-900/90 border border-slate-800' : 'bg-slate-100 border border-slate-200/60'
        }`}
      >
        <button
          onClick={() => setActiveTab('all')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
            activeTab === 'all'
              ? isDark
                ? 'bg-slate-800 text-white shadow-sm'
                : 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          {isAr ? 'الكل' : 'All'}
        </button>
        <button
          onClick={() => setActiveTab('expense')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
            activeTab === 'expense'
              ? isDark
                ? 'bg-slate-800 text-rose-400 shadow-sm'
                : 'bg-white text-rose-600 shadow-sm'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          {isAr ? 'مصاريف' : 'Expenses'}
        </button>
        <button
          onClick={() => setActiveTab('income')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
            activeTab === 'income'
              ? isDark
                ? 'bg-slate-800 text-emerald-400 shadow-sm'
                : 'bg-white text-emerald-600 shadow-sm'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          {isAr ? 'إيرادات' : 'Income'}
        </button>
        <button
          onClick={() => setActiveTab('transfer')}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
            activeTab === 'transfer'
              ? isDark
                ? 'bg-slate-800 text-blue-400 shadow-sm'
                : 'bg-white text-blue-600 shadow-sm'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          {isAr ? 'تحويلات' : 'Transfers'}
        </button>
      </div>

      {/* Search Bar & Filter Button */}
      <div className="flex items-center gap-2">
        <div
          className={`flex-1 flex items-center gap-2 px-3.5 py-2.5 rounded-2xl ${
            isDark ? 'glass-card-dark' : 'glass-card-light'
          }`}
        >
          <Search size={18} className="text-slate-400 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isAr ? 'إبحث عن عملية أو تاجر...' : 'Search transaction or merchant...'}
            className="w-full bg-transparent text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 outline-none"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X size={15} />
            </button>
          )}
        </div>

        <button
          onClick={() => setShowFilterDrawer(!showFilterDrawer)}
          className={`p-3 rounded-2xl flex items-center justify-center transition-colors ${
            selectedCategory !== 'all' || selectedAccount !== 'all' || sortBy !== 'date_desc'
              ? 'bg-emerald-600 text-white shadow-sm'
              : isDark
              ? 'glass-card-dark text-slate-300 hover:bg-slate-800'
              : 'glass-card-light text-slate-700 hover:bg-white'
          }`}
          aria-label="Filter"
        >
          <SlidersHorizontal size={18} />
        </button>
      </div>

      {/* Optional Filter Drawer / Bar */}
      {showFilterDrawer && (
        <div
          className={`p-4 rounded-3xl space-y-3 ${
            isDark ? 'glass-card-dark' : 'glass-card-light'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold text-slate-900 dark:text-white">
            <span>{isAr ? 'خيارات التصفية والترتيب' : 'Filter & Sort Options'}</span>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSelectedAccount('all');
                setSortBy('date_desc');
              }}
              className="text-emerald-600 dark:text-emerald-400 hover:underline font-normal text-[11px]"
            >
              {isAr ? 'إعادة تعيين' : 'Reset'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {/* Category Select */}
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">
                {isAr ? 'الفئة' : 'Category'}
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full text-xs p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 outline-none border border-slate-200 dark:border-slate-700"
              >
                <option value="all">{isAr ? 'جميع الفئات' : 'All Categories'}</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {isAr ? c.nameAr : c.nameEn}
                  </option>
                ))}
              </select>
            </div>

            {/* Account Select */}
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">
                {isAr ? 'الحساب' : 'Account'}
              </label>
              <select
                value={selectedAccount}
                onChange={(e) => setSelectedAccount(e.target.value)}
                className="w-full text-xs p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 outline-none border border-slate-200 dark:border-slate-700"
              >
                <option value="all">{isAr ? 'جميع الحسابات' : 'All Accounts'}</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {isAr ? a.name : a.nameEn}
                  </option>
                ))}
              </select>
            </div>

            {/* Sort Select */}
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">
                {isAr ? 'الترتيب' : 'Sort By'}
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full text-xs p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 outline-none border border-slate-200 dark:border-slate-700"
              >
                <option value="date_desc">{isAr ? 'الأحدث أولاً' : 'Newest First'}</option>
                <option value="date_asc">{isAr ? 'الأقدم أولاً' : 'Oldest First'}</option>
                <option value="amount_desc">{isAr ? 'الأعلى مبلغاً' : 'Highest Amount'}</option>
                <option value="amount_asc">{isAr ? 'الأقل مبلغاً' : 'Lowest Amount'}</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Transaction List with Date Groups */}
      {filteredTransactions.length === 0 ? (
        <div
          className={`text-center py-12 px-4 rounded-3xl ${
            isDark ? 'glass-card-dark' : 'glass-card-light'
          }`}
        >
          <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400 mb-3">
            <Search size={22} />
          </div>
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
            {isAr ? 'لا توجد عمليات مطابقة' : 'No transactions found'}
          </p>
          <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
            {isAr
              ? 'جرّب تغيير كلمات البحث أو خيارات التصفية'
              : 'Try adjusting your search terms or filters'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {groupedTransactions.map((group) => (
            <div key={group.date} className="space-y-1.5">
              {/* Date Header */}
              <div className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 px-2 flex items-center gap-1.5">
                <Calendar size={12} />
                <span>{group.date.replace(/-/g, '/')}</span>
              </div>

              {/* Transactions in group */}
              <div
                className={`rounded-3xl divide-y ${
                  isDark
                    ? 'glass-card-dark divide-slate-800/60'
                    : 'glass-card-light divide-slate-100'
                } overflow-hidden`}
              >
                {group.items.map((tx) => {
                  const cat = getCategory(tx.categoryId);
                  const isIncome = tx.type === 'income';
                  const isTransfer = tx.type === 'transfer';

                  return (
                    <div
                      key={tx.id}
                      onClick={() => setSelectedTxForDetail(tx)}
                      className={`flex items-center justify-between p-3.5 cursor-pointer transition-colors ${
                        isDark ? 'hover:bg-slate-800/50' : 'hover:bg-slate-50/70'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <CategoryIcon
                          iconName={isTransfer ? 'ArrowLeftRight' : cat.icon}
                          color={isTransfer ? '#3b82f6' : cat.color}
                        />
                        <div className="truncate">
                          <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                            {tx.description}
                          </div>
                          <div className="flex items-center gap-2 text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">
                            <span>{isAr ? cat.nameAr : cat.nameEn}</span>
                            <span>·</span>
                            <span>
                              {tx.source === 'statement_import'
                                ? isAr ? 'كشف بنكي' : 'Imported'
                                : isAr ? 'يدوي' : 'Manual'}
                            </span>
                            {tx.status === 'uncertain' && (
                              <span className="text-amber-500 font-medium flex items-center gap-0.5">
                                <AlertCircle size={10} />
                                {isAr ? 'يحتاج مراجعة' : 'Review'}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="text-left font-bold tabular-nums shrink-0">
                        <div
                          className={`text-xs sm:text-sm ${
                            isIncome
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : isTransfer
                              ? 'text-blue-600 dark:text-blue-400'
                              : 'text-rose-600 dark:text-rose-400'
                          }`}
                        >
                          {isIncome ? '+ ' : isTransfer ? '' : '- '}
                          {formatAmount(tx.amount)}
                        </div>
                        {tx.destinationAccountId && (
                          <div className="text-[10px] text-blue-500/80 font-normal mt-0.5">
                            {isAr ? 'تحويل حساب' : 'Transfer'}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Floating Action Button (+) with emerald green gradient matching reference */}
      <div className="fixed bottom-24 right-5 z-30">
        <button
          onClick={onOpenAddModal}
          className="w-14 h-14 rounded-full flex items-center justify-center text-white shadow-xl shadow-emerald-700/30 active:scale-95 transition-all"
          style={{
            background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
          }}
          aria-label="Add transaction"
        >
          <Plus size={26} strokeWidth={2.5} />
        </button>
      </div>

      {/* Transaction Details Modal */}
      {selectedTxForDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div
            className={`w-full max-w-sm rounded-3xl p-6 shadow-2xl ${
              isDark ? 'bg-slate-900 border border-slate-800 text-white' : 'bg-white text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-base">
                {isAr ? 'تفاصيل المعاملة' : 'Transaction Details'}
              </h3>
              <button
                onClick={() => setSelectedTxForDetail(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X size={18} />
              </button>
            </div>

            <div className="py-4 space-y-3">
              <div className="text-center py-2">
                <div className="text-xs text-slate-400">
                  {selectedTxForDetail.type === 'income'
                    ? isAr ? 'إيراد' : 'Income'
                    : selectedTxForDetail.type === 'transfer'
                    ? isAr ? 'تحويل بين الحسابات' : 'Account Transfer'
                    : isAr ? 'مصروف' : 'Expense'}
                </div>
                <div
                  className={`text-2xl font-extrabold tabular-nums mt-1 ${
                    selectedTxForDetail.type === 'income'
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : selectedTxForDetail.type === 'transfer'
                      ? 'text-blue-600 dark:text-blue-400'
                      : 'text-rose-600 dark:text-rose-400'
                  }`}
                >
                  {selectedTxForDetail.type === 'income' ? '+ ' : selectedTxForDetail.type === 'transfer' ? '' : '- '}
                  {formatAmount(selectedTxForDetail.amount)}
                </div>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-400">{isAr ? 'الوصف' : 'Description'}</span>
                  <span className="font-semibold">{selectedTxForDetail.description}</span>
                </div>

                {selectedTxForDetail.originalDescription && (
                  <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400">{isAr ? 'النص الأصلي للكشف' : 'Original Narrative'}</span>
                    <span className="font-mono text-[10px] text-right max-w-[200px] truncate">
                      {selectedTxForDetail.originalDescription}
                    </span>
                  </div>
                )}

                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-400">{isAr ? 'التاريخ' : 'Date'}</span>
                  <span className="font-semibold">{selectedTxForDetail.date}</span>
                </div>

                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-400">
                    {selectedTxForDetail.type === 'transfer' ? (isAr ? 'من الحساب' : 'From') : isAr ? 'الحساب' : 'Account'}
                  </span>
                  <span className="font-semibold">
                    {(() => {
                      const a = getAccount(selectedTxForDetail.accountId);
                      return a ? (isAr ? a.name : a.nameEn) : isAr ? 'حساب محذوف' : 'Deleted account';
                    })()}
                  </span>
                </div>

                {selectedTxForDetail.destinationAccountId && (
                  <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400">{isAr ? 'إلى الحساب' : 'To'}</span>
                    <span className="font-semibold">
                      {(() => {
                        const a = getAccount(selectedTxForDetail.destinationAccountId!);
                        return a ? (isAr ? a.name : a.nameEn) : isAr ? 'حساب محذوف' : 'Deleted account';
                      })()}
                    </span>
                  </div>
                )}

                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-400">{isAr ? 'المصدر' : 'Source'}</span>
                  <span className="font-semibold">
                    {selectedTxForDetail.source === 'statement_import'
                      ? isAr ? 'كشف حساب مستورد' : 'Imported Statement'
                      : isAr ? 'إدخال يدوي' : 'Manual Entry'}
                  </span>
                </div>

                {selectedTxForDetail.status === 'uncertain' && (
                  <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-700 dark:text-amber-400">
                    <div className="flex items-center gap-1.5 font-semibold">
                      <AlertCircle size={14} />
                      <span>{isAr ? 'معاملة تحتاج تأكيد' : 'Needs Confirmation'}</span>
                    </div>
                    <button
                      onClick={() => {
                        onUpdateStatus(selectedTxForDetail.id, 'verified');
                        setSelectedTxForDetail({ ...selectedTxForDetail, status: 'verified' });
                      }}
                      className="mt-2 w-full py-1.5 rounded-lg bg-amber-500 text-white font-medium text-xs"
                    >
                      {isAr ? 'تأكيد المعاملة' : 'Confirm transaction'}
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => {
                  const tx = selectedTxForDetail;
                  setSelectedTxForDetail(null);
                  onEditTransaction(tx);
                }}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Edit2 size={14} />
                <span>{isAr ? 'تعديل' : 'Edit'}</span>
              </button>

              <button
                onClick={() => {
                  if (confirm(isAr ? 'هل أنت متأكد من حذف هذه المعاملة؟' : 'Delete this transaction?')) {
                    onDeleteTransaction(selectedTxForDetail.id);
                    setSelectedTxForDetail(null);
                  }
                }}
                className="py-2.5 px-4 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Trash2 size={14} />
                <span>{isAr ? 'حذف' : 'Delete'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
