import React from 'react';
import {
  Home,
  Receipt,
  BarChart3,
  PieChart,
  MoreHorizontal,
  Wallet,
} from 'lucide-react';

export type NavTab = 'home' | 'transactions' | 'reports' | 'budget' | 'more';

interface BottomNavBarProps {
  activeTab: NavTab;
  onChangeTab: (tab: NavTab) => void;
  isDark?: boolean;
  isAr?: boolean;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab,
  onChangeTab,
  isDark = false,
  isAr = true,
}) => {
  const tabs = [
    {
      id: 'home' as NavTab,
      labelAr: 'الرئيسية',
      labelEn: 'Home',
      icon: Home,
    },
    {
      id: 'transactions' as NavTab,
      labelAr: 'العمليات',
      labelEn: 'Transactions',
      icon: Receipt,
    },
    {
      id: 'reports' as NavTab,
      labelAr: 'التقارير',
      labelEn: 'Reports',
      icon: BarChart3,
    },
    {
      id: 'budget' as NavTab,
      labelAr: 'الميزانية',
      labelEn: 'Budget',
      icon: PieChart,
    },
    {
      id: 'more' as NavTab,
      labelAr: 'المزيد',
      labelEn: 'More',
      icon: MoreHorizontal,
    },
  ];

  return (
    <nav
      className={`fixed bottom-0 left-0 right-0 z-40 max-w-md mx-auto h-20 px-4 pb-4 pt-2 flex items-center justify-around transition-colors border-t backdrop-blur-xl ${
        isDark
          ? 'bg-slate-950/85 border-slate-800/80 text-slate-400'
          : 'bg-white/85 border-slate-200/60 text-slate-500 shadow-lg shadow-slate-900/5'
      }`}
      style={{
        height: 'calc(5rem + env(safe-area-inset-bottom))',
        paddingBottom: 'calc(1rem + env(safe-area-inset-bottom))',
        borderTopLeftRadius: '24px',
        borderTopRightRadius: '24px',
      }}
    >
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        const Icon = tab.icon;

        return (
          <button
            key={tab.id}
            onClick={() => onChangeTab(tab.id)}
            className={`flex flex-col items-center justify-center min-w-[56px] py-1 transition-all ${
              isActive
                ? 'text-emerald-600 dark:text-emerald-400 font-bold scale-105'
                : 'hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <div
              className={`w-9 h-9 rounded-2xl flex items-center justify-center transition-colors ${
                isActive
                  ? isDark
                    ? 'bg-emerald-500/15 text-emerald-400'
                    : 'bg-emerald-50 text-emerald-600'
                  : ''
              }`}
            >
              <Icon size={20} strokeWidth={isActive ? 2.4 : 1.8} />
            </div>
            <span className="text-[10px] tracking-tight mt-0.5">
              {isAr ? tab.labelAr : tab.labelEn}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
