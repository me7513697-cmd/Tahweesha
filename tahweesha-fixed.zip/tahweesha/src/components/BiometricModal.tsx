import React, { useState } from 'react';
import { Fingerprint, CheckCircle2, X } from 'lucide-react';

interface BiometricModalProps {
  isOpen: boolean;
  isAr?: boolean;
  locked?: boolean; // launch lock: cannot be dismissed without authenticating
  onSuccess: () => void;
  onCancel: () => void;
}

export const BiometricModal: React.FC<BiometricModalProps> = ({
  isOpen,
  isAr = true,
  locked = false,
  onSuccess,
  onCancel,
}) => {
  const [authenticating, setAuthenticating] = useState(false);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSimulateTouch = () => {
    setAuthenticating(true);
    setTimeout(() => {
      setAuthenticating(false);
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onSuccess();
      }, 500);
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-70 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-xs rounded-3xl p-6 bg-slate-900 border border-slate-800 text-white shadow-2xl text-center">
        <div className="flex justify-end h-[18px]">
          {!locked && (
            <button onClick={onCancel} className="text-slate-400 hover:text-white" aria-label="Close">
              <X size={18} />
            </button>
          )}
        </div>

        <h3 className="text-base font-bold tracking-tight mt-1">
          {isAr ? 'التحقق البيومتري' : 'Biometric Authentication'}
        </h3>
        <p className="text-xs text-slate-400 mt-1">
          {isAr
            ? 'المس مستشعر البصمة لفتح تطبيق تحويشة'
            : 'Touch fingerprint sensor to unlock Tahweesha'}
        </p>

        {/* Biometric Sensor Icon Button */}
        <div className="py-8 flex justify-center">
          <button
            onClick={handleSimulateTouch}
            disabled={authenticating || success}
            className={`w-20 h-20 rounded-full flex items-center justify-center border-2 transition-all ${
              success
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400 scale-105'
                : authenticating
                ? 'bg-emerald-500/10 border-emerald-400 text-emerald-400 animate-pulse'
                : 'bg-slate-800 border-slate-700 text-emerald-400 hover:scale-105 hover:border-emerald-500'
            }`}
          >
            {success ? (
              <CheckCircle2 size={36} className="text-emerald-400" />
            ) : (
              <Fingerprint size={36} className={authenticating ? 'animate-bounce' : ''} />
            )}
          </button>
        </div>

        <p className="text-[11px] text-slate-500">
          {isAr ? 'اضغط على أيقونة البصمة للتأكيد' : 'Tap the fingerprint sensor to verify'}
        </p>

        {!locked && (
          <button
            onClick={onSuccess}
            className="mt-5 w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
          >
            {isAr ? 'تخطي (محاكاة)' : 'Skip (simulation)'}
          </button>
        )}
      </div>
    </div>
  );
};
