import React from 'react';
import {
  FileSpreadsheet,
  Wallet,
  Target,
  Sparkles,
  Settings,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Info,
  ExternalLink,
} from 'lucide-react';
import { TahweeshaLogo } from './TahweeshaLogo';
import { AppSettings } from '../types/finance';

export type MoreDestination = 'import' | 'accounts' | 'goals' | 'assistant' | 'settings';

interface MoreMenuScreenProps {
  settings: AppSettings;
  onSelectDestination: (dest: MoreDestination) => void;
}

export const MoreMenuScreen: React.FC<MoreMenuScreenProps> = ({
  settings,
  onSelectDestination,
}) => {
  const isDark = settings.theme === 'dark';
  const isAr = settings.language === 'ar';

  const menuItems = [
    {
      id: 'import' as MoreDestination,
      titleAr: 'استيراد كشوف الحسابات',
      titleEn: 'Bank Statement Import',
      subtitleAr: 'استيراد ومطابقة ملفات PDF و Excel و CSV',
      subtitleEn: 'Parse & reconcile PDF, Excel & CSV',
      icon: FileSpreadsheet,
      color: '#0d9488',
      badgeAr: 'ميزة متقدمة',
      badgeEn: 'Key Feature',
    },
    {
      id: 'accounts' as MoreDestination,
      titleAr: 'الحسابات والمحافظ',
      titleEn: 'Accounts & Wallets',
      subtitleAr: 'إدارة الحسابات البنكية والنقدية والتحويلات',
      subtitleEn: 'Manage bank accounts, cash & transfers',
      icon: Wallet,
      color: '#0284c7',
    },
    {
      id: 'goals' as MoreDestination,
      titleAr: 'الأهداف والالتزامات',
      titleEn: 'Goals & Upcoming Bills',
      subtitleAr: 'خطط الادخار، الطوارئ، ومواعيد سداد الفواتير',
      subtitleEn: 'Savings goals & recurring bill dues',
      icon: Target,
      color: '#8b5cf6',
    },
    {
      id: 'assistant' as MoreDestination,
      titleAr: 'المساعد الذكي والتحليل المالي',
      titleEn: 'Smart Financial Assistant',
      subtitleAr: 'إجابات وتحليلات فورية لإنفاقك ومدخراتك',
      subtitleEn: 'Real-time answers on your money trends',
      icon: Sparkles,
      color: '#10b981',
      badgeAr: 'جديد',
      badgeEn: 'New',
    },
    {
      id: 'settings' as MoreDestination,
      titleAr: 'الإعدادات والنسخ الاحتياطي',
      titleEn: 'Settings & Local Backup',
      subtitleAr: 'اللغة، العملة، المظهر، القفل البيومتري، والخصوصية',
      subtitleEn: 'Language, theme, biometric lock & privacy',
      icon: Settings,
      color: '#f59e0b',
    },
  ];

  return (
    <div className="flex flex-col gap-5 pb-28">
      {/* Top Header */}
      <div className="flex items-center justify-between px-1">
        <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          {isAr ? 'المزيد' : 'More Features'}
        </h1>
      </div>

      {/* Brand Card */}
      <div
        className={`p-5 rounded-3xl flex items-center justify-between ${
          isDark ? 'glass-card-dark' : 'glass-card-light'
        }`}
      >
        <TahweeshaLogo size="md" showText={true} showTagline={true} isDark={isDark} />
      </div>

      {/* Menu Navigation Items */}
      <div
        className={`rounded-3xl divide-y ${
          isDark ? 'glass-card-dark divide-slate-800' : 'glass-card-light divide-slate-100'
        } overflow-hidden`}
      >
        {menuItems.map((item) => {
          const Icon = item.icon;

          return (
            <div
              key={item.id}
              onClick={() => onSelectDestination(item.id)}
              className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition-colors"
            >
              <div className="flex items-center gap-3.5">
                <div
                  className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0"
                  style={{
                    backgroundColor: `${item.color}15`,
                    color: item.color,
                  }}
                >
                  <Icon size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                      {isAr ? item.titleAr : item.titleEn}
                    </span>
                    {item.badgeAr && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                        {isAr ? item.badgeAr : item.badgeEn}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                    {isAr ? item.subtitleAr : item.subtitleEn}
                  </p>
                </div>
              </div>

              <ChevronLeft size={16} className={`text-slate-400 ${isAr ? '' : 'rotate-180'} shrink-0`} />
            </div>
          );
        })}
      </div>

      {/* Privacy Guarantee Banner */}
      <div
        className={`p-4 rounded-3xl border ${
          isDark
            ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-300'
            : 'bg-emerald-50/80 border-emerald-100 text-emerald-900'
        } text-xs space-y-1.5`}
      >
        <div className="flex items-center gap-2 font-bold">
          <ShieldCheck size={16} className="text-emerald-500 shrink-0" />
          <span>{isAr ? 'أمان وخصوصية تامة' : 'Local-First Privacy Guarantee'}</span>
        </div>
        <p className="text-[11px] opacity-90 leading-relaxed">
          {isAr
            ? 'بياناتك المالية وكشوف حساباتك البنكية تُعالج محلياً بنسبة 100% داخل جهازك دون إرسال أي أرقام أو سجلات إلى خوادم سحابية.'
            : 'Your financial statements and accounts are processed 100% locally on your device without transmitting data to any cloud servers.'}
        </p>
      </div>
    </div>
  );
};
