import React, { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  AlertTriangle,
  Plus,
  Edit2,
  Check,
  X,
  Target,
  Sparkles,
} from 'lucide-react';
import { CategoryIcon } from './CategoryIcon';
import { Budget, Category, AppSettings, MonthlyFinancialSummary } from '../types/finance';
import { formatCurrency, roundTo2Decimals } from '../utils/financialMath';
import { MonthSwitcher } from './MonthSwitcher';

interface BudgetScreenProps {
  summary: MonthlyFinancialSummary;
  budgets: Budget[];
  categories: Category[];
  settings: AppSettings;
  onSaveBudget: (budget: Budget) => void;
  onChangeMonth: (month: string) => void;
}

export const BudgetScreen: React.FC<BudgetScreenProps> = ({
  summary,
  budgets,
  categories,
  settings,
  onSaveBudget,
  onChangeMonth,
}) => {
  const isDark = settings.theme === 'dark';
  const isAr = settings.language === 'ar';

  const [editingBudgetCategory, setEditingBudgetCategory] = useState<string | null>(null);
  const [budgetLimitInput, setBudgetLimitInput] = useState('');

  const formatAmount = (val: number) => {
    return formatCurrency(val, settings.currency, settings.language, { hideDecimals: true });
  };

  // Circular gauge values
  const totalLimit = summary.totalBudget;
  const totalSpent = summary.budgetSpent;
  const progressPct = summary.budgetProgressPct;

  // SVG Circle Gauge
  const gaugeRadius = 70;
  const gaugeCircumference = 2 * Math.PI * gaugeRadius;
  const gaugeOffset = gaugeCircumference - (Math.min(100, progressPct) / 100) * gaugeCircumference;

  // Category specific budget items
  const categoryBudgets = categories
    .filter((c) => c.type === 'expense')
    .map((cat) => {
      const budgetRecord = budgets.find((b) => b.categoryId === cat.id && b.month === summary.month);
      const limit = budgetRecord ? budgetRecord.limitAmount : 1500;
      const spendingItem = summary.categoryBreakdown.find((b) => b.category.id === cat.id);
      const spent = spendingItem ? spendingItem.amount : 0;
      const pct = limit > 0 ? Math.round((spent / limit) * 100) : 0;
      return {
        category: cat,
        limit,
        spent,
        percentage: pct,
        isWarning: pct >= 80 && pct < 100,
        isExceeded: pct >= 100,
      };
    })
    .sort((a, b) => b.percentage - a.percentage);

  const handleEditClick = (categoryId: string, currentLimit: number) => {
    setEditingBudgetCategory(categoryId);
    setBudgetLimitInput(currentLimit.toString());
  };

  const handleSaveCategoryBudget = (categoryId: string) => {
    const val = parseFloat(budgetLimitInput);
    if (!isNaN(val) && val > 0) {
      onSaveBudget({
        id: `b_${categoryId}_${summary.month}`,
        categoryId,
        month: summary.month,
        limitAmount: roundTo2Decimals(val),
      });
    }
    setEditingBudgetCategory(null);
  };

  return (
    <div className="flex flex-col gap-5 pb-28">
      {/* Top Header */}
      <div className="flex items-center justify-between px-1">
        <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          {isAr ? 'الميزانية' : 'Budget'}
        </h1>
        <MonthSwitcher month={summary.month} onChange={onChangeMonth} isAr={isAr} />
      </div>

      {/* Big Circular Progress Gauge Card matching reference */}
      <div
        className={`p-6 rounded-3xl flex flex-col items-center justify-center text-center ${
          isDark ? 'glass-card-dark' : 'glass-card-light'
        }`}
      >
        <div className="relative w-48 h-48 flex items-center justify-center">
          <svg className="w-48 h-48 -rotate-90 transform" viewBox="0 0 160 160">
            {/* Background Track */}
            <circle
              cx="80"
              cy="80"
              r={gaugeRadius}
              className="text-slate-100 dark:text-slate-800"
              strokeWidth="14"
              stroke="currentColor"
              fill="transparent"
            />
            {/* Progress Arc */}
            <circle
              cx="80"
              cy="80"
              r={gaugeRadius}
              stroke={progressPct > 100 ? '#ef4444' : progressPct > 80 ? '#f59e0b' : '#0d9488'}
              strokeWidth="14"
              strokeDasharray={gaugeCircumference}
              strokeDashoffset={gaugeOffset}
              strokeLinecap="round"
              fill="transparent"
              className="transition-all duration-1000 ease-out"
            />
          </svg>

          {/* Centered Figure in Gauge */}
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-3xl font-extrabold text-slate-900 dark:text-white tabular-nums tracking-tight">
              {progressPct}%
            </span>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-1">
              {isAr ? 'من الميزانية الشهرية' : 'of monthly budget'}
            </span>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 tabular-nums mt-0.5">
              {formatAmount(totalSpent)} / {formatAmount(totalLimit)}
            </span>
          </div>
        </div>

        {/* Edit the overall monthly budget */}
        {editingBudgetCategory === 'total' ? (
          <div className="mt-3 p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center gap-2 w-full">
            <input
              type="number"
              value={budgetLimitInput}
              onChange={(e) => setBudgetLimitInput(e.target.value)}
              className="flex-1 px-2 py-1 rounded-lg bg-white dark:bg-slate-900 text-xs font-bold tabular-nums border border-slate-300 dark:border-slate-700 outline-none"
              autoFocus
            />
            <button
              onClick={() => handleSaveCategoryBudget('total')}
              className="p-1.5 rounded-lg bg-emerald-600 text-white"
              aria-label="Save"
            >
              <Check size={14} />
            </button>
            <button
              onClick={() => setEditingBudgetCategory(null)}
              className="p-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500"
              aria-label="Cancel"
            >
              <X size={14} />
            </button>
          </div>
        ) : (
          <button
            onClick={() => handleEditClick('total', totalLimit)}
            className="mt-3 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 hover:underline"
          >
            <Edit2 size={12} />
            {isAr ? 'تعديل الميزانية الشهرية' : 'Edit monthly budget'}
          </button>
        )}

        {/* Status text */}
        <div className="mt-4 text-xs font-medium text-slate-600 dark:text-slate-300 flex items-center gap-2">
          {progressPct >= 100 ? (
            <span className="text-rose-600 dark:text-rose-400 font-bold flex items-center gap-1">
              <AlertTriangle size={14} />
              {isAr ? 'تم تجاوز الميزانية الشهرية!' : 'Monthly budget exceeded!'}
            </span>
          ) : progressPct >= 80 ? (
            <span className="text-amber-600 dark:text-amber-400 font-bold flex items-center gap-1">
              <AlertTriangle size={14} />
              {isAr ? 'تنبيه: اقتربت من حد الميزانية (80%+)' : 'Warning: Approaching 80% limit'}
            </span>
          ) : (
            <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
              <Sparkles size={14} />
              {isAr
                ? `متبقي ${formatAmount(summary.remainingBudget)} حتى نهاية الشهر`
                : `${formatAmount(summary.remainingBudget)} remaining until month end`}
            </span>
          )}
        </div>
      </div>

      {/* Categories Budget List matching reference */}
      <div
        className={`p-5 rounded-3xl ${
          isDark ? 'glass-card-dark' : 'glass-card-light'
        }`}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            {isAr ? 'الفئات' : 'Categories'}
          </h2>
          <span className="text-xs text-slate-400">
            {isAr ? 'الحد والنسبة' : 'Limit & Ratio'}
          </span>
        </div>

        <div className="space-y-4">
          {categoryBudgets.map((item) => (
            <div key={item.category.id} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CategoryIcon iconName={item.category.icon} color={item.category.color} />
                  <div>
                    <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                      {isAr ? item.category.nameAr : item.category.nameEn}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5 tabular-nums">
                      {formatAmount(item.spent)} {isAr ? 'من' : 'of'} {formatAmount(item.limit)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="text-right">
                    <span
                      className={`text-xs font-bold tabular-nums ${
                        item.isExceeded
                          ? 'text-rose-600 dark:text-rose-400'
                          : item.isWarning
                          ? 'text-amber-600 dark:text-amber-400'
                          : 'text-slate-900 dark:text-white'
                      }`}
                    >
                      {item.percentage}%
                    </span>
                  </div>

                  <button
                    onClick={() => handleEditClick(item.category.id, item.limit)}
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                    title={isAr ? 'تعديل الحد' : 'Edit Limit'}
                  >
                    <Edit2 size={13} />
                  </button>
                </div>
              </div>

              {/* Edit form inline if selected */}
              {editingBudgetCategory === item.category.id && (
                <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center gap-2 animate-in fade-in">
                  <span className="text-xs text-slate-500 font-medium">
                    {isAr ? `الحد الشهري (${settings.currency}):` : `Limit (${settings.currency}):`}
                  </span>
                  <input
                    type="number"
                    value={budgetLimitInput}
                    onChange={(e) => setBudgetLimitInput(e.target.value)}
                    className="flex-1 px-2 py-1 rounded-lg bg-white dark:bg-slate-900 text-xs font-bold tabular-nums border border-slate-300 dark:border-slate-700 outline-none"
                    autoFocus
                  />
                  <button
                    onClick={() => handleSaveCategoryBudget(item.category.id)}
                    className="p-1.5 rounded-lg bg-emerald-600 text-white"
                  >
                    <Check size={14} />
                  </button>
                  <button
                    onClick={() => setEditingBudgetCategory(null)}
                    className="p-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500"
                  >
                    <X size={14} />
                  </button>
                </div>
              )}

              {/* Progress bar */}
              <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(100, item.percentage)}%`,
                    backgroundColor:
                      item.isExceeded
                        ? '#ef4444'
                        : item.isWarning
                        ? '#f59e0b'
                        : item.category.color,
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
