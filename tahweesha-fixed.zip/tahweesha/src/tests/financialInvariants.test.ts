/**
 * Tahweesha (تحويشة) - Comprehensive Financial Calculation & Invariant Tests
 * Tests all accounting rules, balance equations, transfer neutrality,
 * duplicate detection, and statement reconciliation.
 */

import {
  calculateAccountBalance,
  calculateTotalBalance,
  generateTransactionFingerprint,
  reconcileStatement,
  calculateMonthlySummary,
  roundTo2Decimals,
  formatCurrency,
  todayISO,
  shiftMonth,
} from '../utils/financialMath';
import { groupItemsIntoRows } from '../services/pdfExtract';
import { SYNTHETIC_STATEMENTS } from '../services/statementParser';
import { INITIAL_TRANSACTIONS } from '../data/initialData';
import {
  detectColumnMapping,
  normalizeDate,
  normalizeNumber,
  parseCSVText,
  processStatementMatrix,
  guessCategoryFromDescription,
} from '../services/statementParser';
import { Account, Transaction, Category, Budget } from '../types/finance';

export function runAllFinancialTests(): { passed: number; failed: number; results: string[] } {
  let passed = 0;
  let failed = 0;
  const results: string[] = [];

  function assert(condition: boolean, testName: string) {
    if (condition) {
      passed++;
      results.push(`✓ [PASS] ${testName}`);
    } else {
      failed++;
      results.push(`✗ [FAIL] ${testName}`);
      console.error(`Test failed: ${testName}`);
    }
  }

  // --- Test 1: Precision Arithmetic (avoiding binary float drift) ---
  const sum = roundTo2Decimals(0.1 + 0.2);
  assert(sum === 0.3, 'Precision: 0.1 + 0.2 equals exactly 0.30');

  // --- Test 2: Account Balance Invariant ---
  const testAccount: Account = {
    id: 'acc_test',
    name: 'حساب تجريبي',
    nameEn: 'Test Account',
    type: 'bank',
    currency: 'AED',
    openingBalance: 1000.0,
    openingDate: '2025-01-01',
    color: '#059669',
    icon: 'Building2',
  };

  const testTransactions: Transaction[] = [
    {
      id: 't1',
      date: '2025-10-01',
      amount: 500.0,
      type: 'income',
      categoryId: 'cat_salary',
      accountId: 'acc_test',
      description: 'راتب',
      source: 'manual',
      status: 'verified',
      fingerprint: 'fp1',
    },
    {
      id: 't2',
      date: '2025-10-02',
      amount: 200.0,
      type: 'expense',
      categoryId: 'cat_dining',
      accountId: 'acc_test',
      description: 'مطعم',
      source: 'manual',
      status: 'verified',
      fingerprint: 'fp2',
    },
  ];

  const calculatedBal = calculateAccountBalance(testAccount, testTransactions);
  assert(calculatedBal === 1300.0, 'Balance: 1000 opening + 500 income - 200 expense = 1300');

  // --- Test 3: Transfer Neutrality ---
  const savingsAccount: Account = {
    id: 'acc_savings',
    name: 'حساب توفير',
    nameEn: 'Savings Account',
    type: 'savings',
    currency: 'AED',
    openingBalance: 2000.0,
    openingDate: '2025-01-01',
    color: '#7c3aed',
    icon: 'PiggyBank',
  };

  const transferTx: Transaction = {
    id: 't_trf',
    date: '2025-10-03',
    amount: 300.0,
    type: 'transfer',
    categoryId: 'cat_transfer',
    accountId: 'acc_test',
    destinationAccountId: 'acc_savings',
    description: 'تحويل للتوفير',
    source: 'manual',
    status: 'verified',
    fingerprint: 'fp_trf',
  };

  const allTx = [...testTransactions, transferTx];
  const sourceBal = calculateAccountBalance(testAccount, allTx);
  const destBal = calculateAccountBalance(savingsAccount, allTx);
  const totalNet = calculateTotalBalance([testAccount, savingsAccount], allTx);

  assert(sourceBal === 1000.0, 'Transfer: Source account balance decreased by 300 (1300 -> 1000)');
  assert(destBal === 2300.0, 'Transfer: Destination account balance increased by 300 (2000 -> 2300)');
  assert(totalNet === 3300.0, 'Transfer Neutrality: Combined aggregate net funds remain exactly 3300');

  // --- Test 4: Statement Balance Reconciliation ---
  const reconcileOk = reconcileStatement(1000.0, 1300.0, [
    { type: 'income', amount: 500.0 },
    { type: 'expense', amount: 200.0 },
  ]);
  assert(reconcileOk.isReconciled === true, 'Reconciliation: Valid statement matches closing balance (1300)');
  assert(reconcileOk.difference === 0, 'Reconciliation: Variance difference is exactly 0.00');

  const reconcileMismatch = reconcileStatement(1000.0, 1500.0, [
    { type: 'income', amount: 500.0 },
    { type: 'expense', amount: 200.0 },
  ]);
  assert(reconcileMismatch.isReconciled === false, 'Reconciliation: Detects discrepancy if closing is 1500 vs 1300 calculated');
  assert(reconcileMismatch.difference === 200.0, 'Reconciliation: Accurately reports +200 variance');

  // --- Test 5: Deterministic Duplicate Fingerprint ---
  const fp1 = generateTransactionFingerprint('2025-10-21', 180.0, 'POS DEBIT - ZAHRAT AL LAYMOUN');
  const fp2 = generateTransactionFingerprint('2025-10-21', 180.0, 'POS DEBIT - zahrat al laymoun');
  assert(fp1 === fp2, 'Fingerprint: Case and whitespace normalization yields identical hash for duplicates');

  const fpDifferentAmount = generateTransactionFingerprint('2025-10-21', 180.5, 'POS DEBIT - ZAHRAT AL LAYMOUN');
  assert(fp1 !== fpDifferentAmount, 'Fingerprint: Different amounts produce distinct hashes');

  // --- Test 6: Date & Number Normalization ---
  assert(normalizeDate('2025/10/21') === '2025-10-21', 'Normalize Date: YYYY/MM/DD -> YYYY-MM-DD');
  assert(normalizeDate('21/10/2025') === '2025-10-21', 'Normalize Date: DD/MM/YYYY -> YYYY-MM-DD');
  assert(normalizeDate('15-Oct-2025') === '2025-10-15', 'Normalize Date: DD-Mon-YYYY -> YYYY-MM-DD');

  assert(normalizeNumber('1,250.50') === 1250.5, 'Normalize Number: Commas in 1,250.50 parsed to 1250.5');
  assert(normalizeNumber('(180.00)') === -180.0, 'Normalize Number: Parentheses (180.00) parsed as negative -180.0');
  assert(normalizeNumber('AED 3,450.00 CR') === 3450.0, 'Normalize Number: Currency prefix and CR parsed cleanly');

  // --- Test 7: CSV Statement Matrix Parser ---
  const csvContent = `Date,Particulars,Debit,Credit,Balance
2025/10/21,ZAHRAT AL LAYMOUN,180.00,,23450.00
2025/10/20,WPS SALARY TRANSFER,,8000.00,23630.00`;
  const matrix = parseCSVText(csvContent);
  assert(matrix.length === 3, 'CSV Parser: Extracted 3 rows (header + 2 transactions)');

  const parseResult = processStatementMatrix(matrix, 'test.csv', 'csv', []);
  assert(parseResult.candidateRows.length === 2, 'Statement Matrix: Extracted 2 candidate transactions');
  assert(parseResult.candidateRows[0].amount === 180.0, 'Statement Matrix: Row 1 amount is 180.00');
  assert(parseResult.candidateRows[0].type === 'expense', 'Statement Matrix: Debit row mapped to expense');
  assert(parseResult.candidateRows[1].amount === 8000.0, 'Statement Matrix: Row 2 amount is 8000.00');
  assert(parseResult.candidateRows[1].type === 'income', 'Statement Matrix: Credit row mapped to income');

  // --- Test 8: Heuristic Category Detection ---
  assert(guessCategoryFromDescription('CARREFOUR MOE') === 'cat_shopping', 'Category: Carrefour recognized as Shopping');
  assert(guessCategoryFromDescription('STARBUCKS COFFEE') === 'cat_dining', 'Category: Starbucks recognized as Dining');
  assert(guessCategoryFromDescription('WPS PAYROLL SALARY') === 'cat_salary', 'Category: WPS Payroll recognized as Salary');
  assert(guessCategoryFromDescription('DEWA UTILITY PAYMENT') === 'cat_housing', 'Category: DEWA recognized as Housing');
  assert(guessCategoryFromDescription('ENOC PETROL STATION') === 'cat_transport', 'Category: ENOC recognized as Transport');

  // --- Test 9: Regression tests for fixed bugs ---
  assert(guessCategoryFromDescription('SOME SHOP DUBAI') === 'cat_other', 'Category: the word "Dubai" alone is not a utility bill');
  assert(guessCategoryFromDescription('DIVIDEND DISTRIBUTION') === 'cat_investments', 'Category: dividend recognized as Investments');
  assert(normalizeDate('45951') === '2025-10-21', 'Normalize Date: Excel serial 45951 -> 2025-10-21');
  assert(normalizeDate('31/02/2025') === null, 'Normalize Date: impossible date rejected');
  assert(normalizeDate('10/21/2025') === '2025-10-21', 'Normalize Date: month-first fallback when day-first is impossible');
  assert(normalizeDate('Oct 21, 2025') === '2025-10-21', 'Normalize Date: textual date uses local calendar day');
  assert(todayISO(new Date(2025, 9, 21, 1, 0)) === '2025-10-21', 'todayISO: 01:00 local stays on the local day');
  assert(shiftMonth('2025-01', -1) === '2024-12' && shiftMonth('2025-12', 1) === '2026-01', 'shiftMonth: wraps across years');
  assert(formatCurrency(23450, 'AED', 'ar') === 'AED 23,450.00', 'formatCurrency: Latin digits in Arabic mode');

  const prevTx: Transaction[] = [
    { id: 'p1', date: '2025-09-10', amount: 1000, type: 'income', categoryId: 'cat_salary', accountId: 'a', description: 'x', source: 'manual', status: 'verified', fingerprint: 'p1' },
    { id: 'p2', date: '2025-10-10', amount: 1500, type: 'income', categoryId: 'cat_salary', accountId: 'a', description: 'x', source: 'manual', status: 'verified', fingerprint: 'p2' },
  ];
  const cmp = calculateMonthlySummary('2025-10', prevTx, [], []);
  assert(cmp.incomeChangePct === 50 && cmp.hasPreviousIncome, 'Monthly summary: income change vs previous month is computed (+50%)');
  assert(!cmp.hasPreviousExpenses, 'Monthly summary: no fake expense comparison without previous data');

  const nbd = SYNTHETIC_STATEMENTS.emiratesNBD_CSV;
  const nbdResult = processStatementMatrix(parseCSVText(nbd.data), nbd.name, 'csv', INITIAL_TRANSACTIONS);
  assert(nbdResult.isReconciled && nbdResult.openingBalance === 17100 && nbdResult.closingBalance === 23450,
    'Import: newest-first statement derives opening 17,100 / closing 23,450 and reconciles');

  const amb = SYNTHETIC_STATEMENTS.ambiguous_CSV;
  const ambResult = processStatementMatrix(parseCSVText(amb.data), amb.name, 'csv', INITIAL_TRANSACTIONS);
  assert(ambResult.duplicateCount >= 3 && !ambResult.isReconciled, 'Import: duplicate/variance statement is flagged and not reconciled');

  const excelLike = [
    ['Date', 'Description', 'Amount'],
    [45951, 'Carrefour', -120.5],
    [45950, 'Salary', 5000],
  ] as unknown as string[][];
  const excelResult = processStatementMatrix(excelLike, 'x.xlsx', 'excel', []);
  assert(excelResult.candidateRows.length === 2 && excelResult.candidateRows[0].normalizedDate === '2025-10-21',
    'Import: Excel rows with numeric dates/amounts no longer crash');

  const pdfRows = groupItemsIntoRows([
    { str: 'Date', x: 40, y: 350, width: 20 }, { str: 'Particulars', x: 120, y: 350, width: 50 },
    { str: 'Debit', x: 330, y: 350, width: 25 }, { str: 'Credit', x: 400, y: 350, width: 25 },
    { str: '2025/10/20', x: 40, y: 330, width: 50 }, { str: 'WPS SALARY', x: 120, y: 330, width: 60 },
    { str: '8000.00', x: 400, y: 330, width: 35 },
  ]);
  assert(pdfRows[1][2] === '' && pdfRows[1][3] === '8000.00', 'PDF: empty Debit cell keeps the credit in the Credit column');

  return { passed, failed, results };
}
