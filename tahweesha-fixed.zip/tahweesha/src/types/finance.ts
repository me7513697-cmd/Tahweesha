/**
 * Tahweesha (تحويشة) - Domain Types
 * Core financial data structures, strict typing, and multi-currency support.
 */

export type TransactionType = 'income' | 'expense' | 'transfer';

export type TransactionSource = 'manual' | 'statement_import';

export type TransactionReviewStatus = 'verified' | 'reviewed' | 'uncertain';

export interface Transaction {
  id: string;
  date: string; // ISO format: YYYY-MM-DD
  amount: number; // Stored in major units with 2 decimal precision (e.g. 180.00)
  type: TransactionType;
  categoryId: string;
  accountId: string;
  destinationAccountId?: string; // For transfers between own accounts
  description: string;
  originalDescription?: string; // From bank statement for auditing
  notes?: string;
  source: TransactionSource;
  importBatchId?: string;
  status: TransactionReviewStatus;
  fingerprint: string; // Hash of date + amount + sanitized description for deduplication
  referenceNumber?: string;
}

export type AccountType = 'bank' | 'wallet' | 'savings' | 'credit';

export interface Account {
  id: string;
  name: string;
  nameEn: string;
  type: AccountType;
  currency: string; // 'AED', etc.
  openingBalance: number;
  openingDate: string;
  color: string;
  icon: string;
  accountNumberMask?: string;
  lastReconciliationDate?: string;
}

export interface Category {
  id: string;
  nameAr: string;
  nameEn: string;
  icon: string;
  color: string;
  type: 'expense' | 'income' | 'both';
  isDefault?: boolean;
}

export interface Budget {
  id: string;
  categoryId: string | 'total'; // 'total' for global monthly budget
  month: string; // YYYY-MM
  limitAmount: number;
}

export interface SavingsGoal {
  id: string;
  name: string;
  nameEn: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  category: string;
  icon: string;
  color: string;
}

export interface RecurringBill {
  id: string;
  name: string;
  nameEn: string;
  amount: number;
  dueDate: string; // YYYY-MM-DD
  frequency: 'monthly' | 'yearly' | 'weekly';
  isPaid: boolean;
  categoryId: string;
  icon: string;
  autoRemind?: boolean;
}

export interface ImportBatch {
  id: string;
  fileName: string;
  fileType: 'pdf' | 'excel' | 'csv';
  importedAt: string;
  totalRows: number;
  acceptedCount: number;
  duplicateCount: number;
  skippedCount: number;
  openingBalance?: number;
  closingBalance?: number;
  calculatedClosingBalance?: number;
  isReconciled: boolean;
  reconciliationDifference?: number;
}

export interface AppSettings {
  language: 'ar' | 'en';
  currency: 'AED' | 'USD' | 'EUR' | 'SAR' | 'EGP';
  theme: 'light' | 'dark' | 'system';
  biometricEnabled: boolean;
  hideBalance: boolean;
  currentMonth: string; // '2025-10'
  selectedAccountId: string | 'all';
  userName?: string;
}

export interface MonthlyFinancialSummary {
  month: string; // YYYY-MM
  totalIncome: number;
  totalExpenses: number;
  netCashFlow: number;
  savingsRate: number; // percentage (0-100)
  totalBudget: number;
  budgetSpent: number;
  remainingBudget: number;
  budgetProgressPct: number;
  incomeChangePct: number; // e.g. +12
  expenseChangePct: number; // e.g. -8
  hasPreviousIncome: boolean; // false when the previous month has no income to compare with
  hasPreviousExpenses: boolean;
  categoryBreakdown: {
    category: Category;
    amount: number;
    percentage: number;
  }[];
}
