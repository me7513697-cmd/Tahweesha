/**
 * Tahweesha (تحويشة) - Financial Math & Accounting Invariants
 * Precision arithmetic, balance calculators, duplicate fingerprinting, and reconciliation.
 */

import { Transaction, Account, MonthlyFinancialSummary, Category, Budget } from '../types/finance';

/**
 * Rounding to 2 decimal places to avoid floating point precision drift
 */
export function roundTo2Decimals(val: number): number {
  return Math.round((val + Number.EPSILON) * 100) / 100;
}

/**
 * Format currency amount with proper sign, thousand separators, and currency code.
 */
/** Local calendar date as YYYY-MM-DD (toISOString would shift the day in UTC+4). */
export function todayISO(d: Date = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/** Current month as YYYY-MM (local time). */
export function currentMonthKey(): string {
  return todayISO().slice(0, 7);
}

/** Shift a YYYY-MM key by N months. */
export function shiftMonth(month: string, delta: number): string {
  const [y, m] = month.split('-').map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export function formatMonthLabel(month: string, language: 'ar' | 'en'): string {
  const [y, m] = month.split('-').map(Number);
  const ar = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
  const en = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  return `${(language === 'ar' ? ar : en)[m - 1]} ${y}`;
}

export function formatCurrency(
  amount: number,
  currency: string = 'AED',
  language: 'ar' | 'en' = 'ar',
  options?: { showPlusSign?: boolean; hideDecimals?: boolean }
): string {
  const rounded = roundTo2Decimals(Math.abs(amount));
  // Always Latin digits, consistent with the design reference (AED 23,450.00)
  const locale = language === 'ar' ? 'ar-AE-u-nu-latn' : 'en-US';
  const formattedNumber = options?.hideDecimals
    ? Math.round(rounded).toLocaleString(locale)
    : rounded.toLocaleString(locale, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });

  const sign = amount < 0 ? '-' : (options?.showPlusSign && amount > 0 ? '+' : '');

  if (language === 'ar') {
    // Reference format: AED 23,450.00 or - AED 180
    return sign ? `${sign} ${currency} ${formattedNumber}` : `${currency} ${formattedNumber}`;
  } else {
    return sign ? `${sign} ${currency} ${formattedNumber}` : `${currency} ${formattedNumber}`;
  }
}

/**
 * Generate a deterministic fingerprint for duplicate transaction detection
 */
export function generateTransactionFingerprint(
  date: string,
  amount: number,
  description: string
): string {
  const cleanDate = date.trim();
  const cleanAmount = Math.abs(roundTo2Decimals(amount)).toFixed(2);
  const cleanDesc = description
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]/gu, '') // Keep letters and numbers in any language (Arabic, English)
    .trim();

  return `${cleanDate}#${cleanAmount}#${cleanDesc}`;
}

/**
 * Calculate the exact balance of a single account given its opening balance and transactions.
 * Accounting Invariant:
 * Opening balance + Incomes - Expenses + Inward Transfers - Outward Transfers = Current Balance
 */
export function calculateAccountBalance(account: Account, transactions: Transaction[]): number {
  let balance = account.openingBalance;

  for (const tx of transactions) {
    if (tx.accountId === account.id) {
      if (tx.type === 'income') {
        balance = roundTo2Decimals(balance + tx.amount);
      } else if (tx.type === 'expense') {
        balance = roundTo2Decimals(balance - tx.amount);
      } else if (tx.type === 'transfer') {
        // Outward transfer from this account
        balance = roundTo2Decimals(balance - tx.amount);
      }
    } else if (tx.destinationAccountId === account.id && tx.type === 'transfer') {
      // Inward transfer to this account
      balance = roundTo2Decimals(balance + tx.amount);
    }
  }

  return roundTo2Decimals(balance);
}

/**
 * Calculate total aggregate balance across all accounts.
 * Internal transfers between owned accounts do NOT create or destroy money.
 */
export function calculateTotalBalance(accounts: Account[], transactions: Transaction[]): number {
  return roundTo2Decimals(
    accounts.reduce((sum, acc) => sum + calculateAccountBalance(acc, transactions), 0)
  );
}

/**
 * Validate Statement Balance Reconciliation:
 * Opening Balance + Sum(Credits) - Sum(Debits) === Closing Balance
 */
export interface ReconciliationResult {
  isReconciled: boolean;
  openingBalance: number;
  calculatedClosingBalance: number;
  reportedClosingBalance: number;
  difference: number;
  totalCredits: number;
  totalDebits: number;
  rowCount: number;
}

export function reconcileStatement(
  openingBalance: number,
  reportedClosingBalance: number,
  statementRows: { type: 'income' | 'expense' | 'transfer'; amount: number }[]
): ReconciliationResult {
  let totalCredits = 0;
  let totalDebits = 0;

  for (const row of statementRows) {
    const amt = Math.abs(roundTo2Decimals(row.amount));
    if (row.type === 'income') {
      totalCredits = roundTo2Decimals(totalCredits + amt);
    } else {
      totalDebits = roundTo2Decimals(totalDebits + amt);
    }
  }

  const calculatedClosingBalance = roundTo2Decimals(openingBalance + totalCredits - totalDebits);
  const difference = roundTo2Decimals(reportedClosingBalance - calculatedClosingBalance);
  const isReconciled = Math.abs(difference) < 0.01;

  return {
    isReconciled,
    openingBalance: roundTo2Decimals(openingBalance),
    calculatedClosingBalance,
    reportedClosingBalance: roundTo2Decimals(reportedClosingBalance),
    difference,
    totalCredits,
    totalDebits,
    rowCount: statementRows.length,
  };
}

/**
 * Calculate Monthly Summary for a specific month (YYYY-MM).
 * Internal transfers are excluded from monthly income and expenses.
 */
export function calculateMonthlySummary(
  month: string, // 'YYYY-MM'
  transactions: Transaction[],
  categories: Category[],
  budgets: Budget[],
  previousMonthTransactions?: Transaction[]
): MonthlyFinancialSummary {
  const currentMonthTx = transactions.filter((tx) => tx.date.startsWith(month));

  let totalIncome = 0;
  let totalExpenses = 0;
  const categorySpendingMap: Record<string, number> = {};

  for (const tx of currentMonthTx) {
    if (tx.type === 'income') {
      totalIncome = roundTo2Decimals(totalIncome + tx.amount);
    } else if (tx.type === 'expense') {
      totalExpenses = roundTo2Decimals(totalExpenses + tx.amount);
      const catId = tx.categoryId || 'other';
      categorySpendingMap[catId] = roundTo2Decimals((categorySpendingMap[catId] || 0) + tx.amount);
    }
    // Note: 'transfer' between user's own accounts is deliberately excluded
  }

  const netCashFlow = roundTo2Decimals(totalIncome - totalExpenses);
  const savingsRate = totalIncome > 0 ? Math.max(0, Math.min(100, Math.round((netCashFlow / totalIncome) * 100))) : 0;

  // Previous month comparison (computed from real data when not supplied)
  const prevTxs =
    previousMonthTransactions ??
    transactions.filter((tx) => tx.date.startsWith(shiftMonth(month, -1)));
  let prevIncome = 0;
  let prevExpenses = 0;
  for (const tx of prevTxs) {
    if (tx.type === 'income') prevIncome += tx.amount;
    if (tx.type === 'expense') prevExpenses += tx.amount;
  }

  const incomeChangePct = prevIncome > 0 ? Math.round(((totalIncome - prevIncome) / prevIncome) * 100) : 0;
  const expenseChangePct = prevExpenses > 0 ? Math.round(((totalExpenses - prevExpenses) / prevExpenses) * 100) : 0;
  const hasPreviousIncome = prevIncome > 0;
  const hasPreviousExpenses = prevExpenses > 0;

  // Monthly Budget
  const totalBudgetRecord = budgets.find((b) => b.month === month && b.categoryId === 'total');
  const totalBudget = totalBudgetRecord ? totalBudgetRecord.limitAmount : 10000;
  const budgetSpent = totalExpenses;
  const remainingBudget = roundTo2Decimals(Math.max(0, totalBudget - budgetSpent));
  const budgetProgressPct = totalBudget > 0 ? Math.round((budgetSpent / totalBudget) * 100) : 0;

  // Category Breakdown sorted by amount descending
  const categoryBreakdown = Object.entries(categorySpendingMap)
    .map(([catId, amount]) => {
      const cat = categories.find((c) => c.id === catId) || {
        id: catId,
        nameAr: 'أخرى',
        nameEn: 'Other',
        icon: 'MoreHorizontal',
        color: '#94a3b8',
        type: 'expense' as const,
      };
      const percentage = totalExpenses > 0 ? Math.round((amount / totalExpenses) * 100) : 0;
      return {
        category: cat,
        amount,
        percentage,
      };
    })
    .sort((a, b) => b.amount - a.amount);

  return {
    month,
    totalIncome,
    totalExpenses,
    netCashFlow,
    savingsRate,
    totalBudget,
    budgetSpent,
    remainingBudget,
    budgetProgressPct,
    incomeChangePct,
    expenseChangePct,
    hasPreviousIncome,
    hasPreviousExpenses,
    categoryBreakdown,
  };
}
