/**
 * Tahweesha - PDF statement text extraction (runs fully on-device with pdf.js).
 * Text-based PDFs only: scanned/image PDFs contain no text layer and cannot be read.
 */

export interface PdfTextItem {
  str: string;
  x: number; // left edge
  y: number; // baseline (PDF space: larger y = higher on the page)
  width: number;
}

interface Cell {
  text: string;
  x0: number;
  x1: number;
}

/** Group positioned text fragments into table rows; columns are split on visible gaps. */
export function groupItemsIntoRows(items: PdfTextItem[], yTolerance = 3, columnGap = 6): string[][] {
  const clean = items.filter((i) => i.str.trim().length > 0);
  clean.sort((a, b) => (Math.abs(b.y - a.y) <= yTolerance ? a.x - b.x : b.y - a.y));

  const lines: PdfTextItem[][] = [];
  for (const item of clean) {
    const line = lines[lines.length - 1];
    if (line && Math.abs(line[0].y - item.y) <= yTolerance) line.push(item);
    else lines.push([item]);
  }

  const cellLines: Cell[][] = lines.map((line) => {
    line.sort((a, b) => a.x - b.x);
    const cells: Cell[] = [];
    let cur: Cell | null = null;
    for (const it of line) {
      const end = it.x + it.width;
      if (cur && it.x - cur.x1 <= columnGap) {
        cur.text += (it.x - cur.x1 > 0.5 ? ' ' : '') + it.str;
        cur.x1 = end;
      } else {
        if (cur) cells.push(cur);
        cur = { text: it.str, x0: it.x, x1: end };
      }
    }
    if (cur) cells.push(cur);
    cells.forEach((c) => (c.text = c.text.trim()));
    return cells;
  });

  // Align cells to the header row's columns so empty cells (e.g. blank Debit) keep their position
  const headerIdx = cellLines.findIndex((cells) => {
    const j = cells.map((c) => c.text).join(' ').toLowerCase();
    return cells.length >= 3 && (j.includes('date') || j.includes('تاريخ'));
  });
  if (headerIdx === -1) return cellLines.map((cells) => cells.map((c) => c.text));

  const anchors = cellLines[headerIdx].map((c) => (c.x0 + c.x1) / 2);
  return cellLines.map((cells, idx) => {
    if (idx <= headerIdx) return cells.map((c) => c.text);
    const row: string[] = anchors.map(() => '');
    for (const c of cells) {
      const center = (c.x0 + c.x1) / 2;
      let best = 0;
      for (let k = 1; k < anchors.length; k++) {
        if (Math.abs(anchors[k] - center) < Math.abs(anchors[best] - center)) best = k;
      }
      row[best] = row[best] ? `${row[best]} ${c.text}` : c.text;
    }
    return row;
  });
}

/** Extract table-like rows from every page of a PDF. */
export async function extractPdfRows(buffer: ArrayBuffer): Promise<string[][]> {
  const pdfjs = await import('pdfjs-dist');
  const worker = await import('pdfjs-dist/build/pdf.worker.min.mjs?url');
  pdfjs.GlobalWorkerOptions.workerSrc = worker.default;

  const doc = await pdfjs.getDocument({ data: new Uint8Array(buffer) }).promise;
  const rows: string[][] = [];
  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p);
    const content = await page.getTextContent();
    const items: PdfTextItem[] = (content.items as any[])
      .filter((i) => typeof i.str === 'string' && Array.isArray(i.transform))
      .map((i) => ({ str: i.str, x: i.transform[4], y: i.transform[5], width: i.width || 0 }));
    rows.push(...groupItemsIntoRows(items));
  }
  return rows;
}
