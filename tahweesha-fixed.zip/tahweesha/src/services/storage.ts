/**
 * Tahweesha (تحويشة) - Local Storage & Persistence Service
 * Local-first architecture: all user data is stored safely in the browser's localStorage.
 * No external servers or cloud accounts required.
 */

import {
  Transaction,
  Account,
  Category,
  Budget,
  SavingsGoal,
  RecurringBill,
  AppSettings,
  ImportBatch,
} from '../types/finance';
import {
  INITIAL_ACCOUNTS,
  INITIAL_APP_SETTINGS,
  INITIAL_BUDGETS,
  INITIAL_CATEGORIES,
  INITIAL_RECURRING_BILLS,
  INITIAL_SAVINGS_GOALS,
  INITIAL_TRANSACTIONS,
} from '../data/initialData';
import { currentMonthKey, todayISO } from '../utils/financialMath';

const STORAGE_KEYS = {
  TRANSACTIONS: 'tahweesha_transactions_v1',
  ACCOUNTS: 'tahweesha_accounts_v1',
  CATEGORIES: 'tahweesha_categories_v1',
  BUDGETS: 'tahweesha_budgets_v1',
  GOALS: 'tahweesha_goals_v1',
  BILLS: 'tahweesha_bills_v1',
  SETTINGS: 'tahweesha_settings_v1',
  IMPORT_BATCHES: 'tahweesha_batches_v1',
};

// In-memory fallback when localStorage is unavailable (private mode, quota, etc.)
const memoryStore = new Map<string, string>();

function safeGet(key: string): string | null {
  try {
    const v = localStorage.getItem(key);
    return v !== null ? v : memoryStore.get(key) ?? null;
  } catch {
    return memoryStore.get(key) ?? null;
  }
}

function safeSet(key: string, value: string): void {
  memoryStore.set(key, value);
  try {
    localStorage.setItem(key, value);
  } catch (e) {
    console.error('localStorage write failed, keeping in memory only:', e);
  }
}

function safeRemove(key: string): void {
  memoryStore.delete(key);
  try {
    localStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}

const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v));

/** Read a JSON array; seeds defaults on first run; never returns shared constants. */
function readArray<T>(key: string, defaults: T[], seed: (v: T[]) => void): T[] {
  const raw = safeGet(key);
  if (!raw) {
    const d = clone(defaults);
    seed(d);
    return clone(d);
  }
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : clone(defaults);
  } catch {
    return clone(defaults);
  }
}

class StorageService {
  private listeners: Set<() => void> = new Set();

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((listener) => {
      try {
        listener();
      } catch (e) {
        console.error('Error notifying storage listener:', e);
      }
    });
  }

  // --- Transactions ---
  public getTransactions(): Transaction[] {
    return readArray<Transaction>(STORAGE_KEYS.TRANSACTIONS, INITIAL_TRANSACTIONS, (v) => this.setTransactions(v));
  }

  public setTransactions(txs: Transaction[]): void {
    safeSet(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(txs));
    this.notify();
  }

  public addTransaction(tx: Transaction): void {
    const list = this.getTransactions();
    list.unshift(tx);
    this.setTransactions(list);
  }

  public updateTransaction(tx: Transaction): void {
    const list = this.getTransactions();
    const idx = list.findIndex((item) => item.id === tx.id);
    if (idx !== -1) {
      list[idx] = tx;
      this.setTransactions(list);
    }
  }

  public deleteTransaction(id: string): void {
    const list = this.getTransactions().filter((item) => item.id !== id);
    this.setTransactions(list);
  }

  // --- Accounts ---
  public getAccounts(): Account[] {
    return readArray<Account>(STORAGE_KEYS.ACCOUNTS, INITIAL_ACCOUNTS, (v) => this.setAccounts(v));
  }

  public setAccounts(accounts: Account[]): void {
    safeSet(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));
    this.notify();
  }

  public updateAccount(account: Account): void {
    const list = this.getAccounts();
    const idx = list.findIndex((a) => a.id === account.id);
    if (idx !== -1) {
      list[idx] = account;
      this.setAccounts(list);
    }
  }

  // --- Categories ---
  public getCategories(): Category[] {
    return readArray<Category>(STORAGE_KEYS.CATEGORIES, INITIAL_CATEGORIES, (v) => this.setCategories(v));
  }

  public setCategories(cats: Category[]): void {
    safeSet(STORAGE_KEYS.CATEGORIES, JSON.stringify(cats));
    this.notify();
  }

  // --- Budgets ---
  public getBudgets(): Budget[] {
    return readArray<Budget>(STORAGE_KEYS.BUDGETS, INITIAL_BUDGETS, (v) => this.setBudgets(v));
  }

  public setBudgets(budgets: Budget[]): void {
    safeSet(STORAGE_KEYS.BUDGETS, JSON.stringify(budgets));
    this.notify();
  }

  public saveBudget(budget: Budget): void {
    const list = this.getBudgets();
    const idx = list.findIndex((b) => b.categoryId === budget.categoryId && b.month === budget.month);
    if (idx !== -1) {
      list[idx] = budget;
    } else {
      list.push(budget);
    }
    this.setBudgets(list);
  }

  // --- Savings Goals ---
  public getSavingsGoals(): SavingsGoal[] {
    return readArray<SavingsGoal>(STORAGE_KEYS.GOALS, INITIAL_SAVINGS_GOALS, (v) => this.setSavingsGoals(v));
  }

  public setSavingsGoals(goals: SavingsGoal[]): void {
    safeSet(STORAGE_KEYS.GOALS, JSON.stringify(goals));
    this.notify();
  }

  public updateSavingsGoal(goal: SavingsGoal): void {
    const list = this.getSavingsGoals();
    const idx = list.findIndex((g) => g.id === goal.id);
    if (idx !== -1) {
      list[idx] = goal;
      this.setSavingsGoals(list);
    }
  }

  public addSavingsGoal(goal: SavingsGoal): void {
    const list = this.getSavingsGoals();
    list.push(goal);
    this.setSavingsGoals(list);
  }

  // --- Recurring Bills ---
  public getRecurringBills(): RecurringBill[] {
    return readArray<RecurringBill>(STORAGE_KEYS.BILLS, INITIAL_RECURRING_BILLS, (v) => this.setRecurringBills(v));
  }

  public setRecurringBills(bills: RecurringBill[]): void {
    safeSet(STORAGE_KEYS.BILLS, JSON.stringify(bills));
    this.notify();
  }

  public toggleBillPaid(billId: string): void {
    const list = this.getRecurringBills();
    const bill = list.find((b) => b.id === billId);
    if (bill) {
      bill.isPaid = !bill.isPaid;
      this.setRecurringBills(list);
    }
  }

  // --- Settings ---
  public getSettings(): AppSettings {
    const raw = safeGet(STORAGE_KEYS.SETTINGS);
    if (!raw) {
      const d = { ...INITIAL_APP_SETTINGS };
      this.setSettings(d);
      return { ...d };
    }
    try {
      const parsed = JSON.parse(raw);
      return { ...INITIAL_APP_SETTINGS, ...(parsed && typeof parsed === 'object' ? parsed : {}) };
    } catch {
      return { ...INITIAL_APP_SETTINGS };
    }
  }

  public setSettings(settings: AppSettings): void {
    safeSet(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    this.notify();
  }

  public updateSettings(partial: Partial<AppSettings>): void {
    const current = this.getSettings();
    this.setSettings({ ...current, ...partial });
  }

  // --- Import Batches ---
  public getImportBatches(): ImportBatch[] {
    const raw = safeGet(STORAGE_KEYS.IMPORT_BATCHES);
    if (!raw) return [];
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  public addImportBatch(batch: ImportBatch, transactions: Transaction[]): void {
    const batches = this.getImportBatches();
    batches.unshift(batch);
    safeSet(STORAGE_KEYS.IMPORT_BATCHES, JSON.stringify(batches));

    const currentTx = this.getTransactions();
    const updatedTx = [...transactions, ...currentTx];
    this.setTransactions(updatedTx);
  }

  // --- Reset & Export ---
  public resetToDemoData(): void {
    const prefs = this.getSettings();
    this.setTransactions(clone(INITIAL_TRANSACTIONS));
    this.setAccounts(clone(INITIAL_ACCOUNTS));
    this.setCategories(clone(INITIAL_CATEGORIES));
    this.setBudgets(clone(INITIAL_BUDGETS));
    this.setSavingsGoals(clone(INITIAL_SAVINGS_GOALS));
    this.setRecurringBills(clone(INITIAL_RECURRING_BILLS));
    safeRemove(STORAGE_KEYS.IMPORT_BATCHES);
    // Keep the user's own preferences, only reset the data scope
    this.setSettings({
      ...INITIAL_APP_SETTINGS,
      language: prefs.language,
      theme: prefs.theme,
      currency: prefs.currency,
      hideBalance: prefs.hideBalance,
      biometricEnabled: prefs.biometricEnabled,
      userName: prefs.userName,
    });
  }

  public clearAllData(): void {
    const emptyAccounts: Account[] = [
      {
        id: 'acc_primary',
        name: 'الحساب الرئيسي',
        nameEn: 'Primary Account',
        type: 'bank',
        currency: 'AED',
        openingBalance: 0,
        openingDate: todayISO(),
        color: '#059669',
        icon: 'Building2',
      },
    ];
    this.setTransactions([]);
    this.setAccounts(emptyAccounts);
    this.setBudgets([]);
    this.setSavingsGoals([]);
    this.setRecurringBills([]);
    safeRemove(STORAGE_KEYS.IMPORT_BATCHES);
    // Stale selection / demo month would otherwise point at data that no longer exists
    this.setSettings({
      ...this.getSettings(),
      selectedAccountId: 'all',
      currentMonth: currentMonthKey(),
    });
  }

  public exportBackupJSON(): string {
    const backup = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      transactions: this.getTransactions(),
      accounts: this.getAccounts(),
      categories: this.getCategories(),
      budgets: this.getBudgets(),
      goals: this.getSavingsGoals(),
      bills: this.getRecurringBills(),
      settings: this.getSettings(),
    };
    return JSON.stringify(backup, null, 2);
  }

  public restoreBackupJSON(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (!data || typeof data !== 'object') return false;
      const hasAny = ['transactions', 'accounts', 'categories', 'budgets', 'goals', 'bills', 'settings'].some(
        (k) => data[k] !== undefined
      );
      if (!hasAny) return false;
      if (Array.isArray(data.accounts) && data.accounts.length === 0) return false;
      if (Array.isArray(data.transactions)) this.setTransactions(data.transactions);
      if (Array.isArray(data.accounts)) this.setAccounts(data.accounts);
      if (Array.isArray(data.categories) && data.categories.length > 0) this.setCategories(data.categories);
      if (Array.isArray(data.budgets)) this.setBudgets(data.budgets);
      if (Array.isArray(data.goals)) this.setSavingsGoals(data.goals);
      if (Array.isArray(data.bills)) this.setRecurringBills(data.bills);
      if (data.settings && typeof data.settings === 'object') {
        this.setSettings({ ...INITIAL_APP_SETTINGS, ...data.settings });
      }
      return true;
    } catch (e) {
      console.error('Failed to parse backup JSON:', e);
      return false;
    }
  }

  public exportTransactionsCSV(): string {
    const txs = this.getTransactions();
    const categories = this.getCategories();
    const accounts = this.getAccounts();

    const catMap = new Map(categories.map((c) => [c.id, c.nameAr]));
    const accMap = new Map(accounts.map((a) => [a.id, a.name]));

    // Quote every text cell and neutralise spreadsheet formula injection
    const q = (v: string) => {
      const safe = /^[=+\-@]/.test(v) ? `'${v}` : v;
      return `"${safe.replace(/"/g, '""')}"`;
    };

    const header = ['ID', 'Date', 'Type', 'Amount', 'Description', 'Category', 'Account', 'Source', 'Status'];
    const rows = txs.map((t) => [
      t.id,
      t.date,
      t.type,
      t.amount.toFixed(2),
      q(t.description || ''),
      q(catMap.get(t.categoryId) || ''),
      q(accMap.get(t.accountId) || ''),
      t.source,
      t.status,
    ]);

    // BOM so Excel opens Arabic text correctly
    return '\ufeff' + [header.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }
}

export const storage = new StorageService();
