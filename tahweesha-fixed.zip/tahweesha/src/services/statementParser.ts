/**
 * Tahweesha (تحويشة) - Bank Statement Parser Service
 * Real parsing engine for CSV, Excel (XLSX), and text-based statements.
 * Features automated column detection, date & currency normalization,
 * duplicate detection, and opening/closing balance reconciliation.
 */

import * as XLSX from 'xlsx';
import { Transaction, TransactionReviewStatus } from '../types/finance';
import { generateTransactionFingerprint, roundTo2Decimals } from '../utils/financialMath';

export interface ColumnMapping {
  dateCol: number;
  descCol: number;
  amountCol: number;
  debitCol?: number;
  creditCol?: number;
  balanceCol?: number;
  refCol?: number;
}

export interface ParsedStatementRow {
  rowIndex: number;
  rawDate: string;
  normalizedDate: string;
  rawDescription: string;
  cleanedDescription: string;
  rawAmount: string;
  amount: number;
  type: 'income' | 'expense' | 'transfer';
  balance?: number;
  referenceNumber?: string;
  suggestedCategoryId: string;
  isDuplicate: boolean;
  duplicateReason?: string;
  isValid: boolean;
  validationError?: string;
  status: TransactionReviewStatus;
  selected: boolean;
}

export interface StatementParseResult {
  fileName: string;
  fileType: 'pdf' | 'excel' | 'csv';
  rawRows: string[][];
  headers: string[];
  detectedMapping: ColumnMapping;
  candidateRows: ParsedStatementRow[];
  openingBalance?: number;
  closingBalance?: number;
  calculatedClosingBalance?: number;
  reconciliationDifference?: number;
  isReconciled: boolean;
  duplicateCount: number;
  validCount: number;
  invalidCount: number;
}

/**
 * Intelligent Merchant & Category Heuristics
 */
export function guessCategoryFromDescription(desc: string): string {
  const lower = desc.toLowerCase();

  // Salary / Income
  if (lower.includes('dividend') || lower.includes('أرباح') || lower.includes('investment') || lower.includes('استثمار')) {
    return 'cat_investments';
  }
  if (lower.includes('salary') || lower.includes('راتب') || lower.includes('wps') || lower.includes('payroll') || lower.includes('bonus') || lower.includes('مكافأة') || lower.includes('invoice') || lower.includes('consulting')) {
    return 'cat_salary';
  }

  // Dining / Food
  if (
    lower.includes('restaurant') || lower.includes('مطعم') || lower.includes('cafe') || lower.includes('coffee') ||
    lower.includes('starbucks') || lower.includes('talabat') || lower.includes('deliveroo') || lower.includes('zomato') ||
    lower.includes('mcdonald') || /\bkfc\b/.test(lower) || lower.includes('noon food') || lower.includes('كافيه')
  ) {
    return 'cat_dining';
  }

  // Shopping & Groceries
  if (
    lower.includes('carrefour') || lower.includes('lulu') || lower.includes('spinneys') || lower.includes('choithrams') ||
    lower.includes('supermarket') || lower.includes('سوبرماركت') || lower.includes('amazon') || /\bnoon\b/.test(lower) ||
    lower.includes('ikea') || lower.includes('zara') || lower.includes('h&m') || /\bmall\b/.test(lower) || lower.includes('تسوق')
  ) {
    return 'cat_shopping';
  }

  // Transport & Auto
  if (
    lower.includes('uber') || lower.includes('careem') || /\brta\b/.test(lower) || lower.includes('salik') ||
    lower.includes('enoc') || lower.includes('adnoc') || lower.includes('emarat') || lower.includes('petrol') ||
    lower.includes('parking') || lower.includes('موقف') || lower.includes('مواصلات') || lower.includes('وقود')
  ) {
    return 'cat_transport';
  }

  // Housing & Bills
  if (
    lower.includes('dewa') || lower.includes('sewa') || lower.includes('fewa') || lower.includes('etisalat') ||
    /\bdu\b/.test(lower) || /\brent\b/.test(lower) || lower.includes('إيجار') || lower.includes('cheque') ||
    lower.includes('chq') || lower.includes('كهرباء') || lower.includes('فواتير') || lower.includes('maintenance')
  ) {
    return 'cat_housing';
  }

  // Health
  if (
    lower.includes('pharmacy') || lower.includes('صيدلية') || lower.includes('clinic') || lower.includes('عيادة') ||
    lower.includes('hospital') || lower.includes('مستشفى') || lower.includes('gym') || lower.includes('fitness') ||
    lower.includes('doctor')
  ) {
    return 'cat_health';
  }

  // Entertainment
  if (
    lower.includes('netflix') || lower.includes('spotify') || lower.includes('cinema') || /\bvox\b/.test(lower) ||
    /\breel\b/.test(lower) || lower.includes('playstation') || lower.includes('itunes') || lower.includes('entertainment')
  ) {
    return 'cat_entertainment';
  }

  // Transfers
  if (lower.includes('transfer') || lower.includes('تحويل') || lower.includes('trf') || lower.includes('remittance')) {
    return 'cat_transfer';
  }

  return 'cat_other';
}

/**
 * Normalize Date to ISO YYYY-MM-DD
 */
export function normalizeDate(raw: string): string | null {
  if (raw === undefined || raw === null) return null;
  const str = String(raw).trim();
  if (!str) return null;

  const pad = (n: number | string) => String(n).padStart(2, '0');
  const valid = (y: number, m: number, d: number): string | null => {
    if (y < 1900 || y > 2200 || m < 1 || m > 12 || d < 1 || d > 31) return null;
    const dt = new Date(Date.UTC(y, m - 1, d));
    if (dt.getUTCMonth() !== m - 1) return null; // e.g. 31 Feb
    return `${y}-${pad(m)}-${pad(d)}`;
  };

  // Match YYYY-MM-DD or YYYY/MM/DD (optionally followed by a time)
  const ymd = str.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[ T].*)?$/);
  if (ymd) return valid(+ymd[1], +ymd[2], +ymd[3]);

  // Excel serial date number (e.g. 45951 or 45951.5)
  if (/^\d{5}(\.\d+)?$/.test(str)) {
    const serial = Math.floor(parseFloat(str));
    if (serial >= 25000 && serial <= 80000) {
      const dt = new Date(Date.UTC(1899, 11, 30) + serial * 86400000);
      return valid(dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate());
    }
  }

  // Match DD/MM/YYYY or DD-MM-YYYY (UAE banks are day-first; fall back to month-first if impossible)
  const dmyMatch = str.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})(?:[ T].*)?$/);
  if (dmyMatch) {
    const a = +dmyMatch[1];
    const b = +dmyMatch[2];
    const y = +dmyMatch[3];
    return valid(y, b, a) ?? valid(y, a, b);
  }

  // Match DD-MMM-YYYY (e.g. 15-Oct-2025 or 15 Oct 2025)
  const monthNames: Record<string, string> = {
    jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
    jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12',
    يناير: '01', فبراير: '02', مارس: '03', أبريل: '04', مايو: '05', يونيو: '06',
    يوليو: '07', أغسطس: '08', سبتمبر: '09', أكتوبر: '10', نوفمبر: '11', ديسمبر: '12',
  };

  const textMatch = str.match(/^(\d{1,2})[\s-]([a-zA-Z\u0600-\u06FF]{3,})[\s,-]+(\d{4})$/);
  if (textMatch) {
    const mStr = textMatch[2].toLowerCase().substring(0, 3);
    const month = monthNames[mStr] ?? monthNames[textMatch[2]];
    if (month) return valid(+textMatch[3], +month, +textMatch[1]);
  }

  // Try standard Date parse (use local components, not UTC, to avoid off-by-one in UTC+4)
  const parsed = new Date(str);
  if (!isNaN(parsed.getTime())) {
    return valid(parsed.getFullYear(), parsed.getMonth() + 1, parsed.getDate());
  }

  return null;
}

/**
 * Normalize Currency Number String
 * Handles commas, parentheses for negatives (e.g. (180.00)), Dr/Cr tags, etc.
 */
export function normalizeNumber(raw: string | number): number | null {
  if (typeof raw === 'number') return isNaN(raw) ? null : roundTo2Decimals(raw);
  if (!raw) return null;

  let str = String(raw).trim();
  let isNegative = false;

  // Handles (123.45)
  if (str.startsWith('(') && str.endsWith(')')) {
    isNegative = true;
    str = str.slice(1, -1).trim();
  }

  // Handles -123.45 or 123.45- or 123.45 DR
  if (str.endsWith('-') || /\bdr\b/i.test(str)) {
    isNegative = true;
  }
  if (str.startsWith('-')) {
    isNegative = true;
    str = str.substring(1).trim();
  }

  // Strip currency codes, symbols, and tags
  str = str.replace(/\b(AED|USD|EUR|SAR|EGP|CR|DR)\b/gi, '');
  str = str.replace(/د\.إ/g, '');
  // Strip commas, spaces, and trailing signs
  str = str.replace(/,/g, '').replace(/\s+/g, '').replace(/-/g, '').trim();

  const num = parseFloat(str);
  if (isNaN(num)) return null;

  const result = isNegative ? -Math.abs(num) : Math.abs(num);
  return roundTo2Decimals(result);
}

/**
 * Clean Merchant Description for readability while preserving original
 */
export function cleanMerchantDescription(raw: string): string {
  let cleaned = raw
    .replace(/\b(POS DEBIT|POS PURCHASE|WPS SALARY|CHQ CLEARING|DIRECT DEBIT|ATM WITHDRAWAL|TRF|TRANSFER)\b/gi, '')
    .replace(/[*\d#_]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // If after cleaning it's empty, revert to raw
  if (cleaned.length < 3) cleaned = raw.trim();

  // Title case
  return cleaned
    .split(' ')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

/**
 * Heuristically detect columns from header row
 */
export function detectColumnMapping(headers: string[]): ColumnMapping {
  let dateCol = -1;
  let descCol = -1;
  let amountCol = -1;
  let debitCol: number | undefined;
  let creditCol: number | undefined;
  let balanceCol: number | undefined;
  let refCol: number | undefined;

  headers.forEach((h, idx) => {
    const lower = h.toLowerCase().trim();

    // Date
    if (lower.includes('date') || lower.includes('تاريخ') || lower.includes('posting date') || lower.includes('value date')) {
      if (dateCol === -1) dateCol = idx;
    }
    // Description
    else if (lower.includes('desc') || lower.includes('particulars') || lower.includes('بيان') || lower.includes('تفاصيل') || lower.includes('narrative') || lower.includes('merchant')) {
      if (descCol === -1) descCol = idx;
    }
    // Debit
    else if (lower.includes('debit') || lower.includes('مدين') || lower.includes('withdrawal') || lower.includes('سحب') || lower.includes('مصروف')) {
      debitCol = idx;
    }
    // Credit
    else if (lower.includes('credit') || lower.includes('دائن') || lower.includes('deposit') || lower.includes('إيداع') || lower.includes('دخل')) {
      creditCol = idx;
    }
    // Amount
    else if (lower.includes('amount') || lower.includes('مبلغ') || lower.includes('قيمة')) {
      if (amountCol === -1) amountCol = idx;
    }
    // Balance
    else if (lower.includes('balance') || lower.includes('رصيد')) {
      balanceCol = idx;
    }
    // Reference
    else if (lower.includes('ref') || lower.includes('مرجع') || lower.includes('chq') || lower.includes('شيك')) {
      refCol = idx;
    }
  });

  // Fallbacks if not detected by header name
  if (dateCol === -1) dateCol = 0;
  if (descCol === -1) descCol = 1;
  if (amountCol === -1 && debitCol === undefined && creditCol === undefined) {
    amountCol = 2;
  }

  return {
    dateCol,
    descCol,
    amountCol: amountCol !== -1 ? amountCol : 2,
    debitCol,
    creditCol,
    balanceCol,
    refCol,
  };
}

/**
 * Parse CSV text into 2D string array
 */
export function parseCSVText(csvContent: string): string[][] {
  const lines = csvContent.split(/\r?\n/).filter((l) => l.trim().length > 0);
  const result: string[][] = [];

  for (const line of lines) {
    const row: string[] = [];
    let insideQuote = false;
    let currentCell = '';

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        insideQuote = !insideQuote;
      } else if ((char === ',' || char === ';' || char === '\t') && !insideQuote) {
        row.push(currentCell.trim());
        currentCell = '';
      } else {
        currentCell += char;
      }
    }
    row.push(currentCell.trim());
    if (row.some((c) => c.length > 0)) {
      result.push(row);
    }
  }

  return result;
}

/**
 * Main parser entry point for uploaded or sample files
 */
export function processStatementMatrix(
  rawMatrix: string[][],
  fileName: string,
  fileType: 'pdf' | 'excel' | 'csv',
  existingTransactions: Transaction[],
  customMapping?: ColumnMapping
): StatementParseResult {
  if (rawMatrix.length === 0) {
    return {
      fileName,
      fileType,
      rawRows: [],
      headers: [],
      detectedMapping: { dateCol: 0, descCol: 1, amountCol: 2 },
      candidateRows: [],
      isReconciled: false,
      duplicateCount: 0,
      validCount: 0,
      invalidCount: 0,
    };
  }

  // Excel/PDF cells may be numbers or Date objects at runtime: coerce everything to text
  rawMatrix = rawMatrix.map((row) =>
    row.map((cell: unknown) => {
      if (cell === null || cell === undefined) return '';
      if (cell instanceof Date) {
        const d = cell as Date;
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      }
      return String(cell).replace(/^\ufeff/, '');
    })
  );

  // Find header row (first non-empty row)
  let headerRowIndex = 0;
  for (let i = 0; i < Math.min(rawMatrix.length, 5); i++) {
    const row = rawMatrix[i];
    const joined = row.join(' ').toLowerCase();
    if (joined.includes('date') || joined.includes('تاريخ') || joined.includes('amount') || joined.includes('desc')) {
      headerRowIndex = i;
      break;
    }
  }

  const headers = rawMatrix[headerRowIndex] || [];
  const mapping = customMapping || detectColumnMapping(headers);

  // Existing fingerprints for duplicate detection
  const existingFingerprints = new Set(existingTransactions.map((tx) => tx.fingerprint));

  const candidateRows: ParsedStatementRow[] = [];
  const seenInFile = new Set<string>();
  let openingBalance: number | undefined;
  let closingBalance: number | undefined;

  // Process data rows
  for (let r = headerRowIndex + 1; r < rawMatrix.length; r++) {
    const row = rawMatrix[r];
    if (!row || row.length < 2) continue;

    const rawDate = row[mapping.dateCol] || '';
    const rawDesc = row[mapping.descCol] || '';
    const rawRef = mapping.refCol !== undefined ? row[mapping.refCol] : undefined;

    // Check for opening balance or closing balance summary rows
    const lowerDesc = rawDesc.toLowerCase();
    if (lowerDesc.includes('opening balance') || lowerDesc.includes('الرصيد الافتتاحي') || lowerDesc.includes('balance b/f')) {
      const balStr = mapping.balanceCol !== undefined ? row[mapping.balanceCol] : row[mapping.amountCol];
      openingBalance = normalizeNumber(balStr) ?? undefined;
      continue;
    }
    if (lowerDesc.includes('closing balance') || lowerDesc.includes('الرصيد الختامي') || lowerDesc.includes('balance c/f')) {
      const balStr = mapping.balanceCol !== undefined ? row[mapping.balanceCol] : row[mapping.amountCol];
      closingBalance = normalizeNumber(balStr) ?? undefined;
      continue;
    }

    const normalizedDate = normalizeDate(rawDate);
    if (!normalizedDate) {
      // Not a valid transaction row (possibly subheader or footer)
      continue;
    }

    // Determine amount and type (Debit vs Credit)
    let amount = 0;
    let type: 'income' | 'expense' | 'transfer' = 'expense';
    let rawAmount = '';

    if (mapping.debitCol !== undefined && mapping.creditCol !== undefined) {
      const debitRaw = row[mapping.debitCol] || '';
      const creditRaw = row[mapping.creditCol] || '';
      const debitVal = normalizeNumber(debitRaw);
      const creditVal = normalizeNumber(creditRaw);

      if (creditVal && creditVal > 0) {
        amount = Math.abs(creditVal);
        type = 'income';
        rawAmount = creditRaw;
      } else if (debitVal && debitVal > 0) {
        amount = Math.abs(debitVal);
        type = 'expense';
        rawAmount = debitRaw;
      }
    } else {
      rawAmount = row[mapping.amountCol] || '';
      const parsedNum = normalizeNumber(rawAmount);
      if (parsedNum !== null) {
        if (parsedNum < 0) {
          type = 'expense';
          amount = Math.abs(parsedNum);
        } else {
          // If description indicates expense keywords or salary
          const suggested = guessCategoryFromDescription(rawDesc);
          if (suggested === 'cat_salary' || suggested === 'cat_investments') {
            type = 'income';
          } else {
            type = 'expense';
          }
          amount = Math.abs(parsedNum);
        }
      }
    }

    // Balance column tracking
    let rowBalance: number | undefined;
    if (mapping.balanceCol !== undefined && row[mapping.balanceCol]) {
      const b = normalizeNumber(row[mapping.balanceCol]);
      if (b !== null) {
        rowBalance = b;
      }
    }

    const cleanedDesc = cleanMerchantDescription(rawDesc);
    const suggestedCategory = guessCategoryFromDescription(rawDesc);

    // If description mentions internal transfer
    // (only outgoing money becomes an internal transfer; an incoming credit stays income so the balance math keeps its direction)
    if (suggestedCategory === 'cat_transfer' && type === 'expense') {
      type = 'transfer';
    }

    // Check duplicate
    const fp = generateTransactionFingerprint(normalizedDate, amount, cleanedDesc);
    const dupKey = `${fp}#${rawRef || ''}`;
    // Duplicate of an already-saved transaction, or an identical row (same reference) earlier in this file
    const isDuplicate = existingFingerprints.has(fp) || seenInFile.has(dupKey);
    seenInFile.add(dupKey);

    const isValid = amount > 0 && normalizedDate !== null && rawDesc.trim().length > 0;

    candidateRows.push({
      rowIndex: r,
      rawDate,
      normalizedDate,
      rawDescription: rawDesc,
      cleanedDescription: cleanedDesc,
      rawAmount,
      amount,
      type,
      balance: rowBalance,
      referenceNumber: rawRef,
      suggestedCategoryId: suggestedCategory,
      isDuplicate,
      duplicateReason: isDuplicate ? 'تم العثور على معاملة مطابقة بنفس التاريخ والمبلغ والوصف' : undefined,
      isValid,
      validationError: !isValid ? 'بيانات المعاملة غير مكتملة أو المبلغ غير صالح' : undefined,
      status: isDuplicate ? 'uncertain' : 'reviewed',
      selected: isValid && !isDuplicate,
    });
  }

  // Single-amount-column statements: infer credit vs debit from running-balance movement
  if (mapping.debitCol === undefined && mapping.creditCol === undefined && candidateRows.length > 1) {
    const allBal = candidateRows.every((c) => c.balance !== undefined);
    if (allBal) {
      const newestFirst = candidateRows[0].normalizedDate > candidateRows[candidateRows.length - 1].normalizedDate;
      for (let i = 0; i < candidateRows.length; i++) {
        const prev = newestFirst ? candidateRows[i + 1] : candidateRows[i - 1];
        const cur = candidateRows[i];
        if (!prev || cur.type === 'transfer') continue;
        const delta = roundTo2Decimals((cur.balance as number) - (prev.balance as number));
        if (Math.abs(Math.abs(delta) - cur.amount) < 0.01) {
          cur.type = delta > 0 ? 'income' : 'expense';
          if (cur.type === 'income' && cur.suggestedCategoryId === 'cat_other') cur.suggestedCategoryId = 'cat_salary';
        }
      }
    }
  }

  // Derive opening/closing balances from the running-balance column when the file has no explicit rows
  if ((openingBalance === undefined || closingBalance === undefined) && candidateRows.length > 0) {
    const withBal = candidateRows.filter((c) => c.balance !== undefined);
    if (withBal.length === candidateRows.length) {
      const first = candidateRows[0];
      const last = candidateRows[candidateRows.length - 1];
      const newestFirst = first.normalizedDate > last.normalizedDate;
      const signed = (c: ParsedStatementRow) => (c.type === 'income' ? c.amount : -c.amount);
      const oldest = newestFirst ? last : first;
      const newest = newestFirst ? first : last;
      if (closingBalance === undefined) closingBalance = newest.balance;
      if (openingBalance === undefined) {
        openingBalance = roundTo2Decimals((oldest.balance as number) - signed(oldest));
      }
    }
  }

  // Calculate reconciliation if balances exist
  let calculatedClosingBalance: number | undefined;
  let reconciliationDifference: number | undefined;
  let isReconciled = false;

  if (openingBalance !== undefined && closingBalance !== undefined) {
    let net = 0;
    for (const c of candidateRows) {
      if (c.type === 'income') net = roundTo2Decimals(net + c.amount);
      else net = roundTo2Decimals(net - c.amount);
    }
    calculatedClosingBalance = roundTo2Decimals(openingBalance + net);
    reconciliationDifference = roundTo2Decimals(closingBalance - calculatedClosingBalance);
    isReconciled = Math.abs(reconciliationDifference) < 0.05;
  }

  const duplicateCount = candidateRows.filter((r) => r.isDuplicate).length;
  const validCount = candidateRows.filter((r) => r.isValid).length;
  const invalidCount = candidateRows.filter((r) => !r.isValid).length;

  return {
    fileName,
    fileType,
    rawRows: rawMatrix,
    headers,
    detectedMapping: mapping,
    candidateRows,
    openingBalance,
    closingBalance,
    calculatedClosingBalance,
    reconciliationDifference,
    isReconciled,
    duplicateCount,
    validCount,
    invalidCount,
  };
}

/**
 * Parse an Excel File (Buffer or ArrayBuffer) using XLSX
 */
export function parseExcelBuffer(
  buffer: ArrayBuffer,
  fileName: string,
  existingTransactions: Transaction[]
): StatementParseResult {
  const workbook = XLSX.read(buffer, { type: 'array' });
  const firstSheetName = workbook.SheetNames[0];
  if (!firstSheetName) throw new Error('Empty workbook');
  const worksheet = workbook.Sheets[firstSheetName];
  const rawData: string[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '', raw: true });

  return processStatementMatrix(rawData, fileName, 'excel', existingTransactions);
}

/**
 * Pre-configured Synthetic Bank Statements for 1-Click Verification
 */
export const SYNTHETIC_STATEMENTS = {
  emiratesNBD_CSV: {
    name: 'كشف حساب بنك الإمارات دبي الوطني (CSV)',
    type: 'csv' as const,
    data: `Date,Particulars,Debit,Credit,Balance,Ref
2025/10/21,POS DEBIT - ZAHRAT AL LAYMOUN DUBAI,180.00,,23450.00,TXN849102
2025/10/20,WPS SALARY TRANSFER OCT 2025 - TECH CORP,,8000.00,23630.00,SAL202510
2025/10/19,CARREFOUR HYPERMARKET MOE DUBAI,320.00,,15630.00,POS492019
2025/10/18,INTERNAL FUNDS TRANSFER TO SAVINGS,1500.00,,15950.00,TRF882011
2025/10/15,CHQ CLEARING - REAL ESTATE DUBAI RENT,2500.00,,17450.00,CHQ009182
2025/10/14,RTA PARKING DUBAI RECHARGE,50.00,,19950.00,RTA88291
2025/10/10,BONUS PAYMENT FOR PROJECT COMPLETION,,1000.00,20000.00,BON99218
2025/10/08,DIVIDEND DISTRIBUTION Q3 2025,,3800.00,19000.00,DIV33019
2025/10/05,SHIMMERS JUMEIRAH RESTAURANT,770.00,,15200.00,POS19482
2025/10/04,ENOC SERVICE STATION DUBAI,650.00,,15970.00,ENOC9182
2025/10/02,IKEA DUBAI FESTIVAL CITY,480.00,,16620.00,POS77381`,
  },
  adcb_CSV: {
    name: 'كشف حساب بنك أبوظبي التجاري ADCB (CSV)',
    type: 'csv' as const,
    data: `Posting Date,Description,Withdrawals,Deposits,Running Balance,Reference
15-10-2025,DEWA BILL PAYMENT DUBAI,350.00,,18500.00,DEWA882190
12-10-2025,LULU HYPERMARKET AL BARSHA,415.50,,18850.00,POS551029
09-10-2025,STARBUCKS COFFEE DUBAI MALL,38.00,,19265.50,POS339102
05-10-2025,CONSULTING SERVICES INVOICE 104,,4500.00,19303.50,INV104
02-10-2025,SALIK TOLL CHARGES AUTO DEBIT,100.00,,14803.50,SLK99210`,
  },
  ambiguous_CSV: {
    name: 'كشف حساب يحتوي على معاملات مكررة وفروقات (اختبار التحقق)',
    type: 'csv' as const,
    data: `التاريخ,البيان,المبلغ,الرصيد
2025/10/21,مطعم,-180.00,23450.00
2025/10/20,راتب,8000.00,23630.00
2025/10/19,سوبرماركت,-320.00,15630.00
2025/10/21,مطعم,-180.00,23450.00
2025/10/18,دفعة نقدية غير مصنفة,-500.00,15450.00`,
  },
};
