/**
 * Tahweesha (تحويشة) - Main Application Entry
 * Premium Personal Finance Android Application
 * Recreates the exact glassmorphism design showcase with real financial computations,
 * persistent local storage, bank statement importing, and Arabic/English localization.
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Smartphone,
  Maximize2,
  Minimize2,
  Moon,
  Sun,
  Globe,
  Wifi,
  Battery,
  Shield,
  Layers,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  ArrowLeft,
} from 'lucide-react';
import { storage } from './services/storage';
import {
  Transaction,
  Account,
  Category,
  Budget,
  SavingsGoal,
  RecurringBill,
  AppSettings,
  ImportBatch,
} from './types/finance';
import {
  calculateAccountBalance,
  calculateMonthlySummary,
  calculateTotalBalance,
  roundTo2Decimals,
  todayISO,
} from './utils/financialMath';

// Screen Components
import { HomeScreen } from './components/HomeScreen';
import { TransactionsScreen } from './components/TransactionsScreen';
import { ReportsScreen } from './components/ReportsScreen';
import { BudgetScreen } from './components/BudgetScreen';
import { MoreMenuScreen, MoreDestination } from './components/MoreMenuScreen';
import { StatementImportScreen } from './components/StatementImportScreen';
import { AccountsScreen } from './components/AccountsScreen';
import { GoalsAndBillsScreen } from './components/GoalsAndBillsScreen';
import { SmartAssistantScreen } from './components/SmartAssistantScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { AddTransactionModal } from './components/AddTransactionModal';
import { BiometricModal } from './components/BiometricModal';
import { BottomNavBar, NavTab } from './components/BottomNavBar';
import { TahweeshaLogo } from './components/TahweeshaLogo';

export default function App() {
  // Persistence State
  const [transactions, setTransactions] = useState<Transaction[]>(() => storage.getTransactions());
  const [accounts, setAccounts] = useState<Account[]>(() => storage.getAccounts());
  const [categories, setCategories] = useState<Category[]>(() => storage.getCategories());
  const [budgets, setBudgets] = useState<Budget[]>(() => storage.getBudgets());
  const [goals, setGoals] = useState<SavingsGoal[]>(() => storage.getSavingsGoals());
  const [bills, setBills] = useState<RecurringBill[]>(() => storage.getRecurringBills());
  const [settings, setSettings] = useState<AppSettings>(() => storage.getSettings());

  // Navigation State
  const [currentTab, setCurrentTab] = useState<NavTab>('home');
  const [moreSubScreen, setMoreSubScreen] = useState<MoreDestination | null>(null);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [addModalType, setAddModalType] = useState<'expense' | 'income' | 'transfer'>('expense');
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isBiometricModalOpen, setIsBiometricModalOpen] = useState(false);

  // View Mode: Mobile Phone Shell (desktop preview only) vs real full-screen app (phones)
  const [isWideScreen, setIsWideScreen] = useState(
    () => typeof window !== 'undefined' && window.matchMedia('(min-width: 640px)').matches
  );
  const [framePref, setFramePref] = useState(true);
  const usePhoneFrame = isWideScreen && framePref;
  const setUsePhoneFrame = (v: boolean) => setFramePref(v);

  useEffect(() => {
    const mq = window.matchMedia('(min-width: 640px)');
    const onChange = (e: MediaQueryListEvent) => setIsWideScreen(e.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  // Biometric app lock (simulated): lock on launch when enabled
  const [isLocked, setIsLocked] = useState(() => storage.getSettings().biometricEnabled);

  // Synchronize with storage updates
  useEffect(() => {
    const unsubscribe = storage.subscribe(() => {
      setTransactions([...storage.getTransactions()]);
      setAccounts([...storage.getAccounts()]);
      setCategories([...storage.getCategories()]);
      setBudgets([...storage.getBudgets()]);
      setGoals([...storage.getSavingsGoals()]);
      setBills([...storage.getRecurringBills()]);
      setSettings({ ...storage.getSettings() });
    });
    return unsubscribe;
  }, []);

  // Update HTML tag attributes on language and theme changes
  useEffect(() => {
    const html = document.documentElement;
    html.lang = settings.language;
    html.dir = settings.language === 'ar' ? 'rtl' : 'ltr';

    if (settings.theme === 'dark') {
      html.classList.add('dark');
    } else {
      html.classList.remove('dark');
    }
  }, [settings.language, settings.theme]);

  const isDark = settings.theme === 'dark';
  const isAr = settings.language === 'ar';

  // Derived Financial Computations
  const totalBalance = useMemo(() => {
    if (settings.selectedAccountId !== 'all') {
      const acc = accounts.find((a) => a.id === settings.selectedAccountId);
      return acc ? calculateAccountBalance(acc, transactions) : 0;
    }
    return calculateTotalBalance(accounts, transactions);
  }, [accounts, transactions, settings.selectedAccountId]);

  // Transactions in scope of the account selector (transfers count for both accounts)
  const scopedTransactions = useMemo(() => {
    if (settings.selectedAccountId === 'all') return transactions;
    return transactions.filter(
      (t) =>
        t.accountId === settings.selectedAccountId || t.destinationAccountId === settings.selectedAccountId
    );
  }, [transactions, settings.selectedAccountId]);

  const monthlySummary = useMemo(() => {
    return calculateMonthlySummary(settings.currentMonth, scopedTransactions, categories, budgets);
  }, [settings.currentMonth, scopedTransactions, categories, budgets]);

  const handleChangeMonth = (month: string) => storage.updateSettings({ currentMonth: month });

  // Handlers
  const handleSaveTransaction = (tx: Transaction) => {
    if (editingTransaction) {
      storage.updateTransaction(tx);
    } else {
      storage.addTransaction(tx);
    }
    setEditingTransaction(null);
  };

  const handleDeleteTransaction = (id: string) => {
    storage.deleteTransaction(id);
  };

  const handleUpdateTxStatus = (id: string, status: 'verified' | 'reviewed') => {
    const tx = transactions.find((t) => t.id === id);
    if (tx) {
      storage.updateTransaction({ ...tx, status });
    }
  };

  const handleImportBatchComplete = (batch: ImportBatch, newTxs: Transaction[]) => {
    storage.addImportBatch(batch, newTxs);
    setIsImportModalOpen(false);
    setMoreSubScreen(null);
    // Jump to the newest imported month so the user immediately sees the result
    const latest = newTxs.map((t) => t.date.slice(0, 7)).sort().pop();
    if (latest) storage.updateSettings({ currentMonth: latest });
  };

  const handleInternalTransfer = (
    fromAccountId: string,
    toAccountId: string,
    amount: number,
    description: string
  ) => {
    const tx: Transaction = {
      id: `tx_trf_${Date.now()}`,
      date: todayISO(),
      amount: roundTo2Decimals(amount),
      type: 'transfer',
      categoryId: 'cat_transfer',
      accountId: fromAccountId,
      destinationAccountId: toAccountId,
      description,
      source: 'manual',
      status: 'verified',
      fingerprint: `trf_${Date.now()}_${amount}`,
    };
    storage.addTransaction(tx);
  };

  const handleTabChange = (tab: NavTab) => {
    setCurrentTab(tab);
    setMoreSubScreen(null);
  };

  // Render current screen content
  const renderScreenContent = () => {
    // If under "More" and a subscreen is active:
    if (currentTab === 'more' && moreSubScreen) {
      switch (moreSubScreen) {
        case 'import':
          return (
            <StatementImportScreen
              accounts={accounts}
              categories={categories}
              existingTransactions={transactions}
              settings={settings}
              onClose={() => setMoreSubScreen(null)}
              onImportComplete={handleImportBatchComplete}
            />
          );
        case 'accounts':
          return (
            <AccountsScreen
              accounts={accounts}
              transactions={transactions}
              settings={settings}
              onAddAccount={(acc) => {
                const list = storage.getAccounts();
                list.push(acc);
                storage.setAccounts(list);
              }}
              onTransfer={handleInternalTransfer}
            />
          );
        case 'goals':
          return (
            <GoalsAndBillsScreen
              goals={goals}
              bills={bills}
              settings={settings}
              onUpdateGoal={(g) => storage.updateSavingsGoal(g)}
              onAddGoal={(g) => storage.addSavingsGoal(g)}
              onToggleBill={(id) => storage.toggleBillPaid(id)}
            />
          );
        case 'assistant':
          return (
            <SmartAssistantScreen
              summary={monthlySummary}
              totalBalance={totalBalance}
              transactions={transactions}
              categories={categories}
              settings={settings}
            />
          );
        case 'settings':
          return (
            <SettingsScreen
              settings={settings}
              onUpdateSettings={(p) => storage.updateSettings(p)}
              onResetDemo={() => storage.resetToDemoData()}
              onClearAll={() => storage.clearAllData()}
              onRequestBiometricTest={() => setIsBiometricModalOpen(true)}
            />
          );
      }
    }

    switch (currentTab) {
      case 'home':
        return (
          <HomeScreen
            summary={monthlySummary}
            totalBalance={totalBalance}
            recentTransactions={scopedTransactions}
            categories={categories}
            accounts={accounts}
            settings={settings}
            onChangeMonth={handleChangeMonth}
            onNavigate={(t) => setCurrentTab(t)}
            onOpenAddModal={(type) => {
              setAddModalType(type || 'expense');
              setEditingTransaction(null);
              setIsAddModalOpen(true);
            }}
            onOpenImportModal={() => setIsImportModalOpen(true)}
            onToggleHideBalance={() =>
              storage.updateSettings({ hideBalance: !settings.hideBalance })
            }
            onSelectAccount={(accId) => storage.updateSettings({ selectedAccountId: accId })}
          />
        );
      case 'transactions':
        return (
          <TransactionsScreen
            transactions={transactions}
            categories={categories}
            accounts={accounts}
            settings={settings}
            onOpenAddModal={() => {
              setAddModalType('expense');
              setEditingTransaction(null);
              setIsAddModalOpen(true);
            }}
            onEditTransaction={(tx) => {
              setEditingTransaction(tx);
              setIsAddModalOpen(true);
            }}
            onDeleteTransaction={handleDeleteTransaction}
            onUpdateStatus={handleUpdateTxStatus}
          />
        );
      case 'reports':
        return (
          <ReportsScreen
            transactions={scopedTransactions}
            categories={categories}
            settings={settings}
            onChangeMonth={handleChangeMonth}
          />
        );
      case 'budget':
        return (
          <BudgetScreen
            summary={monthlySummary}
            budgets={budgets}
            categories={categories}
            settings={settings}
            onSaveBudget={(b) => storage.saveBudget(b)}
            onChangeMonth={handleChangeMonth}
          />
        );
      case 'more':
        return (
          <MoreMenuScreen
            settings={settings}
            onSelectDestination={(dest) => setMoreSubScreen(dest)}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div
      className={`min-h-screen transition-colors ${
        isDark
          ? 'bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950/20 text-slate-100'
          : 'bg-gradient-to-br from-slate-100 via-emerald-50/20 to-teal-50/30 text-slate-900'
      }`}
    >
      {/* Top Application Utility Bar */}
      <header
        className="sticky top-0 z-50 px-4 py-2.5 backdrop-blur-md border-b flex items-center justify-between gap-4 border-slate-200/50 dark:border-slate-800/60 bg-white/70 dark:bg-slate-900/70"
        style={{ paddingTop: 'calc(0.625rem + env(safe-area-inset-top))' }}
      >
        <div className="flex items-center gap-3">
          <TahweeshaLogo size="sm" showText={true} showTagline={false} isDark={isDark} />
          <span className="hidden sm:inline-block text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
            {isAr ? 'تطبيق مالي شخصي متكامل' : 'Premium Personal Finance'}
          </span>
        </div>

        {/* View Controls & Toggles */}
        <div className="flex items-center gap-2">
          {/* Language Toggle */}
          <button
            onClick={() =>
              storage.updateSettings({ language: settings.language === 'ar' ? 'en' : 'ar' })
            }
            className="px-2.5 py-1 rounded-xl text-xs font-semibold flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 transition-colors"
            title="تبديل اللغة / Toggle Language"
          >
            <Globe size={14} />
            <span>{settings.language === 'ar' ? 'EN' : 'عربي'}</span>
          </button>

          {/* Theme Toggle */}
          <button
            onClick={() =>
              storage.updateSettings({ theme: settings.theme === 'dark' ? 'light' : 'dark' })
            }
            className="p-1.5 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 transition-colors"
            title="تبديل المظهر / Toggle Theme"
          >
            {isDark ? <Sun size={15} className="text-amber-400" /> : <Moon size={15} />}
          </button>

          {/* Phone Shell / Full Viewport Mode Switch */}
          <button
            onClick={() => setUsePhoneFrame(!usePhoneFrame)}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-semibold transition-colors ${
              usePhoneFrame
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <Smartphone size={14} />
            <span>{usePhoneFrame ? (isAr ? 'إطار الهاتف' : 'Phone Frame') : (isAr ? 'شاشة كاملة' : 'Full Width')}</span>
          </button>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="max-w-7xl mx-auto px-2 sm:px-4 py-4 sm:py-6 flex justify-center">
        {usePhoneFrame ? (
          /* Phone Device Shell matching reference showcase presentation */
          <div
            className={`relative w-full max-w-[420px] rounded-[48px] p-3 shadow-2xl transition-all duration-300 border-[7px] ${
              isDark
                ? 'border-slate-800 bg-slate-950 shadow-emerald-950/30'
                : 'border-slate-300/80 bg-white shadow-slate-900/15'
            }`}
            style={{
              minHeight: '844px',
            }}
          >
            {/* Phone Screen Glass Frame */}
            <div
              className={`relative overflow-hidden rounded-[40px] px-4 pt-3 pb-6 min-h-[820px] flex flex-col ${
                isDark ? 'bg-slate-950' : 'bg-slate-50/50'
              }`}
            >
              {/* Native Android/iOS Phone Status Bar */}
              <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400 px-3 pb-3 pt-1 select-none">
                <span className="tabular-nums tracking-tight font-medium">9:41</span>

                {/* Notch / Dynamic Island */}
                <div className="w-24 h-4 rounded-full bg-slate-800 dark:bg-slate-900 mx-auto opacity-90 shadow-inner" />

                <div className="flex items-center gap-1.5">
                  <Wifi size={13} />
                  <span className="text-[10px] font-semibold">5G</span>
                  <Battery size={15} />
                </div>
              </div>

              {/* Subscreen Back Navigation if inside a More subscreen */}
              {currentTab === 'more' && moreSubScreen && (
                <div className="flex items-center gap-2 mb-3 px-1 pt-1">
                  <button
                    onClick={() => setMoreSubScreen(null)}
                    className="p-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center gap-1 text-xs font-semibold"
                  >
                    {isAr ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
                    <span>{isAr ? 'العودة للمزيد' : 'Back to More'}</span>
                  </button>
                </div>
              )}

              {/* Active Screen View */}
              <div className="flex-1">{renderScreenContent()}</div>

              {/* Persistent Bottom Navigation Bar */}
              <BottomNavBar
                activeTab={currentTab}
                onChangeTab={handleTabChange}
                isDark={isDark}
                isAr={isAr}
              />
            </div>
          </div>
        ) : (
          /* Full Viewport / Tablet Layout */
          <div className="w-full max-w-4xl flex flex-col min-h-[800px] relative pb-10">
            {currentTab === 'more' && moreSubScreen && (
              <div className="flex items-center gap-2 mb-4">
                <button
                  onClick={() => setMoreSubScreen(null)}
                  className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center gap-1.5 text-xs font-semibold"
                >
                  {isAr ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
                  <span>{isAr ? 'العودة لقائمة المزيد' : 'Back to More Menu'}</span>
                </button>
              </div>
            )}

            <div className="flex-1">{renderScreenContent()}</div>

            {/* Bottom Bar in full viewport mode */}
            <BottomNavBar
              activeTab={currentTab}
              onChangeTab={handleTabChange}
              isDark={isDark}
              isAr={isAr}
            />
          </div>
        )}
      </main>

      {/* Global Modals */}
      <AddTransactionModal
        isOpen={isAddModalOpen}
        initialType={addModalType}
        editingTransaction={editingTransaction}
        categories={categories}
        accounts={accounts}
        settings={settings}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingTransaction(null);
        }}
        onSave={handleSaveTransaction}
      />

      {isImportModalOpen && (
        <StatementImportScreen
          accounts={accounts}
          categories={categories}
          existingTransactions={transactions}
          settings={settings}
          onClose={() => setIsImportModalOpen(false)}
          onImportComplete={handleImportBatchComplete}
        />
      )}

      <BiometricModal
        isOpen={isBiometricModalOpen || isLocked}
        isAr={isAr}
        locked={isLocked}
        onSuccess={() => {
          setIsBiometricModalOpen(false);
          setIsLocked(false);
        }}
        onCancel={() => setIsBiometricModalOpen(false)}
      />
    </div>
  );
}
